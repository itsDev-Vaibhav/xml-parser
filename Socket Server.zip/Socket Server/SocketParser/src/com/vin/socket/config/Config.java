package com.vin.socket.config;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
public class Config
 {
	private static Logger log = Logger.getLogger(Config.class);
	public static String DBUSER = null;
	public static String PASS = null;
	public static String URL = null;
	public static  String EMAIL_FROM= null;
	public static  String MAIL_SMTP_HOST= null;
	public static  String MAIL_SMTP_PORT= null;
	public static LinkedHashMap<String ,String> STATUS_MAP=null;
	public static LinkedHashMap<String ,String> IMPORT_STATUS_INT_MAP=null;
	public static LinkedHashMap<String ,String> IMPORT_PARSE_TEMPLATE=null;
	public static LinkedHashMap<String,String> IMPORT_COLUMN_MAP=null;
	public static LinkedHashMap<String,String> IMPORT_PARSE_TABLE=null;
	public static LinkedHashMap<String,String> COLUMN_LENGTH_MAPPING=null;
	public static String STATUS_MSG_TEMPLATE=null;
	public static String INSTANCE_NAME=null;
	public static String PARSER_FLAG = null;
	public static String SEND_JALERT = null;
	public static String SEND_DALERT = null;
	public static String EMAIL_TO = null;
	static {
		Properties prop = new Properties();
		try {
			InputStream fstream = ClassLoader.class.getResourceAsStream("/com/vin/socket/resources/Config.properties");
			prop.load(fstream);
			DBUSER = prop.getProperty("DBUSER").trim();
			PASS = prop.getProperty("PASS").trim();
		    URL = prop.getProperty("URL").trim();
		    EMAIL_FROM=prop.getProperty("EMAIL_FROM").trim();
		    MAIL_SMTP_HOST=prop.getProperty("MAIL_SMTP_HOST").trim();
		    MAIL_SMTP_PORT=prop.getProperty("MAIL_SMTP_PORT").trim();
		    STATUS_MSG_TEMPLATE=prop.getProperty("STATUS_MSG_TEMPLATE").trim();
		    INSTANCE_NAME=prop.getProperty("INSTANCE_NAME").trim();
		    SEND_JALERT=prop.getProperty("SEND_JALERT").trim();
		    EMAIL_TO=prop.getProperty("EMAIL_TO").trim();
		    SEND_DALERT=prop.getProperty("SEND_DALERT").trim();
		    PARSER_FLAG=prop.getProperty("PARSER_FLAG").trim();
		    STATUS_MAP=(LinkedHashMap<String,String>)getPropertyMap("/com/vin/socket/resources/Status.properties");
		    IMPORT_STATUS_INT_MAP=(LinkedHashMap<String,String>)getPropertyMap("/com/vin/socket/resources/ImportDriMapping.properties");
		    IMPORT_PARSE_TEMPLATE=(LinkedHashMap<String,String>)getPropertyMap("/com/vin/socket/resources/ImportParseTemplate.properties");
		    IMPORT_COLUMN_MAP=(LinkedHashMap<String,String>)getPropertyMap("/com/vin/socket/resources/ImportColumnMap.properties");
		    IMPORT_PARSE_TABLE=(LinkedHashMap<String,String>)getPropertyMap("/com/vin/socket/resources/ImportParseTable.properties");
		    COLUMN_LENGTH_MAPPING=(LinkedHashMap<String,String>)getPropertyMap("/com/vin/socket/resources/ColumnLengthMapping.properties");
			fstream.close();
		} catch (Exception ex) {
			log.error("[Exception occured in Reading Config File][" + ex + "]");
			ex.printStackTrace();
			System.exit(0);
		}
	}
	
	public static List<String> getInterfaceList(String path){
		Properties prop = null;
		ArrayList<String> list=new ArrayList<String>();
		try{
		prop = new Properties();
		InputStream fstream = ClassLoader.class.getResourceAsStream(path);   //Config/*.properties
		prop.load(fstream);
		Enumeration e = prop.propertyNames();
		 while (e.hasMoreElements()) {
		      String key = (String) e.nextElement();
		      list.add(key);
		    }
		fstream.close();
		}catch(Exception e){
			log.error("Exception in getInFilePath method in Config.java class......");
		}
		return list;
	}
	
	public static Map<String,String> getPropertyMap(String path){
		Properties prop = null;
		LinkedHashMap<String,String> map=new LinkedHashMap<String,String>();
		try{
		prop = new Properties();
		InputStream fstream = ClassLoader.class.getResourceAsStream(path);   // Config/*.properties
		prop.load(fstream);
		Enumeration e = prop.propertyNames();
		 while (e.hasMoreElements()) {
		      String key = (String) e.nextElement();
		      map.put(key,prop.getProperty(key));
		    }
		fstream.close();
		}catch(Exception e){
			log.error("Exception in getInFilePath method in Config.java class......");
		}
		return map;
	}
	
}

