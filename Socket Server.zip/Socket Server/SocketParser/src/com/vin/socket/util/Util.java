package com.vin.socket.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

import com.vin.socket.config.Config;
import com.vin.socket.constant.ApplicationConstant;
import com.vin.socket.constant.DBConstant;


public class Util {
	
	private static Logger log = Logger.getLogger(Util.class); 
	
	public static Connection getConnection() {
		log.info("getting DB connection in parser");
		Connection con = null;
		String userId = Config.DBUSER;
		String passWord = Config.PASS;
		String url = Config.URL;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(url, userId, passWord);
		} catch (Exception e) {
			log.error("Socket Parser: Exception occured while getting connection with "+userId+" and the exception is : "+e.toString());
			if(Config.SEND_JALERT.equals("Y")){
			String errMsg = "<i>Attention</i><br><br>";
			errMsg += "An Exception occured in warehouse :"+Config.INSTANCE_NAME ;
			errMsg += "<br>The exception is given below :<br><br>"+ e.toString();
			errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
			SendMailSSL(Config.EMAIL_TO, "DB Connection Exception", errMsg);
			}
			if(e instanceof SQLRecoverableException || e instanceof SQLException){
				String ex=e.toString();
				if(ex.contains("Socket read timed out")){
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
					System.exit(0);
				}
			}
		}
		return con;
	}
	
	public static boolean SendMailSSL(String to,String interfaceName,String exception){
		boolean flag = true;
		try {
			Properties props = System.getProperties();
			props.put("mail.smtp.host", Config.MAIL_SMTP_HOST);
			props.put("mail.smtp.port", Config.MAIL_SMTP_PORT);
			Session session = Session.getDefaultInstance(props);
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(Config.EMAIL_FROM));
			message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to));
			message.setSubject("Trent Vapi Socket Parser: " + interfaceName);
			message.setContent(exception, "text/html");
			Transport.send(message);
			log.info("Email alert sent successfully");
		} catch (Exception e) {
			flag = false;
			insertToErrorLog(Config.MAIL_SMTP_HOST,Config.MAIL_SMTP_PORT,e.toString(),ApplicationConstant.YES);
			log.error("Exception occured in SendMailSSL while sending email : "+ e.toString());
		}
		return flag;
	}

	public static void insertToErrorLog(String dri,String key,String errMsg,String emailStatus){
		Connection con = null;
		PreparedStatement stmt = null;
		String errorMsg=null;
		try {
			con = Util.getConnection();
			if(null!=con){
			//sql:Insert into TL_ERROR_LOG (PROGRAMNAME, ERRORKEY, ERRORMESSAGE,EMAIL_ALERT) Values (?, ?, ?, ?)
			stmt = con.prepareStatement(DBConstant.INSERT_TO_ERRORLOG);
			stmt.setString(1, dri.trim());
			stmt.setString(2, key.trim());
			stmt.setString(3, errMsg);
			stmt.setString(4, emailStatus.trim());
			stmt.executeUpdate();
			}
		} catch (SQLException sqlException) {
			errorMsg = ApplicationConstant.ERROR_MSG_DATA_INSERT+" "+sqlException.toString();
			log.error(errorMsg);
		}catch (Exception exception) {
			errorMsg = ApplicationConstant.ERROR_MSG_DATA_INSERT+" "+exception.toString();;
			log.error(errorMsg);
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException sqlException) {
				errorMsg = ApplicationConstant.ERROR_MSG_DATA_INSERT+" "+sqlException.toString();
				log.error(errorMsg);
			}
		}
		if(null!=errorMsg){
			if(Config.SEND_JALERT.equals(ApplicationConstant.YES)){
				String err_Msg = "<i>Attention</i><br><br>";
				err_Msg += "An Exception occured in warehouse :"+Config.INSTANCE_NAME ;
				err_Msg += "<br>The exception is given below :<br><br>"+errorMsg;
				err_Msg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
				SendMailSSL(Config.EMAIL_TO, "Exception occured while inserting into tl_error_log table", err_Msg);
				}
		}
	}
	public static boolean isNumeric(String str) {
		boolean flag=true;
		try {
			Double.parseDouble(str);
		} catch (NumberFormatException nfe) {
			flag= false;
		}
		return flag;
	}
	public static void processErrorLog(){
		Connection con=null;
		PreparedStatement stmt=null;
		PreparedStatement stmt1=null;
		ResultSet rs=null;
		int serialkey=0;
		try {
			if(Config.EMAIL_FROM.isEmpty() || Config.EMAIL_TO.isEmpty())
			{
				log.error("Please enter the sender or recepient details in Config");
			}
			else
			{
			con = getConnection();
			if(null!=con){
				stmt = con.prepareStatement(DBConstant.GET_ERROR_LOG);
				rs = stmt.executeQuery();
				while (rs.next()) {
					serialkey=rs.getInt("SERIALKEY");
					String whseid=rs.getString("WHSEID");
					String programname=rs.getString("PROGRAMNAME");
					String errmsg=rs.getString("ERRORMESSAGE");				
					String exception = "<i>Attention</i><br><br>";
					exception += "An error occured in warehouse :"+whseid ;
					exception += "<br>The exception is given below :<br><br>"+ errmsg;
					exception += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
					boolean flag=SendMailSSL(Config.EMAIL_TO, programname, exception);
					if(flag){
						stmt1 = con.prepareStatement(DBConstant.UPDT_ERROR_LOG);
						stmt1.setInt(1,serialkey);
						stmt1.executeQuery();
						stmt1.close();
					}
					}
					if (null != rs) {
						rs.close();
					}
					stmt.close();
					con.close();
			}
			}
		}catch(SQLException se){
			log.error("Exception occured in getErrorLog method "+se);
		}catch (Exception e){
			log.error("Exception occured in getErrorLog method "+e);
		}
	}
		
}
