package com.vin.socket.constant;


public interface DBConstant {
	//for Socket import interface
	//public String INSERT_IN_DATA="insert into  tlv_in_data (BYTECOUNT,DATARECORDID,DATAPACKET,RETURNSTATUS,MSG,PROCESSFLAG,ADDDATE) values(?,?,?,?,?,?,sysdate)";
	//public String SELECT_IN_DATA="select serialkey,DATARECORDID,DATAPACKET  from tlv_in_data where processflag in (?,?) and RETURNSTATUS=? and DATARECORDID =? order by serialkey";
	public String SELECT_IN_DATA="select serialkey,DATARECORDID,DATAPACKET  from tlv_in_data where processflag =? and RETURNSTATUS=? and DATARECORDID =? order by serialkey";
	public String UPDATE_IN_DATA="update tlv_in_data set PROCESSFLAG=?, PROCESSDATE =systimestamp, MSG=? where SERIALKEY=? and PROCESSFLAG=?";
	public String UPDATE_IN_PROCESS = "update tlv_in_data set PROCESSFLAG=?, PROCESSDATE =systimestamp where  PROCESSFLAG=? and DATARECORDID=?";
	public String INSERT_IN_DATA_HDR="insert into tlv_in_data_hdr (PR_SERIALKEY,DATARECORDID) values";
	
	/*****************************************************************NOTE*******************************************************************************
	 * for inserting extracted data from data_packet into import tables, insert query is dynamically generated through code 
	 * The java file name ImportDataParser and method is createInsertSql() used for it.
	 * In the method createInsertSql() we are getting specific table name from ImportParseTable.properties  
	 * with the help of IMPORT_PARSE_TABLE map variable of Config.java file that contains mapping of import interface name and table name.
	 *************************************************************************************************************************************************/
	
	//for Socket Data preparation Export interface
	/*public String SELECT_OUT_HEADER="select distinct TRANSMITLOGKEY from (select TRANSMITLOGKEY  from tlv_out_data_hdr where processflag=? and datarecordid=? order by serialkey)";
	public String INSERT_OUT_DATA="insert into tlv_out_data (TRANSMITLOGKEY,DATAPACKET,DATARECORDID) values (?,?,?)";
	public String UPDATE_OUT_HEADER="update tlv_out_data_hdr set PROCESSFLAG=?, PROCESSDATE=systimestamp, MSG=? where TRANSMITLOGKEY=? and processflag=?";
	
	// select query for preparing Data Packet from export staging tables
	public String  SELECT_OUT_1AN ="select datarecordid,sku,packsize,articleid,n_altsku,altsku,articlenameid,articlename from tlv_out_1an where transmitlogkey=?";
	public String  SELECT_OUT_1AD ="select datarecordid,sku,packkey from tlv_OUT_1AD where transmitlogkey=?";
	public String  SELECT_OUT_1XW ="select datarecordid,wavekey,wavetype,wavestatus,waveinfoid,modeofSort,n_shopgroup,shopgroup,n_consigneekey,consigneekey,priority,n_orderkey,orderkey,n_orderline,sku,qty from tlv_OUT_1XW where transmitlogkey=? order by wavekey,shopgroup,consigneekey,orderkey";
	public String  SELECT_OUT_1XU ="select datarecordid,wavekey,wavetype,wavestatus from tlv_OUT_1XU where transmitlogkey=?";
	public String  SELECT_OUT_1XS ="select datarecordid,wavekey,waveinfoid,n_shopgroup,shopgroup,n_consigneekey,consigneekey,n_orderkey,orderkey,n_orderline,sku,qtydiff from tlv_OUT_1XS where transmitlogkey=? order by wavekey,shopgroup,consigneekey,orderkey";
	public String  SELECT_OUT_12N ="select datarecordid,orderkey,sheetno,ordertypeid,ordertype,loadunitcodeidentifier,toteid,targetstationid,n_station,targetstation from tlv_OUT_12N where transmitlogkey=? order by targetstation";
	public String  SELECT_OUT_12X ="select datarecordid,ordernumber,sheetno,ordertypeid,ordertype,loadunitcodeidentifier,toteid,waveaffiliation,wavekey,shopgroup,n_consigneekey,consigneekey,n_orderkey,orderkey,n_orderline,sku,qty from tlv_OUT_12X where transmitlogkey=? order by wavekey,shopgroup,consigneekey,orderkey";
	public String  SELECT_OUT_1LL ="select datarecordid,wavekey,wavetype,wavestatus,lastloadunitid,shopgroup,n_usedloadunit from tlv_OUT_1LL where transmitlogkey=?";
	public String  SELECT_OUT_12D ="select datarecordid,ordernumber,sheetno from tlv_OUT_12D where transmitlogkey=?";
	
	//for Socket Export interface
	public String SELECT_ART_MST_HEADER="select distinct TRANSMITLOGKEY from (select TRANSMITLOGKEY  from tlv_out_data_hdr where processflag=? and datarecordid=? order by serialkey,TRANSMITLOGKEY) where rownum<101";
	//COUNT_ART_MST_HEADER is being used in two classes ExportSocketClient and ExportDataComposer
	public String COUNT_ART_MST_HEADER="select count(distinct TRANSMITLOGKEY)  from tlv_out_data_hdr where processflag in (?,?) and datarecordid=?";
	public String COUNT_ART_MST_DATA="select count(distinct TRANSMITLOGKEY)  from tlv_out_data where processflag in (?,?) and datarecordid=?";
	public String SELECT_ART_MST_DATA = "select transmitlogkey,DATAPACKET  from tlv_out_data where processflag=? and datarecordid=? and rownum<101 order by serialkey";
	public String SELECT_OUT_DATA="select * from (select transmitlogkey,DATAPACKET  from tlv_out_data where processflag=? and datarecordid=? order by serialkey) where rownum<2";
	public String UPDATE_OUT_DATA="update tlv_out_data set PROCESSFLAG=?,RETURNSTATUS=?,MSG=?,PROCESSDATE =systimestamp where processflag=? and transmitlogkey=? and datarecordid=?";
	public String UPDATE_ART_MST_DATA="update tlv_out_data set PROCESSFLAG=?,PROCESSDATE =systimestamp where processflag=? and datarecordid=?";*/
	
	//insert to error log table
	public String INSERT_TO_ERRORLOG="Insert into tl_ERROR_LOG (PROGRAMNAME, ERRORKEY, ERRORMESSAGE,EMAIL_ALERT) Values (?, ?, ?, ?)";
	
	//for sending emails for error messages
	public  String GET_ERROR_LOG="select SERIALKEY,WHSEID,PROGRAMNAME,ERRORMESSAGE from tl_ERROR_LOG where EMAIL_ALERT='N' and rownum<11";
	public  String UPDT_ERROR_LOG="update tl_ERROR_LOG set EMAIL_ALERT='Y' where SERIALKEY=?";
	
	/*//validate 12X sql
	public  String SELECT_WAVEKEY_12X="select distinct wavekey from tlv_out_12x where transmitlogkey=? order by wavekey";
	public  String SELECT_CONSKEY_12X="select distinct consigneekey,n_consigneekey from tlv_out_12x where transmitlogkey=? and wavekey=? order by consigneekey";
	public  String SELECT_ORDERKEY_12X="select distinct orderkey,n_orderkey from tlv_out_12x where transmitlogkey=? and wavekey=? and consigneekey=? order by orderkey";
	public  String SELECT_SKU_12X="select distinct sku,n_orderline from tlv_out_12x where  transmitlogkey=? and wavekey=? and consigneekey=? and orderkey=? order by sku";

	//validate Wave new and update sql // here table name is dynamically updated by concatenating its respective data record id.
	public  String SELECT_WAVEKEY="select distinct wavekey from tlv_out_ where transmitlogkey=? order by wavekey";
	public  String SELECT_SHOPGROUP="select distinct shopgroup, n_shopgroup from tlv_out_ where transmitlogkey=? and wavekey=? order by shopgroup";
	public  String SELECT_CONSKEY="select distinct consigneekey,n_consigneekey from tlv_out_ where transmitlogkey=? and wavekey=? and shopgroup=? order by consigneekey";
	public  String SELECT_ORDERKEY="select distinct orderkey,n_orderkey from tlv_out_ where transmitlogkey=? and wavekey=? and shopgroup=? and consigneekey=? order by orderkey";
	public  String SELECT_SKU="select distinct sku,n_orderline from tlv_out_ where  transmitlogkey=? and wavekey=? and shopgroup=? and consigneekey=? and orderkey=? order by sku";
	
	//validate 12N sql
	public  String SELECT_TARGETSTATION_12N="select distinct targetstation,n_station from tlv_out_12N where transmitlogkey=? order by targetstation";*/
}
