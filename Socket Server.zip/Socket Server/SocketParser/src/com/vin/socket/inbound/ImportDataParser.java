package com.vin.socket.inbound;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.vin.socket.config.Config;
import com.vin.socket.constant.ApplicationConstant;
import com.vin.socket.constant.DBConstant;
import com.vin.socket.util.Util;

public class ImportDataParser implements Runnable {

	/**
	 * @param args
	 */
	private static Logger log = Logger.getLogger(ImportDataParser.class);
	
	String dri=null;
	
	public ImportDataParser(){}
	
	public ImportDataParser(String dri){
		this.dri= dri;
	}
	
	public  void run(){
		Connection con=null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		String errorMsg=null;
		String emailStatus="N";
		try {
			int i=1;
			con = Util.getConnection();
			while(true){
				if(i>100){
					con = Util.getConnection();
					i=0;
				}
			if(null!=con){
			    String serialKey=null;
			    errorMsg= this.updateTlInData(dri, ApplicationConstant.IN_PROCESS, ApplicationConstant.ZERO,con);
			    //sql:select serialkey,DATARECORDID,DATAPACKET  from tl_in_data where processflag =? and RETURNSTATUS=? and DATARECORDID =? order by serialkey
			    stmt = con.prepareStatement(DBConstant.SELECT_IN_DATA);
			    stmt.setString(1, ApplicationConstant.IN_PROCESS);
			    stmt.setString(2, ApplicationConstant.STATUS_00);
				stmt.setString(3, dri);
				rSet = stmt.executeQuery();
				while (rSet.next() && null==errorMsg) {
			    	HashMap<String,String> map=new HashMap<String,String>();
			    	serialKey=rSet.getString(1);
			    	map.put(ApplicationConstant.SERIALKEY,  serialKey);
			    	map.put(ApplicationConstant.DATAPACKET,  rSet.getString(3));
			    	map.put(ApplicationConstant.DRI,  dri);
			    	LinkedHashMap<String,Object> packetMap=(LinkedHashMap<String,Object>)parseDataPacket(map);
			    	if(null!=packetMap){
			    	errorMsg=(String) packetMap.get(ApplicationConstant.ERROR);
			    	if(null==errorMsg){
			    		HashMap<String,Object> dataMap=createInsertSql(packetMap);
			    		errorMsg=(String) dataMap.get(ApplicationConstant.ERROR);
			    		if(null==errorMsg){
			    			HashMap<String,String> listMap=insertDataHdrSql(serialKey,dri);
			    			errorMsg=listMap.get(ApplicationConstant.ERROR);
			    			if(null==errorMsg){
			    				String headInsert=listMap.get(ApplicationConstant.DATA);
			    				ArrayList<String>list=(ArrayList<String>) dataMap.get(ApplicationConstant.DATA);
						    	if(null!=headInsert && null!=list && list.size()>0){
						    		list.add(headInsert);
						    		errorMsg=insertDataDetail(list,dri,serialKey,con);
						    	}else{
						    		errorMsg=ApplicationConstant.IMPORT_EXCEPTION_MSG.replace(ApplicationConstant.PARAM_1, dri).replace(ApplicationConstant.PARAM_2, serialKey);
						    	}
								if(null==errorMsg){
									updateStageHead(serialKey,ApplicationConstant.SUCCESS,ApplicationConstant.SUCCESS_MSG,con);
								}
			    			}
			    		}
			    	}
				}
			}
			    if(null!=errorMsg){
			    	updateStageHead(serialKey,ApplicationConstant.ERROR,errorMsg,con);
			    	if(Config.SEND_JALERT.equals("Y")){
						String errMsg = "<i>Attention</i><br><br>";
						errMsg += "An Exception occured in warehouse for serialkey :"+serialKey+" and dri "+dri+" "+Config.INSTANCE_NAME ;
						errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
						errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
						Util.SendMailSSL(Config.EMAIL_TO, "Import: Exception occured while DataPacket Parsing", errMsg);
						emailStatus="Y";
						}
			    	Util.insertToErrorLog(dri,serialKey,errorMsg,emailStatus);
			    }
			    errorMsg=null;
			}
			if(null!=con){
				if(null!=rSet){
					rSet.close();
				}
			stmt.close();
			if(i==100){
				log.info("DB connection is reset");
				con.close();
				con=null;
			}
			}
			Thread.sleep(1000);
			i++;
		}
		} catch (SQLException sqlException) {
			errorMsg=sqlException.toString();
			log.error("Exception occured in processDataPacket method while processing data packet "+sqlException.toString());
		} catch(Exception e){
			e.printStackTrace();
			errorMsg=e.toString();
			log.error("Exception occured in processDataPacket method while processing data packet "+e.toString());
		}
		if(null!=errorMsg){
		   	if(Config.SEND_JALERT.equals("Y")){
				String errMsg = "<i>Attention</i><br><br>";
				errMsg += "An Exception occured in warehouse :"+Config.INSTANCE_NAME ;
				errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
				errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
				Util.SendMailSSL(Config.EMAIL_TO, "Import: Exception occured while DataPacket Parsing", errMsg);
				emailStatus="Y";
				}
		   	Util.insertToErrorLog("ImportDataParser","Import: Exception occured while DataPacket Parsing",errorMsg,emailStatus);
		}
	}
	
	private static Map<String,Object> parseDataPacket(HashMap<String,String> map){
		LinkedHashMap<String,String> dataMap=new LinkedHashMap<String, String>();
		LinkedHashMap<String,Object> packetMap=new LinkedHashMap<String,Object>();
		String errorMsg=null;
		String dri=null;
		String serialKey=null;
		String dataPacket=null;
		try{
		serialKey=map.get(ApplicationConstant.SERIALKEY);
		dataPacket=map.get(ApplicationConstant.DATAPACKET);
		dri=map.get(ApplicationConstant.DRI);
		String template=Config.IMPORT_PARSE_TEMPLATE.get(dri);
		String tempArr[]=template.split(ApplicationConstant.COMMA);
		for(String index:tempArr){
			int i=1;
			if(!index.contains(ApplicationConstant.LOOP)){
			String[] indexArr=index.split(Pattern.quote(ApplicationConstant.ASTRICK) );
			dataMap.put(ApplicationConstant.DATA+ApplicationConstant.ZERO, serialKey);
			for(String inde:indexArr){
				if(inde.contains(ApplicationConstant.DASH)){
					inde=dataMap.get(ApplicationConstant.DATA+ApplicationConstant.LENGTH+(i-1));
					String data=dataPacket.substring(0,Integer.parseInt(inde));
					dataMap.put(ApplicationConstant.DATA+i, data);
					dataPacket=dataPacket.substring(Integer.parseInt(inde));
				}else{
					if(inde.contains(ApplicationConstant.LENGTH)){
						String [] lenStr=inde.split(ApplicationConstant.UNDERSCORE);
						inde=lenStr[0];
						String data=dataPacket.substring(0,Integer.parseInt(inde));
						dataMap.put(ApplicationConstant.DATA+ApplicationConstant.LENGTH+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(inde));
					}else{
						String data=dataPacket.substring(0,Integer.parseInt(inde));
						dataMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(inde));
					}
				}
				i++;
			}
		}
		}
		if(null!=tempArr && tempArr.length>1){
		String []loop=template.substring(template.indexOf(ApplicationConstant.LOOP)).replace(ApplicationConstant.LOOP+ApplicationConstant.ASTRICK, ApplicationConstant.EMPTYSTRING) .split(ApplicationConstant.COMMA);
		if(null!=loop && loop.length<4 ){
		String loop1=loop[0];
		String loop2=loop[1];
		String loop3=loop[2];
		String [] loopArr1=loop1.split(Pattern.quote(ApplicationConstant.ASTRICK));
		String [] loopArr2=loop2.split(Pattern.quote(ApplicationConstant.ASTRICK));
		String [] loopArr3=loop3.split(Pattern.quote(ApplicationConstant.ASTRICK));
		int s1=Integer.parseInt(dataMap.get(ApplicationConstant.DATA+(dataMap.size()-1)));
		int i=0;
		LinkedHashMap<String,String> lpMap=new LinkedHashMap<String,String>();
		LinkedHashMap<String,String> myMap= null;
		ArrayList<LinkedHashMap<String,String>> list=new ArrayList<LinkedHashMap<String,String>>();
		while(s1>0){
			String dRow1="";
		for(String shop:loopArr1){
			if(shop.contains(ApplicationConstant.DASH)){
				shop=lpMap.get(ApplicationConstant.DATA+(i-1));
				dRow1=dRow1.concat(dataPacket.substring(0,Integer.parseInt(shop))).concat(ApplicationConstant.COMMA);
				String data=dataPacket.substring(0,Integer.parseInt(shop));
				lpMap.put(ApplicationConstant.DATA+i, data);
				dataPacket=dataPacket.substring(Integer.parseInt(shop));
			}else{
				if(shop.contains(ApplicationConstant.LENGTH)){
					String [] lenStr=shop.split(ApplicationConstant.UNDERSCORE);
					shop=lenStr[0];
					String data=dataPacket.substring(0,Integer.parseInt(shop));
					lpMap.put(ApplicationConstant.DATA+i, data);
					dataPacket=dataPacket.substring(Integer.parseInt(shop));
				}else{
					dRow1=dRow1.concat(dataPacket.substring(0,Integer.parseInt(shop))).concat(ApplicationConstant.COMMA);
					String data=dataPacket.substring(0,Integer.parseInt(shop));
					lpMap.put(ApplicationConstant.DATA+i, data);
					dataPacket=dataPacket.substring(Integer.parseInt(shop));
				}
			}
			i++;
		}
		dRow1=dRow1.substring(0,dRow1.length()-1);
		s1--;
		int s2=Integer.parseInt(lpMap.get(ApplicationConstant.DATA+(i-1)));
		while(s2>0){
			String dRow2="";
			for(String order:loopArr2){
				if(order.contains(ApplicationConstant.DASH)){
					order=lpMap.get(ApplicationConstant.DATA+(i-1));
					dRow2=dRow2.concat(dataPacket.substring(0,Integer.parseInt(order))).concat(ApplicationConstant.COMMA);
					String data=dataPacket.substring(0,Integer.parseInt(order));
					lpMap.put(ApplicationConstant.DATA+i, data);
					dataPacket=dataPacket.substring(Integer.parseInt(order));
				}else{
					if(order.contains(ApplicationConstant.LENGTH)){
						String [] lenStr=order.split(ApplicationConstant.UNDERSCORE);
						order=lenStr[0];
						String data=dataPacket.substring(0,Integer.parseInt(order));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(order));
					}else{
						dRow2=dRow2.concat(dataPacket.substring(0,Integer.parseInt(order))).concat(ApplicationConstant.COMMA);
						String data=dataPacket.substring(0,Integer.parseInt(order));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(order));
					}
				}
				i++;
			}
			dRow2=dRow2.substring(0,dRow2.length()-1);
			dRow2=dRow1.concat(ApplicationConstant.COMMA).concat(dRow2);
			s2--;
			int s3=Integer.parseInt(lpMap.get(ApplicationConstant.DATA+(i-1)));
			while(s3>0){
				String dRow3="";
				for(String article:loopArr3){
					if(article.contains(ApplicationConstant.DASH)){
						article=lpMap.get(ApplicationConstant.DATA+(i-1));
						dRow3=dRow3.concat(dataPacket.substring(0,Integer.parseInt(article))).concat(ApplicationConstant.COMMA);
						String data=dataPacket.substring(0,Integer.parseInt(article));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(article));
					}else{
						if(article.contains(ApplicationConstant.LENGTH)){
							String [] lenStr=article.split(ApplicationConstant.UNDERSCORE);
							article=lenStr[0];
							String data=dataPacket.substring(0,Integer.parseInt(article));
							lpMap.put(ApplicationConstant.DATA+i, data);
							dataPacket=dataPacket.substring(Integer.parseInt(article));
						}else{
							dRow3=dRow3.concat(dataPacket.substring(0,Integer.parseInt(article))).concat(ApplicationConstant.COMMA);
							String data=dataPacket.substring(0,Integer.parseInt(article));
							lpMap.put(ApplicationConstant.DATA+i, data);
							dataPacket=dataPacket.substring(Integer.parseInt(article));
						}
					}
					i++;
				}
				dRow3=dRow3.substring(0,dRow3.length()-1);
				dRow3=dRow2.concat(ApplicationConstant.COMMA).concat(dRow3);
				s3--;
				myMap=new LinkedHashMap<String,String>();
				myMap.put(ApplicationConstant.LOOP, dRow3);
				list.add(myMap);
			}
		}
		}
		packetMap.put(ApplicationConstant.DETAIL, list);
		}else{
                /***************short and pack starts******************/
			
			String loop1=loop[0];
			String loop2=loop[1];
			String loop3=loop[2];
			String loop4=loop[3];
			String [] loopArr1=loop1.split(Pattern.quote(ApplicationConstant.ASTRICK));
			String [] loopArr2=loop2.split(Pattern.quote(ApplicationConstant.ASTRICK));
			String [] loopArr3=loop3.split(Pattern.quote(ApplicationConstant.ASTRICK));
			String [] loopArr4=loop4.split(Pattern.quote(ApplicationConstant.ASTRICK));
			int s1=Integer.parseInt(dataMap.get(ApplicationConstant.DATA+(dataMap.size()-1)));
			int i=0;
			LinkedHashMap<String,String> lpMap=new LinkedHashMap<String,String>();
			LinkedHashMap<String,String> myMap= null;
			ArrayList<LinkedHashMap<String,String>> list=new ArrayList<LinkedHashMap<String,String>>();
			while(s1>0){
				String dRow1="";
			for(String shop:loopArr1){
				if(shop.contains(ApplicationConstant.DASH)){
					shop=lpMap.get(ApplicationConstant.DATA+(i-3));
					dRow1=dRow1.concat(dataPacket.substring(0,Integer.parseInt(shop))).concat(ApplicationConstant.COMMA);
					String data=dataPacket.substring(0,Integer.parseInt(shop));
					lpMap.put(ApplicationConstant.DATA+i, data);
					dataPacket=dataPacket.substring(Integer.parseInt(shop));
				}else{
					if(shop.contains(ApplicationConstant.LENGTH)){
						String [] lenStr=shop.split(ApplicationConstant.UNDERSCORE);
						shop=lenStr[0];
						String data=dataPacket.substring(0,Integer.parseInt(shop));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(shop));
					}else{
						dRow1=dRow1.concat(dataPacket.substring(0,Integer.parseInt(shop))).concat(ApplicationConstant.COMMA);
						String data=dataPacket.substring(0,Integer.parseInt(shop));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(shop));
					}
				}
				i++;
			}
			dRow1=dRow1.substring(0,dRow1.length()-1);
			s1--;
			int s2=Integer.parseInt(lpMap.get(ApplicationConstant.DATA+(i-1)));
			while(s2>0){
				String dRow2="";
				for(String loadUnit:loopArr2){
					if(loadUnit.contains(ApplicationConstant.LENGTH)){
						String [] lenStr=loadUnit.split(ApplicationConstant.UNDERSCORE);
						loadUnit=lenStr[0];
						String data=dataPacket.substring(0,Integer.parseInt(loadUnit));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(loadUnit));
					}else{
						dRow2=dRow2.concat(dataPacket.substring(0,Integer.parseInt(loadUnit))).concat(ApplicationConstant.COMMA);
						String data=dataPacket.substring(0,Integer.parseInt(loadUnit));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(loadUnit));
					}
					i++;
				}
				dRow2=dRow2.substring(0,dRow2.length()-1);
				dRow2=dRow1.concat(ApplicationConstant.COMMA).concat(dRow2);
				s2--;
				int s3=Integer.parseInt(lpMap.get(ApplicationConstant.DATA+(i-1)));
				while(s3>0){
					String dRow3="";
					for(String order:loopArr3){
						if(order.contains(ApplicationConstant.DASH)){
							order=lpMap.get(ApplicationConstant.DATA+(i-2));
							dRow3=dRow3.concat(dataPacket.substring(0,Integer.parseInt(order))).concat(ApplicationConstant.COMMA);
							String data=dataPacket.substring(0,Integer.parseInt(order));
							lpMap.put(ApplicationConstant.DATA+i, data);
							dataPacket=dataPacket.substring(Integer.parseInt(order));
						}else{
							if(order.contains(ApplicationConstant.LENGTH)){
								String [] lenStr=order.split(ApplicationConstant.UNDERSCORE);
								order=lenStr[0];
								String data=dataPacket.substring(0,Integer.parseInt(order));
								lpMap.put(ApplicationConstant.DATA+i, data);
								dataPacket=dataPacket.substring(Integer.parseInt(order));
							}else{
								dRow3=dRow3.concat(dataPacket.substring(0,Integer.parseInt(order))).concat(ApplicationConstant.COMMA);
								String data=dataPacket.substring(0,Integer.parseInt(order));
								lpMap.put(ApplicationConstant.DATA+i, data);
								dataPacket=dataPacket.substring(Integer.parseInt(order));
							}
						}
						i++;
					}
					dRow3=dRow3.substring(0,dRow3.length()-1);
					dRow3=dRow2.concat(ApplicationConstant.COMMA).concat(dRow3);
					s3--;
					int s4=Integer.parseInt(lpMap.get(ApplicationConstant.DATA+(i-1)));
					while(s4>0){
						String dRow4="";
						for(String article:loopArr4){
							if(article.contains(ApplicationConstant.DASH)){
								article=lpMap.get(ApplicationConstant.DATA+(i-2));
								dRow4=dRow4.concat(dataPacket.substring(0,Integer.parseInt(article))).concat(ApplicationConstant.COMMA);
								String data=dataPacket.substring(0,Integer.parseInt(article));
								lpMap.put(ApplicationConstant.DATA+i, data);
								dataPacket=dataPacket.substring(Integer.parseInt(article));
							}else{
								if(article.contains(ApplicationConstant.LENGTH)){
									String [] lenStr=article.split(ApplicationConstant.UNDERSCORE);
									article=lenStr[0];
									String data=dataPacket.substring(0,Integer.parseInt(article));
									lpMap.put(ApplicationConstant.DATA+i, data);
									dataPacket=dataPacket.substring(Integer.parseInt(article));
								}else{
									dRow4=dRow4.concat(dataPacket.substring(0,Integer.parseInt(article))).concat(ApplicationConstant.COMMA);
									String data=dataPacket.substring(0,Integer.parseInt(article));
									lpMap.put(ApplicationConstant.DATA+i, data);
									dataPacket=dataPacket.substring(Integer.parseInt(article));
								}
							}
							i++;
						}
						dRow4=dRow4.substring(0,dRow4.length()-1);
						dRow4=dRow3.concat(ApplicationConstant.COMMA).concat(dRow4);
						s4--;
					myMap=new LinkedHashMap<String,String>();
					myMap.put(ApplicationConstant.LOOP, dRow4);
					list.add(myMap);
					}
				}
			}
			}
			packetMap.put(ApplicationConstant.DETAIL, list);
			/***************short and pack ends******************/
		}
		}
		
		Iterator<Map.Entry<String, String>> entries = dataMap.entrySet().iterator();
		while(entries.hasNext()){
			Map.Entry<String, String> entry = entries.next();
			if(entry.getKey().contains(ApplicationConstant.LENGTH)){
				entries.remove();
			}
		}
		}catch(Exception e){
			errorMsg=ApplicationConstant.IMPORT_EXCEPTION_MSG.replace(ApplicationConstant.PARAM_1, dri).replace(ApplicationConstant.PARAM_2, serialKey)+" "+ e.toString();
			log.error(errorMsg);
		}
		packetMap.put(ApplicationConstant.HEADER, dataMap);
		packetMap.put(ApplicationConstant.DRI, dri);
		packetMap.put(ApplicationConstant.ERROR, errorMsg);
		packetMap.put(ApplicationConstant.SERIALKEY, serialKey);
		return packetMap;
	}
	public static HashMap<String,Object> createInsertSql(LinkedHashMap<String,Object> map){
		LinkedHashMap<String,String> header=(LinkedHashMap<String, String>) map.get(ApplicationConstant.HEADER);
		ArrayList<LinkedHashMap<String,String>> detail=(ArrayList<LinkedHashMap<String, String>>) map.get(ApplicationConstant.DETAIL);
		HashMap<String,Object> dataMap=null;
		
		String serialKey=null;
		ArrayList<String> insertList=new ArrayList<String>();
		String errorMsg=null;
		String dri=null;
		try{
		String columnHead=null;
		String columnDetail=null;
		String HeaderValue="";
		dri=(String) map.get(ApplicationConstant.DRI);
		serialKey=(String) map.get(ApplicationConstant.SERIALKEY);
		Iterator<Map.Entry<String, String>> it = header.entrySet().iterator();
		while (it.hasNext()) {
		    Map.Entry<String, String> pair = it.next();
		    HeaderValue=HeaderValue.concat(ApplicationConstant.SINGLE_QUOTE.concat(pair.getValue()).concat(ApplicationConstant.SINGLE_QUOTE).concat(ApplicationConstant.COMMA));
		}
		HeaderValue=HeaderValue.substring(0,HeaderValue.length()-1);
		columnHead=Config.IMPORT_COLUMN_MAP.get(dri+ApplicationConstant.HEADER);
		if(null!=detail && detail.size()>0){
		columnDetail=Config.IMPORT_COLUMN_MAP.get(dri+ApplicationConstant.DETAIL);
		String column=columnHead.concat(ApplicationConstant.COMMA).concat(columnDetail);
		for(LinkedHashMap<String,String> linkedMap:detail){
			StringBuilder insertSql=new StringBuilder();
			Iterator<Map.Entry<String, String>> itr = linkedMap.entrySet().iterator();
			while (itr.hasNext()) {
			    Map.Entry<String, String> pair = itr.next();
			    String row=pair.getValue();
			    String [] data=row.split(ApplicationConstant.COMMA);
			    String detailVal="";
			    for(String detailValue:data){
			    	detailVal=detailVal.concat(ApplicationConstant.SINGLE_QUOTE.concat(detailValue).concat(ApplicationConstant.SINGLE_QUOTE).concat(ApplicationConstant.COMMA));
			    }
			    detailVal=detailVal.substring(0,detailVal.length()-1);
			    insertSql=insertSql.append(ApplicationConstant.INSERT_IN_TO).append(Config.IMPORT_PARSE_TABLE.get(dri)).append(ApplicationConstant.START_BRACKET).append(column).append(ApplicationConstant.END_BRACKET).append(ApplicationConstant.VALUES).append(ApplicationConstant.START_BRACKET).append(HeaderValue).append(ApplicationConstant.COMMA).append(detailVal).append(ApplicationConstant.END_BRACKET);
			    insertList.add(new String(insertSql));
			}
		}
		}else{
			 StringBuilder insertSql=new StringBuilder();
			 insertSql=insertSql.append(ApplicationConstant.INSERT_IN_TO).append(Config.IMPORT_PARSE_TABLE.get(dri)).append(ApplicationConstant.START_BRACKET).append(columnHead).append(ApplicationConstant.END_BRACKET).append(ApplicationConstant.VALUES).append(ApplicationConstant.START_BRACKET).append(HeaderValue).append(ApplicationConstant.END_BRACKET);
			 insertList.add(new String(insertSql));
		}
		}catch(Exception e){
			errorMsg=ApplicationConstant.IMPORT_EXCEPTION_MSG.replace(ApplicationConstant.PARAM_1, dri).replace(ApplicationConstant.PARAM_2, serialKey)+" "+e.toString();
			log.error("Exception occured while creating insert query inside createInsertSql method "+e.toString());
		}
		dataMap=new HashMap<String,Object>();
		dataMap.put(ApplicationConstant.DATA, insertList);
		dataMap.put(ApplicationConstant.ERROR, errorMsg);
		return dataMap;
	}
	private static String insertDataDetail(ArrayList<String> list,String dri,String serialKey,Connection con){
		Statement stmt = null;
		String errorMsg=null;
		try {
			stmt=con.createStatement();
			for(String query:list){
				stmt.addBatch(query);
			}
			stmt.executeBatch();
			con.commit();
		} catch (SQLException sqlException) {
			errorMsg=ApplicationConstant.IMPORT_EXCEPTION_MSG.replace(ApplicationConstant.PARAM_1, dri).replace(ApplicationConstant.PARAM_2, serialKey)+" "+sqlException.toString();
			log.error(errorMsg);
			sqlException.printStackTrace();
		}
		catch(Exception e){
			errorMsg=ApplicationConstant.IMPORT_EXCEPTION_MSG.replace(ApplicationConstant.PARAM_1, dri).replace(ApplicationConstant.PARAM_2, serialKey)+" "+e.toString();
			log.error(errorMsg);
		}finally {
			try {
				if(null!=con){
					stmt.close();
				}
			} catch (SQLException sqlException) {
				errorMsg=ApplicationConstant.IMPORT_EXCEPTION_MSG.replace(ApplicationConstant.PARAM_1, dri).replace(ApplicationConstant.PARAM_2, serialKey)+" "+sqlException.toString();
				log.error(errorMsg);
			}
		}
		return errorMsg;
	}
	private static void updateStageHead(String serialKey,String pFlag,String message,Connection con ){
		PreparedStatement pStmt = null;
		try {
			//sql :"update tl_in_data set PROCESSFLAG=?, PROCESSDATE =systimestamp, MSG=? where SERIALKEY=? and PROCESSFLAG=?";
			pStmt=con.prepareStatement(DBConstant.UPDATE_IN_DATA);
			pStmt.setString(1, pFlag);//processflag=9 for success and 7 for error
			pStmt.setString(2, message);//msg
			pStmt.setString(3, serialKey);//serialkey
			if(pFlag.equals(ApplicationConstant.IN_PROCESS)){
				pStmt.setString(4, ApplicationConstant.ZERO);//processflag=0
			}else{
				pStmt.setString(4, ApplicationConstant.IN_PROCESS);//processflag=5
			}
			pStmt.executeUpdate();
			con.commit();
		} catch (SQLException sqlException) {
			log.error("Exception occured in updateStageHead method while executing query "+DBConstant.UPDATE_IN_DATA+sqlException.toString());
		} finally {
			try {
				if(null!=con){
					pStmt.close();
				}
				
			} catch (SQLException sqlException) {
				log.error("Exception occured in updateStageHead method while executing query "+DBConstant.UPDATE_IN_DATA+sqlException.toString());
			}
		}
		
	}
	private static HashMap<String,String> insertDataHdrSql(String serialKey,String dri){
		String headInsert =null;
		String errorMsg=null;
		HashMap<String,String> map=null;
		try {
			headInsert = DBConstant.INSERT_IN_DATA_HDR
					.concat(ApplicationConstant.START_BRACKET)
					.concat(ApplicationConstant.SINGLE_QUOTE).concat(serialKey).concat(ApplicationConstant.SINGLE_QUOTE).concat(ApplicationConstant.COMMA)
					.concat(ApplicationConstant.SINGLE_QUOTE).concat(dri).concat(ApplicationConstant.SINGLE_QUOTE)
					.concat(ApplicationConstant.END_BRACKET);
		} catch(Exception e){
			headInsert=null;
			errorMsg=ApplicationConstant.IMPORT_EXCEPTION_MSG.replace(ApplicationConstant.PARAM_1, dri).replace(ApplicationConstant.PARAM_2, serialKey)+" "+e.toString();
			log.error("Exception occured in insertDataHdr while inserting record for serailkey "+serialKey+" "+e.toString());
		}
		map=new HashMap<String,String>();
		map.put(ApplicationConstant.DATA, headInsert);
		map.put(ApplicationConstant.ERROR, errorMsg);
		return map;
	}
	private String updateTlInData(String dri,String pFlag1,String pFlag2,Connection con){
		PreparedStatement pStmt = null;
		String errorMsg=null;
		try {
			//sql :"update tlv_in_data set PROCESSFLAG=?, PROCESSDATE =systimestamp where  PROCESSFLAG=? and dri=?";
			pStmt=con.prepareStatement(DBConstant.UPDATE_IN_PROCESS);
			pStmt.setString(1, pFlag1);
			pStmt.setString(2, pFlag2);
			pStmt.setString(3, dri);
			pStmt.executeUpdate();
			con.commit();
		} catch (SQLException sqlException) {
			errorMsg="Exception occured in updateTlInData method while executing query "+DBConstant.UPDATE_IN_PROCESS+sqlException.toString();
			log.error(errorMsg);
		} finally {
			try {
				if(null!=pStmt){
					pStmt.close();
				}
				
			} catch (SQLException sqlException) {
				errorMsg=sqlException.toString();
					try {
						if(null!=pStmt){
							pStmt.close();
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						errorMsg=e.toString();
					}
				log.error("Exception occured in updateTlInData method while executing query "+DBConstant.UPDATE_IN_PROCESS+sqlException.toString());
			}
		}
		return errorMsg;
	}
}
