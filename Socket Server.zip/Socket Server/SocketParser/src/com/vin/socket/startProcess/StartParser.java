package com.vin.socket.startProcess;

import java.util.LinkedHashMap;
import java.util.Set;

import org.apache.log4j.Logger;

import com.vin.socket.config.Config;
import com.vin.socket.constant.ApplicationConstant;
import com.vin.socket.inbound.ImportDataParser;
import com.vin.socket.util.Util;

public class StartParser {

	private static Logger log = Logger.getLogger(StartParser.class);

	public static void main(String[] args) {
		try {
			if (Config.PARSER_FLAG.equals(ApplicationConstant.YES)) {
				LinkedHashMap<String, String> intMap = new LinkedHashMap<String, String>(Config.IMPORT_STATUS_INT_MAP);
				Set<String> intSet = intMap.keySet();
				for(String dri: intSet){
					ImportDataParser dataParser= new ImportDataParser(dri);
					Thread parserThread = new Thread(dataParser);
					parserThread.start();
				}
			}
			if(Config.SEND_DALERT.equals(ApplicationConstant.YES)){
				Util.processErrorLog();
			}
		} catch (Exception e) {
			String errorMsg=e.toString();
			String emailStatus = ApplicationConstant.NO;
			log.error("Exception occured in  StartParser main method "+ errorMsg);
			if (Config.SEND_JALERT.equals(ApplicationConstant.YES)) {
				String errMsg = "<i>Attention</i><br><br>";
				errMsg += "An Exception occured in warehouse:"+ Config.INSTANCE_NAME;
				errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
				errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
				Util.SendMailSSL(Config.EMAIL_TO,"Exception occured while Starting StartParser",errMsg);
				emailStatus = ApplicationConstant.YES;
			}
			Util.insertToErrorLog("StartParser", "Some thing went wrong",errorMsg, emailStatus);
		}

	}

}
