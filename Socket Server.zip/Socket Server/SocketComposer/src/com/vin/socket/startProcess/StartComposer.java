package com.vin.socket.startProcess;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.log4j.Logger;

import com.vin.socket.config.Config;
import com.vin.socket.constant.ApplicationConstant;
import com.vin.socket.outbound.ExportDataComposer;
import com.vin.socket.util.Util;

public class StartComposer {

	private static Logger log = Logger.getLogger(StartComposer.class);

	public static void main(String[] args) {
		try {
			if (Config.COMPOSER_FLAG.equals(ApplicationConstant.YES)) {
				ArrayList<String> arrayList = new ArrayList<String>(Arrays.asList(Config.EXPORT_STATUS_INT_MAP.get(ApplicationConstant.DRI).split(ApplicationConstant.COMMA))); 
				for(String driMapping: arrayList){
					String [] driArr=driMapping.split(ApplicationConstant.EQUAL);
					ExportDataComposer dataComposer = new ExportDataComposer(driArr[0]);
					Thread composerThread = new Thread(dataComposer);
					composerThread.start();
				}
			}
			if(Config.SEND_DALERT.equals(ApplicationConstant.YES)){
				Util.processErrorLog();
			}
		} catch (Exception e) {
			String errorMsg=e.toString();
			String emailStatus = ApplicationConstant.NO;
			log.error("Exception occured in  StartComposer main method "+ e.toString());
			if (Config.SEND_JALERT.equals(ApplicationConstant.YES)) {
				String errMsg = "<i>Attention</i><br><br>";
				errMsg += "An Exception occured in warehouse:"+ Config.INSTANCE_NAME;
				errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
				errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
				Util.SendMailSSL(Config.EMAIL_TO,"Export: Exception occured while creating datapacket",errMsg);
				emailStatus = ApplicationConstant.YES;
			}
			Util.insertToErrorLog("ExportDataComposer", "Some thing went wrong",errorMsg, emailStatus);
		}
	}

}
