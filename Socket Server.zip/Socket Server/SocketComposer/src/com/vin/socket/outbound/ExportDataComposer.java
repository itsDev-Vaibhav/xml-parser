package com.vin.socket.outbound;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.vin.socket.config.Config;
import com.vin.socket.constant.ApplicationConstant;
import com.vin.socket.constant.DBConstant;
import com.vin.socket.util.Util;

public class ExportDataComposer implements Runnable {
	private static Logger log = Logger.getLogger(ExportDataComposer.class);
	String dri=null;
	public ExportDataComposer(){}
	public ExportDataComposer(String dri){
		this.dri=dri;
	}
	
	public void run() {
		LinkedHashMap<String, String> colLenMap = Config.COLUMN_LENGTH_MAPPING;
		String errorMsg = null;
		String transmitLogKey = null;
		String emailStatus = ApplicationConstant.NO;
		ArrayList<String> tlKeyList = null;
		Connection con=null;
		try{
			LinkedHashMap<String, Object> tlKeyMap = null;
			if (null != colLenMap) {
				con = Util.getConnection();
				int i=0;
					if (!(dri.equals(ApplicationConstant.DRI_1A0)|| dri.equals(ApplicationConstant.DRI_1A1) || dri.equals(ApplicationConstant.DRI_1A9))) {
						while(true){
							if(i>100){
								con = Util.getConnection();
								i=0;
							}
						tlKeyMap = (LinkedHashMap<String, Object>) getTransID(dri, con);
						errorMsg = (String) tlKeyMap.get(ApplicationConstant.ERROR);
						if (null == errorMsg && tlKeyMap.size()>0) {
							tlKeyList = (ArrayList<String>) tlKeyMap.get(ApplicationConstant.DATA);
							for (String tlKey : tlKeyList) {
								transmitLogKey = tlKey;
								try {
									if (null != transmitLogKey) {
										HashMap<String, String> dataPacketMap = null;
										if (dri.equals(ApplicationConstant.DRI_1AN)) {
											dataPacketMap = this.getDataPacket_1AN(transmitLogKey, colLenMap,con); // get dataPacket for New article master data
										} else if (dri.equals(ApplicationConstant.DRI_1AD)) {
											dataPacketMap = this.getDataPacket_1AD(transmitLogKey, colLenMap,con); // get dataPacket for Deleting article master data
										} else if (dri.equals(ApplicationConstant.DRI_1XW)) {
											errorMsg =this.validateWave(transmitLogKey,dri,con);
											if(null==errorMsg){
												dataPacketMap = this.getDataPacket_1XW(transmitLogKey, colLenMap,con); // get dataPacket for Wave message � new
											}
										} else if (dri.equals(ApplicationConstant.DRI_1XU)) {
											dataPacketMap = this.getDataPacket_1XU(transmitLogKey, colLenMap,con); // get dataPacket for Wave update � activation
										} else if (dri.equals(ApplicationConstant.DRI_1XS)) {
											errorMsg =this.validateWave(transmitLogKey,dri,con);
											if(null==errorMsg){
												dataPacketMap = this.getDataPacket_1XS(transmitLogKey, colLenMap,con); // get dataPacket for Wave message update
											}
										} else if (dri.equals(ApplicationConstant.DRI_12N)) {
											errorMsg =this.validate12N(transmitLogKey,con);
											if(null==errorMsg){
												dataPacketMap = this.getDataPacket_12N(transmitLogKey, colLenMap,con); // get dataPacket for Transportation order data
											}
										} else if (dri.equals(ApplicationConstant.DRI_12X)) {
											errorMsg =this.validate12X(transmitLogKey,con);
											if(null==errorMsg){
												dataPacketMap = this.getDataPacket_12X(transmitLogKey, colLenMap,con); // get dataPacket for E-Commerce Multipiece and Shop Delivery
											}
										} else if (dri.equals(ApplicationConstant.DRI_1LL)) {
											dataPacketMap = this.getDataPacket_1LL(transmitLogKey, colLenMap,con); // get dataPacket for Last load unit of E-Commerce Multipiece and Shop Delivery
										} else if (dri.equals(ApplicationConstant.DRI_12D)) {
											dataPacketMap = this.getDataPacket_12D(transmitLogKey, colLenMap,con); // get dataPacket for Deleting order data
										}
										if (null != dataPacketMap) {
											errorMsg = dataPacketMap.get(ApplicationConstant.ERROR);
											if (null == errorMsg) {
												String dataPacket = dataPacketMap.get(ApplicationConstant.DATAPACKET);
												// if(null!=dataPacket)
												HashMap<String, String> byteCountMap = getByteCount(dataPacket); // get total byte count of data packet
												errorMsg = byteCountMap.get(ApplicationConstant.ERROR);
												if (null == errorMsg) {
													String byteCount = byteCountMap.get(ApplicationConstant.BYTECOUNT);
													dataPacket = byteCount.concat(dataPacket); // prepare complete data packet
													// dataPacket = ApplicationConstant.LF_CHARACTER.concat(byteCount).concat(dataPacket).concat(ApplicationConstant.CR_CHARACTER);
													// prepare complete data packet
													errorMsg = insertDataPacket(transmitLogKey,dataPacket, dri,con); // inserting dataPacket into stage table
												}
											}
											if (null != errorMsg) {
												updateHdrDataTable(transmitLogKey,ApplicationConstant.ERROR,errorMsg,ApplicationConstant.IN_PROCESS,con);
											} else {
												errorMsg = updateHdrDataTable(transmitLogKey,ApplicationConstant.SUCCESS,errorMsg,ApplicationConstant.IN_PROCESS,con);
											}
										}else{
											if(null!=errorMsg){
												updateHdrDataTable(transmitLogKey,ApplicationConstant.ERROR,errorMsg,ApplicationConstant.IN_PROCESS,con);
											}
										}
									}
								} catch (Exception e) {
									errorMsg = ApplicationConstant.DP_CREATION_EXCEPTION+ e.toString();
									log.error(errorMsg);
								}
								if (null != errorMsg) {
									if (Config.SEND_JALERT.equals(ApplicationConstant.YES)) {
										String errMsg = "<i>Attention</i><br><br>";
										errMsg += "An Exception occured in warehouse "+ Config.INSTANCE_NAME+ " for transmitlog key:"+ transmitLogKey+ " and dri: "+ dri;
										errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
										errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
										Util.SendMailSSL(Config.EMAIL_TO,"Export: Exception occured while creating/inserting datapacket to export tables",errMsg);
										emailStatus = ApplicationConstant.YES;
									}
									Util.insertToErrorLog(dri, transmitLogKey,errorMsg, emailStatus);
								}
							}
						}
						try{
							if(null!=con){
								if(i==100){
									log.info("DB Connection is reset");
									con.close();
									con=null;
								}
								i++;
							}
							Thread.sleep(5000);
						}catch(Exception ex){
							errorMsg="exception occurred while suspending thread/closing db connection: "+ex.toString();
							log.error(errorMsg);
						}
						if(null!=errorMsg){
							Util.insertToErrorLog("ExportDataComposer", "DataPacketComposingIssue",errorMsg, emailStatus);
						}
					}
				}
			} else {
				errorMsg = "Column Length mapping found null please check in ColumnLengthMapping.properties file and COLUMN_LENGTH_MAPPING map reference variable in Config.java file";
				log.error(errorMsg);
					if (Config.SEND_JALERT.equals(ApplicationConstant.YES)) {
						String errMsg = "<i>Attention</i><br><br>";
						errMsg += "An Exception occured in warehouse:"+ Config.INSTANCE_NAME;
						errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
						errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
						Util.SendMailSSL(Config.EMAIL_TO,"Export: Exception occured while creating datapacket",errMsg);
						emailStatus = ApplicationConstant.YES;
					}
					Util.insertToErrorLog("ExportDataComposer", "ColumnLengthIssue",errorMsg, emailStatus);
			}
		}catch(Exception e){
			errorMsg=e.toString();
			e.printStackTrace();
			log.info("Exception occured in ExportDataComposer  for dri : "+dri+" and exception is : "+errorMsg);
			if (Config.SEND_JALERT.equals(ApplicationConstant.YES)) {
				String errMsg = "<i>Attention</i><br><br>";
				errMsg += "An Exception occured in warehouse:"+ Config.INSTANCE_NAME;
				errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
				errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
				Util.SendMailSSL(Config.EMAIL_TO,"Export: Exception occured while creating datapacket",errMsg);
				emailStatus = ApplicationConstant.YES;
			}
			Util.insertToErrorLog("ExportDataComposer", "Some thing went wrong",errorMsg, emailStatus);
		}
	}

	private String insertDataPacket(String transmitLogKey,String dataPacket,String dri,Connection con){
		log.info("Start of insertDataPacket() method");
		PreparedStatement pStmt = null;
		String errorMsg=null;
		HashMap<String,Object> map=null;
		try {
			map=new HashMap<String,Object>();
			//sql: insert into tl_out_data (TRANSMITLOGKEY,DATAPACKET,DATARECORDID) values (?,?,?)
			pStmt = con.prepareStatement(DBConstant.INSERT_OUT_DATA);
			pStmt.setString(1, transmitLogKey);
			pStmt.setString(2, dataPacket);
			pStmt.setString(3, dri);
			int rowInserted=pStmt.executeUpdate();
			pStmt.close();
			if(!(rowInserted>0)){
				errorMsg=ApplicationConstant.ERROR_MSG_DATA_INSERT;
			}
		} catch (SQLException sqlException) {
			errorMsg=sqlException.toString();
			log.error("Exception occured in insertDataPacket method while inserting dataPacket in "+DBConstant.INSERT_OUT_DATA+" "+sqlException.toString());
		} 
		map.put(ApplicationConstant.ERROR, errorMsg);
		log.info("End of insertDataPacket() method");
		return errorMsg;
	}
	
	private Map<String,Object> getTransID(String dri, Connection con){
		HashMap<String,Object> map=null;
		PreparedStatement pStmt1 = null;
		ResultSet rSet1 = null;
		PreparedStatement pStmt2 = null;
		ResultSet rSet2 = null;
		PreparedStatement pStmt3 = null;
		ResultSet rSet3 = null;
		PreparedStatement pStmt4 = null;
		ResultSet rSet4 = null;
		String transmitLogKey=null;
		ArrayList<String> tlKeyList=null;
		String errorMsg=null;
		try {
			if(null!=con){
			tlKeyList=new ArrayList<String>();
			if(dri.equals(ApplicationConstant.DRI_1AN)){
				int count=getArtMstCount(dri,con);
				boolean flag=true;
				while(count>0 && flag){
					//sql:select distinct TRANSMITLOGKEY from (select TRANSMITLOGKEY  from tl_out_data_hdr where processflag=? and datarecordid=? order by serialkey,TRANSMITLOGKEY) where rownum<101
					pStmt1 = con.prepareStatement(DBConstant.SELECT_ART_MST_HEADER);
					pStmt1.setString(1, ApplicationConstant.ZERO);
					pStmt1.setString(2, dri);//
					rSet1 = pStmt1.executeQuery();
					if(!rSet1.isBeforeFirst()){
						flag=false;
						//sql:select distinct TRANSMITLOGKEY from (select TRANSMITLOGKEY  from tl_out_data_hdr where processflag=? and datarecordid=? order by serialkey,TRANSMITLOGKEY) where rownum<101
						pStmt2 = con.prepareStatement(DBConstant.SELECT_OUT_HEADER);
						pStmt2.setString(1, ApplicationConstant.IN_PROCESS);
						pStmt2.setString(2, dri);
						rSet2 = pStmt2.executeQuery();
						while (rSet2.next()) {
							transmitLogKey=rSet2.getString(1);
							tlKeyList.add(transmitLogKey);
						}
						pStmt2.close();
						rSet2.close();
					}else{
						while (rSet1.next()) {
							transmitLogKey=rSet1.getString(1);
							tlKeyList.add(transmitLogKey);
							errorMsg=updateHdrDataTable(transmitLogKey,	ApplicationConstant.IN_PROCESS,errorMsg,ApplicationConstant.ZERO,con);
						}
					}
					pStmt1.close();
					rSet1.close();
					count--;
				}
			}else{
				pStmt3 = con.prepareStatement(DBConstant.SELECT_OUT_HEADER);
				pStmt3.setString(1, ApplicationConstant.ZERO);
				pStmt3.setString(2, dri);
			    rSet3 = pStmt3.executeQuery();
			    if(!rSet3.isBeforeFirst()){
			    	pStmt4 = con.prepareStatement(DBConstant.SELECT_OUT_HEADER);
			    	pStmt4.setString(1, ApplicationConstant.IN_PROCESS);
			    	pStmt4.setString(2, dri);
				    rSet4 = pStmt4.executeQuery();
					while (rSet4.next()) {
						transmitLogKey=rSet4.getString(1);
						tlKeyList.add(transmitLogKey);
					}
					rSet4.close();
					pStmt4.close();
				}else{
			    while (rSet3.next()) {
			      map=new LinkedHashMap<String,Object>();
				  transmitLogKey=rSet3.getString(1);
				  tlKeyList.add(transmitLogKey);
				  errorMsg=updateHdrDataTable(transmitLogKey,ApplicationConstant.IN_PROCESS,errorMsg,ApplicationConstant.ZERO,con);
			    }
			    rSet3.close();
				pStmt3.close();
			}
		  }
		}
		} catch (SQLException sqlException) {
			errorMsg="Exception occured in getTransID method "+" transmitlog key "+transmitLogKey+" and dri: "+dri+" "+sqlException.toString();
			log.error(errorMsg);
		} catch(Exception e){
			errorMsg="Exception occured in getTransID method "+" transmitlog key "+transmitLogKey+" and dri: "+dri+" "+e.toString();
			log.error(errorMsg);
		}
		map=new LinkedHashMap<String,Object>();
		map.put(ApplicationConstant.DATA, tlKeyList);
		map.put(ApplicationConstant.ERROR, errorMsg);
		return map;
		}
	
	private int getArtMstCount(String dri, Connection con){
		int count=0;
		PreparedStatement pStmt = null;
		ResultSet rSet = null;
		try{
			// sql:select count(distinct TRANSMITLOGKEY)  from tlv_out_data_hdr where processflag in (?,?) and datarecordid=?
			pStmt = con.prepareStatement(DBConstant.COUNT_ART_MST_HEADER);
			pStmt.setString(1, ApplicationConstant.ZERO);
			pStmt.setString(2, ApplicationConstant.IN_PROCESS);
			pStmt.setString(3, dri);
		    rSet = pStmt.executeQuery();
		    if(rSet.next()){
		    	count=Integer.parseInt(rSet.getString(1));
		    }
		}catch(Exception e){
			e.printStackTrace();
			log.error("Exception occured in getArtMstCount method "+e.toString());
		}finally{
			if(null!=con){
		    	try {
					rSet.close();
					pStmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		    }
		}
		return count;
	}
	
	private HashMap<String,String> getByteCount(String dataPacket){
		String byteCount=null;
		HashMap<String,String> dataPacketMap=null;
		String errorMsg=null;
		try{
		dataPacketMap=new HashMap<String,String>();
		int totalByteCount=dataPacket.length()+7;
		String byteCountLength=String.valueOf(totalByteCount);
		int len=byteCountLength.length();
		int totalZero=7-len;
		String zero="";
		for(int i=0;i<totalZero;i++){
			zero=zero.concat(ApplicationConstant.ZERO);
		}
		byteCount=zero.concat(byteCountLength);
		}catch(Exception e){
			errorMsg=e.toString();
			log.error("Exception occured getByteCount method while creating byte count "+e.toString());
		}
		dataPacketMap.put(ApplicationConstant.BYTECOUNT, byteCount);
		dataPacketMap.put(ApplicationConstant.ERROR, errorMsg);
		return dataPacketMap;
	}
	
	private String updateHdrDataTable(String transmitLogKey,String aProcessFlag,String msg,String bProcessFlag,Connection con ){
		PreparedStatement pStmt = null;
		String errorMsg=null;
		try {
			//sql:update tl_out_data_hdr set PROCESSFLAG=?, PROCESSDATE=systimestamp, MSG=? where TRANSMITLOGKEY=? and processflag=?
			pStmt = con.prepareStatement(DBConstant.UPDATE_OUT_HEADER);
			pStmt.setString(1, aProcessFlag); //processFlag
			pStmt.setString(2, msg); // if success msg ="" else msg =error msg
			pStmt.setString(3, transmitLogKey); // transmitlogkey
			pStmt.setString(4, bProcessFlag); //processFlag =5
			pStmt.executeUpdate();
			pStmt.close();
		} catch (SQLException sqlException) {
			errorMsg="Exception occured in updateDataTable Method while executing query "+DBConstant.UPDATE_OUT_HEADER+" "+ sqlException.toString();
			log.error(errorMsg);
		} 
		return errorMsg;
	}
	
	private HashMap<String,String> getDataPacket_1AN(String transmitLogKey,HashMap<String,String> colLenMap,Connection con){
		PreparedStatement pStmt = null;
		ResultSet rSet = null;
		String preLoopData=null;
		String postLoopData=null;
		ArrayList<String> loopDataList=null;
		String dataPacket=null;
		HashMap<String,String> dataPacketMap=null;
		String errorMsg=null;
		String dataRecordId = null;
		String l_Sku = null;
		String l_Packsize = null;
		String sku = null;
		String packSize = null;
		String articleCodeID = null;
		String n_ArticleCode = null;
		String l_ArticleCode = null;
		String articleCode = null;
		String articleNameID = null;
		String l_ArticleName = null;
		String articleName = null;

		try{
			//sql:select datarecordid,sku,packkey,articleid,n_altsku,altsku,articlenameid,articlename from tl_out_1an where transmitlogkey=? 
			pStmt = con.prepareStatement(DBConstant.SELECT_OUT_1AN);
			pStmt.setString(1,transmitLogKey);
			rSet = pStmt.executeQuery();
			loopDataList=new ArrayList<String>();
			inner:
			while (rSet.next()) {
				dataRecordId = rSet.getString(1); 
				sku = rSet.getString(2);
				packSize = rSet.getString(3);
				articleCodeID = rSet.getString(4);
				n_ArticleCode = rSet.getString(5);
				articleCode = rSet.getString(6);
				articleNameID = rSet.getString(7);
				articleName = rSet.getString(8); 
				/**************Start of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				errorMsg=validateLength(dataRecordId, colLenMap.get(ApplicationConstant.LENGTH_DATARECORDID), transmitLogKey, ApplicationConstant.DRI_1AN,ApplicationConstant.LENGTH_DATARECORDID);
				HashMap<String,String> map_l_Sku = getLength(sku,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_SKU); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
				if(null!=errorMsg){
					if(null!=map_l_Sku.get(ApplicationConstant.ERROR)){
						errorMsg.concat(map_l_Sku.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=map_l_Sku.get(ApplicationConstant.ERROR);
				}
				l_Sku=map_l_Sku.get(ApplicationConstant.LENGTH_SKU);
				l_Packsize = colLenMap.get(ApplicationConstant.LENGTH_PACKSIZE);// for fixed length fields we use colLenMap map.
				HashMap<String,String> mapPacksize=getCompleteValue(packSize, colLenMap.get(ApplicationConstant.LENGTH_PACKSIZE), ApplicationConstant.DRI_1AN, transmitLogKey,ApplicationConstant.LENGTH_PACKSIZE);
				if(null!=errorMsg){
					if(null!=mapPacksize.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapPacksize.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapPacksize.get(ApplicationConstant.ERROR);
				}
				packSize=mapPacksize.get(ApplicationConstant.LENGTH_PACKSIZE);
				//
				if(null!=errorMsg){
					if(null!=validateLength(articleCodeID, colLenMap.get(ApplicationConstant.LENGTH_ARTICLEID), transmitLogKey, ApplicationConstant.DRI_1AN,ApplicationConstant.LENGTH_ARTICLEID)){
						errorMsg.concat(validateLength(articleCodeID, colLenMap.get(ApplicationConstant.LENGTH_ARTICLEID), transmitLogKey, ApplicationConstant.DRI_1AN,ApplicationConstant.LENGTH_ARTICLEID));
					}
				}else{
					errorMsg=validateLength(articleCodeID, colLenMap.get(ApplicationConstant.LENGTH_ARTICLEID), transmitLogKey, ApplicationConstant.DRI_1AN,ApplicationConstant.LENGTH_ARTICLEID);
				}
				/*if(n_ArticleCode.equals(ApplicationConstant.ZERO) || n_ArticleCode.equals(ApplicationConstant.ZERO+ApplicationConstant.ZERO)){
					articleCode="    ";
				}*/
				HashMap<String,String> mapArticleCode=getCompleteValue(n_ArticleCode, colLenMap.get(ApplicationConstant.LENGTH_N_ARTICLECODE), ApplicationConstant.DRI_1AN, transmitLogKey,ApplicationConstant.LENGTH_N_ARTICLECODE);
				if(null!=errorMsg){
					if(null!=mapArticleCode.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapArticleCode.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapArticleCode.get(ApplicationConstant.ERROR);
				}
				n_ArticleCode=mapArticleCode.get(ApplicationConstant.LENGTH_N_ARTICLECODE);
				if(!(n_ArticleCode.equals(ApplicationConstant.ZERO) || n_ArticleCode.equals(ApplicationConstant.ZERO+ApplicationConstant.ZERO))){
					HashMap<String,String> map_l_ArticleCode = getLength(articleCode,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_ARTICLECODE); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
					if(null!=errorMsg){
						if(null!=map_l_ArticleCode.get(ApplicationConstant.ERROR)){
							errorMsg.concat(map_l_ArticleCode.get(ApplicationConstant.ERROR));
						}
					}else{
						errorMsg=map_l_ArticleCode.get(ApplicationConstant.ERROR);
					}
					l_ArticleCode=map_l_ArticleCode.get(ApplicationConstant.LENGTH_ARTICLECODE);
				}
				if(null!=errorMsg){
					if(null!=validateLength(articleNameID, colLenMap.get(ApplicationConstant.LENGTH_ARTICLENAMEID), transmitLogKey, ApplicationConstant.DRI_1AN,ApplicationConstant.LENGTH_ARTICLENAMEID)){
						errorMsg.concat(validateLength(articleNameID, colLenMap.get(ApplicationConstant.LENGTH_ARTICLENAMEID), transmitLogKey, ApplicationConstant.DRI_1AN,ApplicationConstant.LENGTH_ARTICLENAMEID));
					}
				}else{
					errorMsg=validateLength(articleNameID, colLenMap.get(ApplicationConstant.LENGTH_ARTICLENAMEID), transmitLogKey, ApplicationConstant.DRI_1AN,ApplicationConstant.LENGTH_ARTICLENAMEID);
				}
				HashMap<String,String> map_l_ArticleName = getLength(articleName,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_ARTICLENAME); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
				if(null!=errorMsg){
					if(null!=map_l_ArticleName.get(ApplicationConstant.ERROR)){
						errorMsg.concat(map_l_ArticleName.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=map_l_ArticleName.get(ApplicationConstant.ERROR);
				}
				l_ArticleName=map_l_ArticleName.get(ApplicationConstant.LENGTH_ARTICLENAME);
				
				/**************End of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				if(null!=errorMsg){
					break inner;
				}
				//pre-loop data preparation
				preLoopData="";
				preLoopData=preLoopData.concat(dataRecordId).concat(l_Sku).concat(l_Packsize).concat(sku)
					.concat(packSize).concat(articleCodeID).concat(n_ArticleCode);
				//loop data preparation
				int loopCount= Integer.parseInt(n_ArticleCode);
				String loopData="";
				if(loopCount>0){
					loopData=loopData.concat(l_ArticleCode).concat(articleCode);
					loopDataList.add(loopData);
				}/*else{
					loopData=loopData.concat(l_ArticleCode).concat(articleCode);
					loopDataList.add(loopData);
				}*/ // as discussed with matja� hajdinjak
				//post-loop data preparation
				postLoopData="";
				postLoopData=postLoopData.concat(articleNameID).concat(l_ArticleName).concat(articleName);
			}
			String loopDatapacket="";
			if (null != loopDataList && null==errorMsg) {
				if (loopDataList.size() > 0) {
					for (String lstData : loopDataList) {
						loopDatapacket = loopDatapacket.concat(lstData);
					}
					dataPacket = preLoopData.concat(loopDatapacket).concat(postLoopData);
				} else {
					if(null!=preLoopData){
						dataPacket = preLoopData.concat(postLoopData);
					}else{
						errorMsg=ApplicationConstant.ERR_DET_MSG.replace(ApplicationConstant.PARAM_1, ApplicationConstant.DRI_1AN) +transmitLogKey;
					}
				}
			}
			rSet.close();
			pStmt.close();
			log.info("The data packet for Article Master Data is: "+dataPacket);
						
		}catch(Exception e){
			errorMsg=e.toString();
			log.error("Exception occured in getDataPacket_1AN method while executing query "+DBConstant.SELECT_OUT_1AN+" "+e.toString());
		}
		if(null==dataPacket){
			if(null==errorMsg){
			//msg:Unable to retrieve data packet for dri param1 and transmitlogkey param2, please check the data
			errorMsg=ApplicationConstant.ERROR_MSG_DATAPACKET.replace(ApplicationConstant.PARAM_1, ApplicationConstant.DRI_1AN).replace(ApplicationConstant.PARAM_2, transmitLogKey);
			}
		}
		dataPacketMap=new HashMap<String,String>();
		dataPacketMap.put(ApplicationConstant.DATAPACKET,dataPacket);
		dataPacketMap.put(ApplicationConstant.ERROR,errorMsg);
		log.info("End of getDataPacket_1AN() method");
		return dataPacketMap;
	}
	
	private HashMap<String, String> getDataPacket_1AD(String transmitLogKey,HashMap<String,String> colLenMap,Connection con) {
		PreparedStatement pStmt = null;
		ResultSet rSet = null;
		String dataPacket=null;
		HashMap<String,String> dataPacketMap=null;
		String dataRecordId = null;
		String l_sku=null;
		String l_packSize = null;
		String sku = null;
		String packSize = null;
		String errorMsg=null;
		try{
			//sql:select datarecordid,sku,packkey from TL_OUT_1AD where transmitlogkey=? 
			pStmt = con.prepareStatement(DBConstant.SELECT_OUT_1AD);
			pStmt.setString(1,transmitLogKey);
			rSet = pStmt.executeQuery();
			inner:
			while (rSet.next()) {
				dataRecordId = rSet.getString(1);
				sku = rSet.getString(2);
				packSize = rSet.getString(3);
				
				/**************Start of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				errorMsg=validateLength(dataRecordId, colLenMap.get(ApplicationConstant.LENGTH_DATARECORDID), transmitLogKey, ApplicationConstant.DRI_1AD,ApplicationConstant.LENGTH_DATARECORDID);
				HashMap<String,String> map_l_sku = getLength(sku,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_SKU); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
				if(null!=errorMsg){
					if(null!=map_l_sku.get(ApplicationConstant.ERROR)){
						errorMsg.concat(map_l_sku.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=map_l_sku.get(ApplicationConstant.ERROR);
				}
				l_sku=map_l_sku.get(ApplicationConstant.LENGTH_SKU);
				l_packSize = colLenMap.get(ApplicationConstant.LENGTH_PACKSIZE);// for fixed length fields we use colLenMap map.
				HashMap<String,String> mapPacksize=getCompleteValue(packSize, colLenMap.get(ApplicationConstant.LENGTH_PACKSIZE), ApplicationConstant.DRI_1AD, transmitLogKey,ApplicationConstant.LENGTH_PACKSIZE);
				if(null!=errorMsg){
					if(null!=mapPacksize.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapPacksize.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapPacksize.get(ApplicationConstant.ERROR);
				}
				packSize=mapPacksize.get(ApplicationConstant.LENGTH_PACKSIZE);
				/**************End of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				if(null!=errorMsg){
					break inner;
				}else{
					dataPacket=dataRecordId.concat(l_sku).concat(l_packSize).concat(sku).concat(packSize);
				}
				
			}
			rSet.close();
			pStmt.close();
			log.info("The data packet for Article Master Data Deletion is: "+dataPacket);
		}catch(Exception e){
			errorMsg=e.toString();
			log.error("Exception occured in getDataPacket_1AD method while executing query "+DBConstant.SELECT_OUT_1AD+" "+e.toString());
		}
		if(null==dataPacket){
			if(null==errorMsg){
			//msg:Unable to retrieve data packet for dri param1 and transmitlogkey param2, please check the data
			errorMsg=ApplicationConstant.ERROR_MSG_DATAPACKET.replace(ApplicationConstant.PARAM_1, ApplicationConstant.DRI_1AD).replace(ApplicationConstant.PARAM_2, transmitLogKey);
			}
		}
		dataPacketMap=new HashMap<String,String>();
		dataPacketMap.put(ApplicationConstant.DATAPACKET,dataPacket);
		dataPacketMap.put(ApplicationConstant.ERROR,errorMsg);
		log.info("End of getDataPacket_1AD() method");
		return dataPacketMap;
	}

	private HashMap<String, String> getDataPacket_1XW(String transmitLogKey,HashMap<String,String> colLenMap, Connection con) {
		PreparedStatement pStmt = null;
		ResultSet rSet = null;
		String preLoopData=null;
		String dataPacket=null;
		String errorMsg=null;
		HashMap<String,String> dataPacketMap=null;
		String dataRecordId =null;
		String l_WaveId =null;
		String l_WaveType =null;
		String l_WaveStatus =null;
		String waveKey =null;
		String waveType =null;
		String waveStatus =null;
		String waveInfoId =null;
		String l_ModeOfSort =null;
		String modeOfSort =null;
		String l_ShopGroup =null;
		String n_ShopGroup =null;
		String shopGroup =null;
		String n_ConsigneeKey =null;
		String l_ConsigneeKey =null;
		String consigneeKey =null;
		String priority =null;
		String n_OrderKey =null;
		String l_OrderKey =null;
		String orderkey =null;
		String n_OrderLine =null;
		String l_Sku =null;
		String sku =null;
		String qty =null;
		int loop1=0;
		int loop2=0;
		int loop3=0;
		int loop4=0;
		ArrayList<String> listLoop=new ArrayList<String>();
		ArrayList<String> listLoop1=new ArrayList<String>();
		ArrayList<String> listLoop2=new ArrayList<String>();
		ArrayList<String> listLoop3=new ArrayList<String>();
		ArrayList<String> listLoop4=new ArrayList<String>();
		
		try{
			//sql:select datarecordid,wavekey,wavetype,wavestatus,waveinfoid,modeofSort,n_shopgroup,shopgroup,n_consigneekey,consigneekey,priority,n_orderkey,orderkey,n_orderline,sku,qty from TL_OUT_1XW where transmitlogkey=? order by wavekey,shopgroup,consigneekey,orderkey 
			pStmt = con.prepareStatement(DBConstant.SELECT_OUT_1XW);
			pStmt.setString(1,transmitLogKey);
			rSet = pStmt.executeQuery();
			inner:
			while (rSet.next()) {
				dataRecordId =rSet.getString(1);
				waveKey =rSet.getString(2);
				waveType =rSet.getString(3);
				waveStatus =rSet.getString(4);
				waveInfoId =rSet.getString(5);
				modeOfSort =rSet.getString(6);
				n_ShopGroup =rSet.getString(7);
				//loop1 data
				shopGroup =rSet.getString(8);
				n_ConsigneeKey =rSet.getString(9);
				//loop2 data
				consigneeKey =rSet.getString(10);
				priority =rSet.getString(11);
				n_OrderKey =rSet.getString(12);
				//loop3 data
				orderkey =rSet.getString(13);
				n_OrderLine =rSet.getString(14);
				//loop4 data
				sku =rSet.getString(15); 
				qty =rSet.getString(16);	
				/**************Start of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				errorMsg=validateLength(dataRecordId, colLenMap.get(ApplicationConstant.LENGTH_DATARECORDID), transmitLogKey, ApplicationConstant.DRI_1XW,ApplicationConstant.LENGTH_DATARECORDID);
				l_WaveId =colLenMap.get(ApplicationConstant.LENGTH_WAVEKEY);// for fixed length fields we use colLenMap map.
				if(null!=errorMsg){
					if(null!=validateLength(waveKey, l_WaveId, transmitLogKey, ApplicationConstant.DRI_1XW,ApplicationConstant.LENGTH_WAVEKEY)){
						errorMsg.concat(validateLength(waveKey, l_WaveId, transmitLogKey, ApplicationConstant.DRI_1XW,ApplicationConstant.LENGTH_WAVEKEY));
					}
				}else{
					errorMsg=validateLength(waveKey, l_WaveId, transmitLogKey, ApplicationConstant.DRI_1XW,ApplicationConstant.LENGTH_WAVEKEY);
				}
				l_WaveType =colLenMap.get(ApplicationConstant.LENGTH_WAVETYPE);
				if(null!=errorMsg){
					if(null!=validateLength(waveType, l_WaveType, transmitLogKey, ApplicationConstant.DRI_1XW,ApplicationConstant.LENGTH_WAVETYPE)){
						errorMsg.concat(validateLength(waveType, l_WaveType, transmitLogKey, ApplicationConstant.DRI_1XW,ApplicationConstant.LENGTH_WAVETYPE));
					}
					
				}else{
					errorMsg=validateLength(waveType, l_WaveType, transmitLogKey, ApplicationConstant.DRI_1XW,ApplicationConstant.LENGTH_WAVETYPE);
				}
				l_WaveStatus =colLenMap.get(ApplicationConstant.LENGTH_WAVESTATUS);
				if(null!=errorMsg){
					if(null!=validateLength(waveStatus, l_WaveStatus, transmitLogKey, ApplicationConstant.DRI_1XW,ApplicationConstant.LENGTH_WAVESTATUS)){
						errorMsg.concat(validateLength(waveStatus, l_WaveStatus, transmitLogKey, ApplicationConstant.DRI_1XW,ApplicationConstant.LENGTH_WAVESTATUS));
					}
				}else{
					errorMsg=validateLength(waveStatus, l_WaveStatus, transmitLogKey, ApplicationConstant.DRI_1XW,ApplicationConstant.LENGTH_WAVESTATUS);
				}
				if(null!=errorMsg){
					if(null!=validateLength(waveInfoId, colLenMap.get(ApplicationConstant.LENGTH_WAVEINFOID), transmitLogKey, ApplicationConstant.DRI_1XW,ApplicationConstant.LENGTH_WAVEINFOID)){
						errorMsg.concat(validateLength(waveInfoId, colLenMap.get(ApplicationConstant.LENGTH_WAVEINFOID), transmitLogKey, ApplicationConstant.DRI_1XW,ApplicationConstant.LENGTH_WAVEINFOID));	
					}
				}else{
					errorMsg=validateLength(waveInfoId, colLenMap.get(ApplicationConstant.LENGTH_WAVEINFOID), transmitLogKey, ApplicationConstant.DRI_1XW,ApplicationConstant.LENGTH_WAVEINFOID);
				}
				l_ModeOfSort =colLenMap.get(ApplicationConstant.LENGTH_MODEOFSORT);
				HashMap<String,String> mapModeOfSort=getCompleteValue(modeOfSort, colLenMap.get(ApplicationConstant.LENGTH_MODEOFSORT), ApplicationConstant.DRI_1XW, transmitLogKey,ApplicationConstant.LENGTH_MODEOFSORT);
				if(null!=errorMsg){
					if(null!=mapModeOfSort.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapModeOfSort.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapModeOfSort.get(ApplicationConstant.ERROR);
				}
				modeOfSort=mapModeOfSort.get(ApplicationConstant.LENGTH_MODEOFSORT);
				HashMap<String,String> mapShopGroup=getCompleteValue(n_ShopGroup, colLenMap.get(ApplicationConstant.LENGTH_N_SHOPGROUP), ApplicationConstant.DRI_1XW, transmitLogKey,ApplicationConstant.LENGTH_N_SHOPGROUP);
				if(null!=errorMsg){
					if(null!=mapShopGroup.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapShopGroup.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapShopGroup.get(ApplicationConstant.ERROR);
				}
				n_ShopGroup=mapShopGroup.get(ApplicationConstant.LENGTH_N_SHOPGROUP);
				l_ShopGroup =colLenMap.get(ApplicationConstant.LENGTH_SHOPGROUP);
				HashMap<String,String> mapshopGroup=getCompleteValue(shopGroup, colLenMap.get(ApplicationConstant.LENGTH_SHOPGROUP), ApplicationConstant.DRI_1XW, transmitLogKey,ApplicationConstant.LENGTH_SHOPGROUP);
				if(null!=errorMsg){
					if(null!=mapshopGroup.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapshopGroup.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapshopGroup.get(ApplicationConstant.ERROR);
				}
				shopGroup=mapshopGroup.get(ApplicationConstant.LENGTH_SHOPGROUP);
				HashMap<String,String> mapConsigneeKey=getCompleteValue(n_ConsigneeKey, colLenMap.get(ApplicationConstant.LENGTH_N_CONSIGNEEKEY), ApplicationConstant.DRI_1XW, transmitLogKey,ApplicationConstant.LENGTH_N_CONSIGNEEKEY);
				if(null!=errorMsg){
					if(null!=mapConsigneeKey.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapConsigneeKey.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapConsigneeKey.get(ApplicationConstant.ERROR);
				}
				n_ConsigneeKey=mapConsigneeKey.get(ApplicationConstant.LENGTH_N_CONSIGNEEKEY);
				HashMap<String,String> map_l_ConsigneeKey = getLength(consigneeKey,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_CONSIGNEEKEY); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
				if(null!=errorMsg){
					if(null!=map_l_ConsigneeKey.get(ApplicationConstant.ERROR)){
						errorMsg.concat(map_l_ConsigneeKey.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=map_l_ConsigneeKey.get(ApplicationConstant.ERROR);
				}
				l_ConsigneeKey=map_l_ConsigneeKey.get(ApplicationConstant.LENGTH_CONSIGNEEKEY);
				HashMap<String,String> mapPriority=getCompleteValue(priority, colLenMap.get(ApplicationConstant.LENGTH_PRIORITY), ApplicationConstant.DRI_1XW, transmitLogKey,ApplicationConstant.LENGTH_PRIORITY);
				if(null!=errorMsg){
					if(null!=mapPriority.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapPriority.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapPriority.get(ApplicationConstant.ERROR);
				}
				priority=mapPriority.get(ApplicationConstant.LENGTH_PRIORITY);
				HashMap<String,String> mapOrderKey=getCompleteValue(n_OrderKey, colLenMap.get(ApplicationConstant.LENGTH_N_ORDERKEY), ApplicationConstant.DRI_1XW, transmitLogKey,ApplicationConstant.LENGTH_N_ORDERKEY);
				if(null!=errorMsg){
					if(null!=mapOrderKey.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapOrderKey.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapOrderKey.get(ApplicationConstant.ERROR);
				}
				n_OrderKey=mapOrderKey.get(ApplicationConstant.LENGTH_N_ORDERKEY);
				HashMap<String,String> map_l_OrderKey = getLength(orderkey,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_ORDERKEY); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
				if(null!=errorMsg){
					if(null!=map_l_OrderKey.get(ApplicationConstant.ERROR)){
						errorMsg.concat(map_l_OrderKey.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=map_l_OrderKey.get(ApplicationConstant.ERROR);
				}
				l_OrderKey=map_l_OrderKey.get(ApplicationConstant.LENGTH_ORDERKEY);
				HashMap<String,String> mapOrderLine=getCompleteValue(n_OrderLine, colLenMap.get(ApplicationConstant.LENGTH_N_ORDERLINE), ApplicationConstant.DRI_1XW, transmitLogKey,ApplicationConstant.LENGTH_N_ORDERLINE);
				if(null!=errorMsg){
					if(null!=mapOrderLine.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapOrderLine.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapOrderLine.get(ApplicationConstant.ERROR);
				}
				n_OrderLine=mapOrderLine.get(ApplicationConstant.LENGTH_N_ORDERLINE);
				//l_Sku =getLength(sku, ApplicationConstant.CHARCOUNT_02);
				HashMap<String,String> map_l_sku = getLength(sku,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_SKU); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
				if(null!=errorMsg){
					if(null!=map_l_sku.get(ApplicationConstant.ERROR)){
						errorMsg.concat(map_l_sku.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=map_l_sku.get(ApplicationConstant.ERROR);
				}
				l_Sku=map_l_sku.get(ApplicationConstant.LENGTH_SKU);
				HashMap<String,String> mapQty=getCompleteValue(qty, colLenMap.get(ApplicationConstant.LENGTH_QTY), ApplicationConstant.DRI_1XW, transmitLogKey,ApplicationConstant.LENGTH_QTY);
				if(null!=errorMsg){
					if(null!=mapQty.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapQty.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapQty.get(ApplicationConstant.ERROR);
				}
				qty=mapQty.get(ApplicationConstant.LENGTH_QTY);	
		
				/**************End of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				
				if(null!=errorMsg){
					break inner;
				}
				//pre-loop data preparation
				preLoopData=dataRecordId.concat(l_WaveId).concat(l_WaveType).concat(l_WaveStatus)
					.concat(waveKey).concat(waveType).concat(waveStatus).concat(waveInfoId)
					.concat(l_ModeOfSort).concat(modeOfSort).concat(l_ShopGroup).concat(n_ShopGroup);
				//loop data preparation
				 loop1=Integer.parseInt(n_ShopGroup);
				 loop2=Integer.parseInt(n_ConsigneeKey);
				 loop3=Integer.parseInt(n_OrderKey);
				 loop4=Integer.parseInt(n_OrderLine);
				 String data1="";
					if(loop1>0){
						if(listLoop1.size()>0){
							boolean flag1=true;
							inner1:
							for(String str:listLoop1){
								if(str.contains(shopGroup.concat(n_ConsigneeKey))){
									flag1=false;
									break inner1;
								}
							}
							if(flag1){
								listLoop1.clear();
								listLoop2.clear();
								listLoop3.clear();
								listLoop4.clear();
								data1=shopGroup.concat(n_ConsigneeKey);
								listLoop1.add(data1);
							}
						}else{
							data1=shopGroup.concat(n_ConsigneeKey);
							listLoop1.add(data1);
						}
						if(null!=data1 && data1.length()>0){
							listLoop2.clear();
						 }
						 String data2="";
						 if(loop2>0){
							 if(listLoop2.size()>0){
								 boolean flag1=true;
								 boolean flag2=true;
								 inner2:
										for(String str:listLoop2){
											if(str.contains(data1.concat(l_ConsigneeKey.concat(consigneeKey).concat(priority).concat(n_OrderKey)))){
												flag1=false;
												flag2=false;
												break inner2;
											}else if(str.contains(l_ConsigneeKey.concat(consigneeKey).concat(priority).concat(n_OrderKey))){
												flag2=false;
												break inner2;
											}
										}
								 if(flag1){
									 data2=data1.concat(l_ConsigneeKey.concat(consigneeKey).concat(priority).concat(n_OrderKey));
									 listLoop2.add(data2);
								 }else if(flag2){
									 data2=l_ConsigneeKey.concat(consigneeKey).concat(priority).concat(n_OrderKey);
									 listLoop2.add(data2);
								 }
							 }else{
								 data2=data1.concat(l_ConsigneeKey.concat(consigneeKey).concat(priority).concat(n_OrderKey));
								 listLoop2.add(data2);
							 }
							 if(null!=data2 && data2.length()>0){
								 listLoop3.clear();
							 }
							 String data3="";
							 if(loop3>0){								 
								 if(listLoop3.size()>0){
									 boolean flag1=true;
									 boolean flag2=true;
									 		inner3:
											for(String str:listLoop3){
												if(str.contains(data2.concat(l_OrderKey).concat(orderkey).concat(n_OrderLine))){
													flag1=false;
													flag2=false;
													break inner3;
												}else if(str.contains(l_OrderKey.concat(orderkey).concat(n_OrderLine))){
													flag2=false;
													break inner3;
												}
											}
									 if(flag1){
										data3=data2.concat(l_OrderKey).concat(orderkey).concat(n_OrderLine);
										listLoop3.add(data3);
									 }else if(flag2){
										 data3=l_OrderKey.concat(orderkey).concat(n_OrderLine);
										 listLoop3.add(data3);
									 }
								 }else{
									data3=data2.concat(l_OrderKey).concat(orderkey).concat(n_OrderLine);
									listLoop3.add(data3);
								 }
								 if(null!=data3 && data3.length()>0){
									 listLoop4.clear();
								 }
								 System.out.println("data3 is : "+data3+" and consigneekey is : "+ consigneeKey+" and orderkey is : "+ orderkey+" and number of order line : "+n_OrderLine +" and sku is : "+sku);
								String data4="";
								if(loop4>0){
									if(listLoop4.size()>0){
										boolean flag1=true;
										boolean flag2=true;
									inner4:
										for(String str:listLoop4){
											if(str.contains(data3.concat(l_Sku).concat(sku).concat(qty))){
												flag1=false;
												flag2=false;
												break inner4;
											}else if(str.contains(l_Sku.concat(sku).concat(qty))){
												flag2=false;
												break inner4;
											}
										}
										if(flag1){
											data4=data3.concat(l_Sku).concat(sku).concat(qty);
											listLoop4.add(data4);
										}else if(flag2){
											data4=l_Sku.concat(sku).concat(qty);
											listLoop4.add(data4);
										}
									}else{
										data4=data3.concat(l_Sku).concat(sku).concat(qty);
										listLoop4.add(data4);
									}
									listLoop.add(data4);
								}
							 }
						 }
					}
			}
			if (null == errorMsg && null!=listLoop) {
				String loopDataPacket = "";
				if (listLoop.size() > 0) {
					for (String data : listLoop) {
						loopDataPacket = loopDataPacket.concat(data);
					}
					dataPacket = "";
					if(null!=preLoopData){
						dataPacket = preLoopData.concat(loopDataPacket);
					}else{
						errorMsg=ApplicationConstant.ERR_DET_MSG.replace(ApplicationConstant.PARAM_1, ApplicationConstant.DRI_1XW) +transmitLogKey;
					}
					
				}
			}
			rSet.close();
			pStmt.close();
		}catch(Exception e){
			errorMsg=e.toString();
			log.error("Exception occured in getDataPacket_1XW method while executing query "+DBConstant.SELECT_OUT_1XW+" "+e.toString());
		}
		if(null==dataPacket){
			if(null==errorMsg){
			//msg:Unable to retrieve data packet for dri param1 and transmitlogkey param2, please check the data
			errorMsg=ApplicationConstant.ERROR_MSG_DATAPACKET.replace(ApplicationConstant.PARAM_1, ApplicationConstant.DRI_1XW).replace(ApplicationConstant.PARAM_2, transmitLogKey);
			}
		}
		log.info("The data packet for Wave Message New is: "+dataPacket);
		dataPacketMap=new HashMap<String,String>();
		dataPacketMap.put(ApplicationConstant.DATAPACKET,dataPacket);
		dataPacketMap.put(ApplicationConstant.ERROR,errorMsg);
		return dataPacketMap;
	}

	private HashMap<String, String> getDataPacket_1XU(String transmitLogKey,HashMap<String,String> colLenMap,Connection con) {
		PreparedStatement pStmt = null;
		ResultSet rSet = null;
		String dataPacket=null;
		String errorMsg=null;
		HashMap<String,String> dataPacketMap=null;
		String preLoopData=null;
		String dataRecordId = null;
		String l_WaveKey = null;
		String l_WaveType = null;
		String l_WaveStatus = null;
		String waveKey = null;
		String waveType = null;
		String waveStatus = null;
		try{
			//sql:select datarecordid,wavekey,wavetype,wavestatus from TL_OUT_1XU where transmitlogkey=?
			pStmt = con.prepareStatement(DBConstant.SELECT_OUT_1XU);
			pStmt.setString(1,transmitLogKey);
			rSet = pStmt.executeQuery();
			inner:
			while (rSet.next()) {
				dataRecordId = rSet.getString(1);
				waveKey = rSet.getString(2);
				waveType = rSet.getString(3);
				waveStatus = rSet.getString(4);
				
				/**************Start of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				errorMsg=validateLength(dataRecordId, colLenMap.get(ApplicationConstant.LENGTH_DATARECORDID), transmitLogKey, ApplicationConstant.DRI_1XU,ApplicationConstant.LENGTH_DATARECORDID);
				l_WaveKey =colLenMap.get(ApplicationConstant.LENGTH_WAVEKEY);// for fixed length fields we use colLenMap map.
				if(null!=errorMsg){
					if(null!=validateLength(waveKey, l_WaveKey, transmitLogKey, ApplicationConstant.DRI_1XU,ApplicationConstant.LENGTH_WAVEKEY)){
						errorMsg.concat(validateLength(waveKey, l_WaveKey, transmitLogKey, ApplicationConstant.DRI_1XU,ApplicationConstant.LENGTH_WAVEKEY));
					}
				}else{
					errorMsg=validateLength(waveKey, l_WaveKey, transmitLogKey, ApplicationConstant.DRI_1XU,ApplicationConstant.LENGTH_WAVEKEY);
				}
				l_WaveType =colLenMap.get(ApplicationConstant.LENGTH_WAVETYPE);
				if(null!=errorMsg){
					if(null!=validateLength(waveType, l_WaveType, transmitLogKey, ApplicationConstant.DRI_1XU,ApplicationConstant.LENGTH_WAVETYPE)){
						errorMsg.concat(validateLength(waveType, l_WaveType, transmitLogKey, ApplicationConstant.DRI_1XU,ApplicationConstant.LENGTH_WAVETYPE));
					}
					
				}else{
					errorMsg=validateLength(waveType, l_WaveType, transmitLogKey, ApplicationConstant.DRI_1XU,ApplicationConstant.LENGTH_WAVETYPE);
				}
				l_WaveStatus =colLenMap.get(ApplicationConstant.LENGTH_WAVESTATUS);
				if(null!=errorMsg){
					if(null!=validateLength(waveStatus, l_WaveStatus, transmitLogKey, ApplicationConstant.DRI_1XU,ApplicationConstant.LENGTH_WAVESTATUS)){
						errorMsg.concat(validateLength(waveStatus, l_WaveStatus, transmitLogKey, ApplicationConstant.DRI_1XU,ApplicationConstant.LENGTH_WAVESTATUS));
					}
				}else{
					errorMsg=validateLength(waveStatus, l_WaveStatus, transmitLogKey, ApplicationConstant.DRI_1XU,ApplicationConstant.LENGTH_WAVESTATUS);
				}
				/**************End of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				if(null!=errorMsg){
					break inner;
				}else{
					preLoopData=dataRecordId.concat(l_WaveKey).concat(l_WaveType)
							.concat(l_WaveStatus).concat(waveKey).concat(waveType).concat(waveStatus);
				}
			}
			if(null==errorMsg){
				dataPacket=preLoopData;
			}
			rSet.close();
			pStmt.close();
		}catch(Exception e){
			errorMsg=e.toString();
			log.error("Exception occured in getDataPacket_1XU method while executing query "+DBConstant.SELECT_OUT_1XU+" "+e.toString());
		}
		if(null==dataPacket){
			if(null==errorMsg){
			//msg:Unable to retrieve data packet for dri param1 and transmitlogkey param2, please check the data
			errorMsg=ApplicationConstant.ERROR_MSG_DATAPACKET.replace(ApplicationConstant.PARAM_1, ApplicationConstant.DRI_1XU).replace(ApplicationConstant.PARAM_2, transmitLogKey);
			}
		}
		log.info("The data packet is : "+dataPacket);
		dataPacketMap=new HashMap<String,String>();
		dataPacketMap.put(ApplicationConstant.DATAPACKET,dataPacket);
		dataPacketMap.put(ApplicationConstant.ERROR,errorMsg);
		return dataPacketMap;
	}

	private HashMap<String, String> getDataPacket_1XS(String transmitLogKey,HashMap<String,String> colLenMap,Connection con) {
		PreparedStatement pStmt = null;
		ResultSet rSet = null;
		String preLoopData=null;
		String dataPacket=null;
		String errorMsg=null;
		HashMap<String,String> dataPacketMap=null;
		String dataRecordId = null;
		String l_WaveKey = null;
		String waveKey = null;
		String waveInfoId = null;
		String l_ShopGroup = null;
		String n_ShopGroup = null;
		String shopGroup = null;
		String n_ConsigneeKey = null;
		String l_ConsigneeKey = null;
		String consigneeKey = null;
		String n_OrderKey = null;
		String l_OrderKey = null;
		String orderKey = null;
		String n_OrderLine = null;
		String l_Sku = null;
		String sku = null;
		String qtyDiff = null;
		int loop1=0;
		int loop2=0;
		int loop3=0;
		int loop4=0;
		ArrayList<String> listLoop=new ArrayList<String>();
		ArrayList<String> listLoop1=new ArrayList<String>();
		ArrayList<String> listLoop2=new ArrayList<String>();
		ArrayList<String> listLoop3=new ArrayList<String>();
		ArrayList<String> listLoop4=new ArrayList<String>();
		try{
			//sql:select datarecordid,wavekey,waveinfoid,n_shopgroup,shopgroup,n_consigneekey,consigneekey,n_orderkey,orderkey,n_orderline,sku,qtydiff from TL_OUT_1XS where transmitlogkey=? order by wavekey,shopgroup,consigneekey,orderkey 
			pStmt = con.prepareStatement(DBConstant.SELECT_OUT_1XS);
			pStmt.setString(1,transmitLogKey);
			rSet = pStmt.executeQuery();
			inner:
			while (rSet.next()) {
				dataRecordId = rSet.getString(1);
				waveKey = rSet.getString(2);
				waveInfoId = rSet.getString(3);
				n_ShopGroup = rSet.getString(4);
				//loop1 data
				shopGroup = rSet.getString(5);
				n_ConsigneeKey = rSet.getString(6);
				//loop2 data
				consigneeKey = rSet.getString(7);
				n_OrderKey = rSet.getString(8);
				//loop3 data
				orderKey = rSet.getString(9);
				n_OrderLine = rSet.getString(10);
				//loop4 data
				sku = rSet.getString(11);
				qtyDiff = rSet.getString(12);
				
				/**************Start of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				errorMsg=validateLength(dataRecordId, colLenMap.get(ApplicationConstant.LENGTH_DATARECORDID), transmitLogKey, ApplicationConstant.DRI_1XS,ApplicationConstant.LENGTH_DATARECORDID);
				l_WaveKey =colLenMap.get(ApplicationConstant.LENGTH_WAVEKEY);// for fixed length fields we use colLenMap map.
				if(null!=errorMsg){
					if(null!=validateLength(waveKey, l_WaveKey, transmitLogKey, ApplicationConstant.DRI_1XS,ApplicationConstant.LENGTH_WAVEKEY)){
						errorMsg.concat(validateLength(waveKey, l_WaveKey, transmitLogKey, ApplicationConstant.DRI_1XS,ApplicationConstant.LENGTH_WAVEKEY));
					}
				}else{
					errorMsg=validateLength(waveKey, l_WaveKey, transmitLogKey, ApplicationConstant.DRI_1XS,ApplicationConstant.LENGTH_WAVEKEY);
				}
				if(null!=errorMsg){
					if(null!=validateLength(waveInfoId, colLenMap.get(ApplicationConstant.LENGTH_WAVEINFOID), transmitLogKey, ApplicationConstant.DRI_1XS,ApplicationConstant.LENGTH_WAVEINFOID)){
						errorMsg.concat(validateLength(waveInfoId, colLenMap.get(ApplicationConstant.LENGTH_WAVEINFOID), transmitLogKey, ApplicationConstant.DRI_1XS,ApplicationConstant.LENGTH_WAVEINFOID));	
					}
				}else{
					errorMsg=validateLength(waveInfoId, colLenMap.get(ApplicationConstant.LENGTH_WAVEINFOID), transmitLogKey, ApplicationConstant.DRI_1XS,ApplicationConstant.LENGTH_WAVEINFOID);
				}
				l_ShopGroup =colLenMap.get(ApplicationConstant.LENGTH_SHOPGROUP);
				HashMap<String,String> mapSGroup=getCompleteValue(shopGroup, colLenMap.get(ApplicationConstant.LENGTH_SHOPGROUP), ApplicationConstant.DRI_1XS, transmitLogKey,ApplicationConstant.LENGTH_SHOPGROUP);
				if(null!=errorMsg){
					if(null!=mapSGroup.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapSGroup.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapSGroup.get(ApplicationConstant.ERROR);
				}
				shopGroup=mapSGroup.get(ApplicationConstant.LENGTH_SHOPGROUP);
				HashMap<String,String> mapShopGroup=getCompleteValue(n_ShopGroup, colLenMap.get(ApplicationConstant.LENGTH_N_SHOPGROUP), ApplicationConstant.DRI_1XS, transmitLogKey,ApplicationConstant.LENGTH_N_SHOPGROUP);
				if(null!=errorMsg){
					if(null!=mapShopGroup.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapShopGroup.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapShopGroup.get(ApplicationConstant.ERROR);
				}
				n_ShopGroup=mapShopGroup.get(ApplicationConstant.LENGTH_N_SHOPGROUP);
				HashMap<String,String> mapConsigneeKey=getCompleteValue(n_ConsigneeKey, colLenMap.get(ApplicationConstant.LENGTH_N_CONSIGNEEKEY), ApplicationConstant.DRI_1XS, transmitLogKey,ApplicationConstant.LENGTH_N_CONSIGNEEKEY);
				if(null!=errorMsg){
					if(null!=mapConsigneeKey.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapConsigneeKey.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapConsigneeKey.get(ApplicationConstant.ERROR);
				}
				n_ConsigneeKey=mapConsigneeKey.get(ApplicationConstant.LENGTH_N_CONSIGNEEKEY);
				HashMap<String,String> map_l_ConsigneeKey = getLength(consigneeKey,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_CONSIGNEEKEY); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
				if(null!=errorMsg){
					if(null!=map_l_ConsigneeKey.get(ApplicationConstant.ERROR)){
						errorMsg.concat(map_l_ConsigneeKey.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=map_l_ConsigneeKey.get(ApplicationConstant.ERROR);
				}
				l_ConsigneeKey=map_l_ConsigneeKey.get(ApplicationConstant.LENGTH_CONSIGNEEKEY);
				HashMap<String,String> mapOrderKey=getCompleteValue(n_OrderKey, colLenMap.get(ApplicationConstant.LENGTH_N_ORDERKEY), ApplicationConstant.DRI_1XS, transmitLogKey,ApplicationConstant.LENGTH_N_ORDERKEY);
				if(null!=errorMsg){
					if(null!=mapOrderKey.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapOrderKey.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapOrderKey.get(ApplicationConstant.ERROR);
				}
				n_OrderKey=mapOrderKey.get(ApplicationConstant.LENGTH_N_ORDERKEY);
				HashMap<String,String> map_l_OrderKey = getLength(orderKey,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_ORDERKEY); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
				if(null!=errorMsg){
					if(null!=map_l_OrderKey.get(ApplicationConstant.ERROR)){
						errorMsg.concat(map_l_OrderKey.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=map_l_OrderKey.get(ApplicationConstant.ERROR);
				}
				l_OrderKey=map_l_OrderKey.get(ApplicationConstant.LENGTH_ORDERKEY);
				HashMap<String,String> mapOrderLine=getCompleteValue(n_OrderLine, colLenMap.get(ApplicationConstant.LENGTH_N_ORDERLINE), ApplicationConstant.DRI_1XS, transmitLogKey,ApplicationConstant.LENGTH_N_ORDERLINE);
				if(null!=errorMsg){
					if(null!=mapOrderLine.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapOrderLine.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapOrderLine.get(ApplicationConstant.ERROR);
				}
				n_OrderLine=mapOrderLine.get(ApplicationConstant.LENGTH_N_ORDERLINE);
				HashMap<String,String> map_l_sku = getLength(sku,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_SKU); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
				if(null!=errorMsg){
					if(null!=map_l_sku.get(ApplicationConstant.ERROR)){
						errorMsg.concat(map_l_sku.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=map_l_sku.get(ApplicationConstant.ERROR);
				}
				l_Sku=map_l_sku.get(ApplicationConstant.LENGTH_SKU);
				HashMap<String,String> mapQty=getCompleteValue(qtyDiff, colLenMap.get(ApplicationConstant.LENGTH_QTY), ApplicationConstant.DRI_1XS, transmitLogKey,ApplicationConstant.LENGTH_QTY);
				if(null!=errorMsg){
					if(null!=mapQty.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapQty.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapQty.get(ApplicationConstant.ERROR);
				}
				qtyDiff=mapQty.get(ApplicationConstant.LENGTH_QTY);	
				/**************End of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				if(null!=errorMsg){
					break inner;
				}
				
				//pre-loop data preparation
				preLoopData=dataRecordId.concat(l_WaveKey).concat(waveKey).concat(waveInfoId)
					.concat(l_ShopGroup).concat(n_ShopGroup);
				//loop data preparation
				 loop1=Integer.parseInt(n_ShopGroup);
				 loop2=Integer.parseInt(n_ConsigneeKey);
				 loop3=Integer.parseInt(n_OrderKey);
				 loop4=Integer.parseInt(n_OrderLine);
				 String data1="";
					if(loop1>0){
						if(listLoop1.size()>0){
							boolean flag1=true;
							inner1:
							for(String str:listLoop1){
								if(str.contains(shopGroup.concat(n_ConsigneeKey))){
									flag1=false;
									break inner1;
								}
							}
							if(flag1){
								listLoop1.clear();
								listLoop2.clear();
								listLoop3.clear();
								listLoop4.clear();
								data1=shopGroup.concat(n_ConsigneeKey);
								listLoop1.add(data1);
							}
						}else{
							data1=shopGroup.concat(n_ConsigneeKey);
							listLoop1.add(data1);
						}
						if(null!=data1 && data1.length()>0){
							listLoop2.clear();
						 }
						 String data2="";
						 if(loop2>0){
							 if(listLoop2.size()>0){
								 boolean flag1=true;
								 boolean flag2=true;
								 inner2:
										for(String str:listLoop2){
											if(str.contains(data1.concat(l_ConsigneeKey.concat(consigneeKey).concat(n_OrderKey)))){
												flag1=false;
												flag2=false;
												break inner2;
											}else if(str.contains(l_ConsigneeKey.concat(consigneeKey).concat(n_OrderKey))){
												flag2=false;
												break inner2;
											}
										}
								 if(flag1){
									 data2=data1.concat(l_ConsigneeKey.concat(consigneeKey).concat(n_OrderKey));
									 listLoop2.add(data2);
								 }else if(flag2){
									 data2=l_ConsigneeKey.concat(consigneeKey).concat(n_OrderKey);
									 listLoop2.add(data2);
								 }
							 }else{
								 data2=data1.concat(l_ConsigneeKey.concat(consigneeKey).concat(n_OrderKey));
								 listLoop2.add(data2);
							 }
							 if(null!=data2 && data2.length()>0){
									listLoop3.clear();
							 }
							 String data3="";
							 if(loop3>0){	
								 if(listLoop3.size()>0){
									 boolean flag1=true;
									 boolean flag2=true;
									 		inner3:
											for(String str:listLoop3){
												if(str.contains(data2.concat(l_OrderKey.concat(orderKey).concat(n_OrderLine)))){
													flag1=false;
													flag2=false;
													break inner3;
												}else if(str.contains(l_OrderKey.concat(orderKey).concat(n_OrderLine))){
													flag2=false;
													break inner3;
												}
											}
									 if(flag1){
										data3=data2.concat(l_OrderKey.concat(orderKey).concat(n_OrderLine));
										listLoop3.add(data3);
									 }else if(flag2){
										 data3=l_OrderKey.concat(orderKey).concat(n_OrderLine);
										 listLoop3.add(data3);
									 }
								 }else{
									data3=data2.concat(l_OrderKey.concat(orderKey).concat(n_OrderLine));
									listLoop3.add(data3);
								 }
								 if(null!=data3 && data3.length()>0){
										listLoop4.clear();
								 }
								String data4="";
								if(loop4>0){
									if(listLoop4.size()>0){
										boolean flag1=true;
										boolean flag2=true;
									inner4:
										for(String str:listLoop4){
											if(str.contains(data3.concat(l_Sku.concat(sku).concat(qtyDiff)))){
												flag1=false;
												flag2=false;
												break inner4;
											}else if(str.contains(l_Sku.concat(sku).concat(qtyDiff))){
												flag2=false;
												break inner4;
											}
										}
										if(flag1){
											data4=data3.concat(l_Sku.concat(sku).concat(qtyDiff));
											listLoop4.add(data4);
										}else if(flag2){
											data4=l_Sku.concat(sku).concat(qtyDiff);
											listLoop4.add(data4);
										}
									}else{
										data4=data3.concat(l_Sku.concat(sku).concat(qtyDiff));
										listLoop4.add(data4);
									}
									listLoop.add(data4);
								}
							 }
						 }
					}
			}
			if (null == errorMsg) {
				String loopDataPacket = "";
				if (listLoop.size() > 0) {
					for (String data : listLoop) {
						loopDataPacket = loopDataPacket.concat(data);
					}
					dataPacket = "";
					if(null!=preLoopData){
						dataPacket = preLoopData.concat(loopDataPacket);
					}else{
						errorMsg=ApplicationConstant.ERR_DET_MSG.replace(ApplicationConstant.PARAM_1, ApplicationConstant.DRI_1XS) +transmitLogKey;
					}
				}
			}
			rSet.close();
			pStmt.close();
		}catch(Exception e){
			errorMsg=e.toString();
			log.error("Exception occured in getDataPacket_1XS method while executing query "+DBConstant.SELECT_OUT_1XS+" "+e.toString());
		}
		if(null==dataPacket){
			if(null==errorMsg){
				//msg:Unable to retrieve data packet for dri param1 and transmitlogkey param2, please check the data
				errorMsg=ApplicationConstant.ERROR_MSG_DATAPACKET.replace(ApplicationConstant.PARAM_1, ApplicationConstant.DRI_1XS).replace(ApplicationConstant.PARAM_2, transmitLogKey);
			}
		}
		log.info("The data packet is : "+dataPacket);
		dataPacketMap=new HashMap<String,String>();
		dataPacketMap.put(ApplicationConstant.DATAPACKET,dataPacket);
		dataPacketMap.put(ApplicationConstant.ERROR,errorMsg);
		return dataPacketMap;
	}

	private HashMap<String, String> getDataPacket_12N(String transmitLogKey,HashMap<String,String> colLenMap,Connection con) {
		PreparedStatement pStmt = null;
		ResultSet rSet = null;
		String preLoopData=null;
		ArrayList<String> loopDataList=null;
		String dataPacket=null;
		HashMap<String,String> dataPacketMap=null;
		String errorMsg=null;
		String dataRecordId = null;
		String l_OrderKey = null;
		String l_SheetNo = null;
		String orderKey = null;
		String sheetNo = null;
		String orderTypeId = null;
		String l_OrderType = null;
		String orderType = null;
		String loadUnitCodeIdentifier = null;
		String l_ToteId = null;
		String toteId=null;
		String targetStationId = null;
		String n_Station = null;
		String l_StationNo = null;
		String targetStation = null;
		try{
			//sql:select datarecordid,orderkey,sheetno,ordertypeid,ordertype,loadunitcodeidentifier,toteid,targetstationid,n_station,targetstation from TL_OUT_12N where transmitlogkey=? 
			pStmt = con.prepareStatement(DBConstant.SELECT_OUT_12N);
			pStmt.setString(1,transmitLogKey);
			rSet = pStmt.executeQuery();
			loopDataList=new ArrayList<String>();
			inner:
			while (rSet.next()) {
				dataRecordId = rSet.getString(1);
				orderKey = rSet.getString(2);
				sheetNo = rSet.getString(3);
				orderTypeId = rSet.getString(4);
				orderType = rSet.getString(5);
				loadUnitCodeIdentifier = rSet.getString(6);
				toteId=rSet.getString(7);
				targetStationId = rSet.getString(8);
				n_Station = rSet.getString(9);
				targetStation = rSet.getString(10);
				/**************Start of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				errorMsg=validateLength(dataRecordId, colLenMap.get(ApplicationConstant.LENGTH_DATARECORDID), transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_DATARECORDID);
				//l_OrderKey =getLength(orderKey, ApplicationConstant.CHARCOUNT_02);
				l_OrderKey =colLenMap.get(ApplicationConstant.LENGTH_ORDERNUMBER);
				if(null!=errorMsg){
					if(null!=validateLength(orderKey, l_OrderKey, transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_ORDERNUMBER)){
						errorMsg.concat(validateLength(orderKey, l_OrderKey, transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_ORDERNUMBER));	
					}
				}else{
					errorMsg=validateLength(orderKey, l_OrderKey, transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_ORDERNUMBER);
				}
				l_SheetNo =colLenMap.get(ApplicationConstant.LENGTH_SHEETNO);
				HashMap<String,String> mapSheetNo=getCompleteValue(sheetNo, l_SheetNo, ApplicationConstant.DRI_12N, transmitLogKey,ApplicationConstant.LENGTH_SHEETNO);
				if(null!=errorMsg){
					if(null!=mapSheetNo.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapSheetNo.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapSheetNo.get(ApplicationConstant.ERROR);
				}
				sheetNo=mapSheetNo.get(ApplicationConstant.LENGTH_SHEETNO);
				if(null!=errorMsg){
					if(null!=validateLength(orderTypeId, colLenMap.get(ApplicationConstant.LENGTH_ORDERTYPEID), transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_ORDERTYPEID)){
						errorMsg.concat(validateLength(orderTypeId, colLenMap.get(ApplicationConstant.LENGTH_ORDERTYPEID), transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_ORDERTYPEID));	
					}
				}else{
					errorMsg=validateLength(orderTypeId, colLenMap.get(ApplicationConstant.LENGTH_ORDERTYPEID), transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_ORDERTYPEID);
				}
				l_OrderType =colLenMap.get(ApplicationConstant.LENGTH_ORDERTYPE);
				if(null!=errorMsg){
					if(null!=validateLength(orderType, l_OrderType, transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_ORDERTYPE)){
						errorMsg.concat(validateLength(orderType, l_OrderType, transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_ORDERTYPE));	
					}
				}else{
					errorMsg=validateLength(orderType, l_OrderType, transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_ORDERTYPE);
				}
				if(null!=errorMsg){
					if(null!=validateLength(loadUnitCodeIdentifier, colLenMap.get(ApplicationConstant.LENGTH_LOADUNITCODEIDENTIFIER), transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_LOADUNITCODEIDENTIFIER)){
						errorMsg.concat(validateLength(loadUnitCodeIdentifier, colLenMap.get(ApplicationConstant.LENGTH_LOADUNITCODEIDENTIFIER), transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_LOADUNITCODEIDENTIFIER));	
					}
				}else{
					errorMsg=validateLength(loadUnitCodeIdentifier, colLenMap.get(ApplicationConstant.LENGTH_LOADUNITCODEIDENTIFIER), transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_LOADUNITCODEIDENTIFIER);
				}
				l_ToteId =colLenMap.get(ApplicationConstant.LENGTH_TOTEID);
				if(null!=errorMsg){
					if(null!=validateLength(toteId, l_ToteId, transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_TOTEID)){
						errorMsg.concat(validateLength(toteId, l_ToteId, transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_TOTEID));	
					}
				}else{
					errorMsg=validateLength(toteId, l_ToteId, transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_TOTEID);
				}
				if(null!=errorMsg){
					if(null!=validateLength(targetStationId, colLenMap.get(ApplicationConstant.LENGTH_TARGETSTATIONID), transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_TARGETSTATIONID)){
						errorMsg.concat(validateLength(targetStationId, colLenMap.get(ApplicationConstant.LENGTH_TARGETSTATIONID), transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_TARGETSTATIONID));	
					}
				}else{
					errorMsg=validateLength(targetStationId, colLenMap.get(ApplicationConstant.LENGTH_TARGETSTATIONID), transmitLogKey, ApplicationConstant.DRI_12N,ApplicationConstant.LENGTH_TARGETSTATIONID);
				}
				HashMap<String,String> mapStation=getCompleteValue(n_Station, colLenMap.get(ApplicationConstant.LENGTH_N_STATION), ApplicationConstant.DRI_12N, transmitLogKey,ApplicationConstant.LENGTH_N_STATION);
				if(null!=errorMsg){
					if(null!=mapStation.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapStation.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapStation.get(ApplicationConstant.ERROR);
				}
				n_Station=mapStation.get(ApplicationConstant.LENGTH_N_STATION);
				l_StationNo =colLenMap.get(ApplicationConstant.LENGTH_TARGETSTATION);
				HashMap<String,String> mapStationNo=getCompleteValue(targetStation, l_StationNo, ApplicationConstant.DRI_12N, transmitLogKey,ApplicationConstant.LENGTH_TARGETSTATION);
				if(null!=errorMsg){
					if(null!=mapStationNo.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapStationNo.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapStationNo.get(ApplicationConstant.ERROR);
				}
				targetStation=mapStationNo.get(ApplicationConstant.LENGTH_TARGETSTATION);
				/**************End of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				if(null!=errorMsg){
					break inner;
				}
				//pre-loop data preparation
				preLoopData=dataRecordId.concat(l_OrderKey).concat(l_SheetNo).concat(orderKey)
					.concat(sheetNo).concat(orderTypeId).concat(l_OrderType).concat(orderType)
					.concat(loadUnitCodeIdentifier).concat(l_ToteId).concat(toteId).concat(targetStationId).concat(n_Station);
				//loop data preparation
				int loopCount= Integer.parseInt(n_Station);
				String loopData="";
				if(loopCount>0){
					loopData=loopData.concat(l_StationNo).concat(targetStation);
					loopDataList.add(loopData);
				}
			}
			String loopDatapacket="";
			if (null == errorMsg && null!=loopDataList) {
				if (loopDataList.size() > 0) {
					for (String lstData : loopDataList) {
						loopDatapacket = loopDatapacket.concat(lstData);
					}
					dataPacket = preLoopData.concat(loopDatapacket);
				} else {
					dataPacket = preLoopData;
				}
			}
			rSet.close();
			pStmt.close();
		}catch(Exception e){
			errorMsg=e.toString();
			log.error("Exception occured in getDataPacket_12N method while executing query "+DBConstant.SELECT_OUT_12N+" "+e.toString());
		}
		if(null==dataPacket){
			if(null==errorMsg){
			//msg:Unable to retrieve data packet for dri param1 and transmitlogkey param2, please check the data
			errorMsg=ApplicationConstant.ERROR_MSG_DATAPACKET.replace(ApplicationConstant.PARAM_1, ApplicationConstant.DRI_12N).replace(ApplicationConstant.PARAM_2, transmitLogKey);
			}
		}
		log.info("The data packet is : "+dataPacket);
		dataPacketMap=new HashMap<String,String>();
		dataPacketMap.put(ApplicationConstant.DATAPACKET,dataPacket);
		dataPacketMap.put(ApplicationConstant.ERROR,errorMsg);
		return dataPacketMap;
	}

	private HashMap<String, String> getDataPacket_12X(String transmitLogKey,HashMap<String,String> colLenMap,Connection con) {
		//select datarecordid,l_ordernumber,l_sheetno,ordernumber,sheetno,ordertypeid,l_ordertype,ordertype,loadunitcodeidentifier,l_toteid,toteid,waveaffiliation,l_wavekey,l_shopgroup,wavekey,shopgroup,n_consigneekey,l_consigneekey,consigneekey,n_orderkey,l_orderkey,orderkey,n_orderline,l_sku,sku,qty from TL_OUT_12X where transmitlogkey=? order by wavekey,shopgroup,consigneekey,orderkey
		PreparedStatement pStmt = null;
		ResultSet rSet = null;
		String preLoopData=null;
		String dataPacket=null;
		String errorMsg=null;
		HashMap<String,String> dataPacketMap=null;
		String dataRecordId = null;
		String l_OrderNumber = null;
		String l_SheetNo = null;
		String orderNumber = null;
		String sheetNo = null;
		String orderTypeId = null;
		String l_OrderType = null;
		String orderType = null;
		String loadUnitCodeIdentifier = null;
		String l_ToteId = null;
		String toteId = null;
		String waveAffiliation = null;
		String l_Wavekey = null;
		String l_ShopGroup = null;
		String waveKey = null;
		String shopGroup = null;
		String n_ConsigneeKey = null;
		String l_ConsigneeKey = null;
		String consigneeKey = null;
		String n_OrderKey = null;
		String l_OrderKey = null;
		String orderKey = null;
		String n_OrderLine = null;
		String l_Sku = null;
		String sku = null;
		String qty = null;
		int loop1=0;
		int loop2=0;
		int loop3=0;
		ArrayList<String> listLoop=new ArrayList<String>();
		ArrayList<String> listLoop1=new ArrayList<String>();
		ArrayList<String> listLoop2=new ArrayList<String>();
		ArrayList<String> listLoop3=new ArrayList<String>();
		try{
			//sql:select datarecordid,ordernumber,sheetno,ordertypeid,ordertype,loadunitcodeidentifier,toteid,waveaffiliation,wavekey,shopgroup,n_consigneekey,consigneekey,n_orderkey,orderkey,n_orderline,sku,qty from TL_OUT_12X where transmitlogkey=? order by wavekey,shopgroup,consigneekey,orderkey 
			pStmt = con.prepareStatement(DBConstant.SELECT_OUT_12X);
			pStmt.setString(1,transmitLogKey);
			rSet = pStmt.executeQuery();
			inner:
			while (rSet.next()) {
				dataRecordId = rSet.getString(1);
				orderNumber = rSet.getString(2);
				sheetNo = rSet.getString(3);
				orderTypeId = rSet.getString(4);
				orderType = rSet.getString(5);
				loadUnitCodeIdentifier = rSet.getString(6);
				toteId = rSet.getString(7);
				waveAffiliation = rSet.getString(8);
				waveKey = rSet.getString(9);
				shopGroup = rSet.getString(10);
				n_ConsigneeKey = rSet.getString(11);
				//loop1 data
				consigneeKey = rSet.getString(12);
				n_OrderKey = rSet.getString(13);
				//loop2 data
				orderKey = rSet.getString(14);
				n_OrderLine = rSet.getString(15);
				//loop3 data
				sku = rSet.getString(16);
				qty = rSet.getString(17);
				/**************Start of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				errorMsg=validateLength(dataRecordId, colLenMap.get(ApplicationConstant.LENGTH_DATARECORDID), transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_DATARECORDID);
				l_OrderNumber =colLenMap.get(ApplicationConstant.LENGTH_ORDERNUMBER);
				if(null!=errorMsg){
					if(null!=validateLength(orderNumber, l_OrderNumber, transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_ORDERNUMBER)){
						errorMsg.concat(validateLength(orderNumber, l_OrderNumber, transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_ORDERNUMBER));	
					}
				}else{
					errorMsg=validateLength(orderNumber, l_OrderNumber, transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_ORDERNUMBER);
				}
				l_SheetNo =colLenMap.get(ApplicationConstant.LENGTH_SHEETNO);
				HashMap<String,String> mapSheetNo=getCompleteValue(sheetNo, l_SheetNo, ApplicationConstant.DRI_12X, transmitLogKey,ApplicationConstant.LENGTH_SHEETNO);
				if(null!=errorMsg){
					if(null!=mapSheetNo.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapSheetNo.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapSheetNo.get(ApplicationConstant.ERROR);
				}
				sheetNo=mapSheetNo.get(ApplicationConstant.LENGTH_SHEETNO);
				if(null!=errorMsg){
					if(null!=validateLength(orderTypeId, colLenMap.get(ApplicationConstant.LENGTH_ORDERTYPEID), transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_ORDERTYPEID)){
						errorMsg.concat(validateLength(orderTypeId, colLenMap.get(ApplicationConstant.LENGTH_ORDERTYPEID), transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_ORDERTYPEID));	
					}
				}else{
					errorMsg=validateLength(orderTypeId, colLenMap.get(ApplicationConstant.LENGTH_ORDERTYPEID), transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_ORDERTYPEID);
				}
				l_OrderType =colLenMap.get(ApplicationConstant.LENGTH_ORDERTYPE);
				if(null!=errorMsg){
					if(null!=validateLength(orderType, l_OrderType, transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_ORDERTYPE)){
						errorMsg.concat(validateLength(orderType, l_OrderType, transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_ORDERTYPE));	
					}
				}else{
					errorMsg=validateLength(orderType, l_OrderType, transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_ORDERTYPE);
				}
				if(null!=errorMsg){
					if(null!=validateLength(loadUnitCodeIdentifier, colLenMap.get(ApplicationConstant.LENGTH_LOADUNITCODEIDENTIFIER), transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_LOADUNITCODEIDENTIFIER)){
						errorMsg.concat(validateLength(loadUnitCodeIdentifier, colLenMap.get(ApplicationConstant.LENGTH_LOADUNITCODEIDENTIFIER), transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_LOADUNITCODEIDENTIFIER));	
					}
				}else{
					errorMsg=validateLength(loadUnitCodeIdentifier, colLenMap.get(ApplicationConstant.LENGTH_LOADUNITCODEIDENTIFIER), transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_LOADUNITCODEIDENTIFIER);
				}
				l_ToteId =colLenMap.get(ApplicationConstant.LENGTH_TOTEID);
				if(null!=errorMsg){
					if(null!=validateLength(toteId, l_ToteId, transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_TOTEID)){
						errorMsg.concat(validateLength(toteId, l_ToteId, transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_TOTEID));	
					}
				}else{
					errorMsg=validateLength(toteId, l_ToteId, transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_TOTEID);
				}
				if(null!=errorMsg){
					if(null!=validateLength(waveAffiliation, colLenMap.get(ApplicationConstant.LENGTH_WAVEAFFILIATION), transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_WAVEAFFILIATION)){
						errorMsg.concat(validateLength(waveAffiliation, colLenMap.get(ApplicationConstant.LENGTH_WAVEAFFILIATION), transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_WAVEAFFILIATION));	
					}
				}else{
					errorMsg=validateLength(waveAffiliation, colLenMap.get(ApplicationConstant.LENGTH_WAVEAFFILIATION), transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_WAVEAFFILIATION);
				}
				l_Wavekey =colLenMap.get(ApplicationConstant.LENGTH_WAVEKEY);// for fixed length fields we use colLenMap map.
				if(null!=errorMsg){
					if(null!=validateLength(waveKey, l_Wavekey, transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_WAVEKEY)){
						errorMsg.concat(validateLength(waveKey, l_Wavekey, transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_WAVEKEY));
					}
				}else{
					errorMsg=validateLength(waveKey, l_Wavekey, transmitLogKey, ApplicationConstant.DRI_12X,ApplicationConstant.LENGTH_WAVEKEY);
				}
				l_ShopGroup =colLenMap.get(ApplicationConstant.LENGTH_SHOPGROUP);
				HashMap<String,String> mapShopGroup=getCompleteValue(shopGroup, colLenMap.get(ApplicationConstant.LENGTH_SHOPGROUP), ApplicationConstant.DRI_12X, transmitLogKey,ApplicationConstant.LENGTH_SHOPGROUP);
				if(null!=errorMsg){
					if(null!=mapShopGroup.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapShopGroup.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapShopGroup.get(ApplicationConstant.ERROR);
				}
				shopGroup=mapShopGroup.get(ApplicationConstant.LENGTH_SHOPGROUP);
				HashMap<String,String> mapConsigneeKey=getCompleteValue(n_ConsigneeKey, colLenMap.get(ApplicationConstant.LENGTH_N_CONSIGNEEKEY), ApplicationConstant.DRI_12X, transmitLogKey,ApplicationConstant.LENGTH_N_CONSIGNEEKEY);
				if(null!=errorMsg){
					if(null!=mapConsigneeKey.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapConsigneeKey.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapConsigneeKey.get(ApplicationConstant.ERROR);
				}
				n_ConsigneeKey=mapConsigneeKey.get(ApplicationConstant.LENGTH_N_CONSIGNEEKEY);
				HashMap<String,String> map_l_ConsigneeKey = getLength(consigneeKey,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_CONSIGNEEKEY); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
				if(null!=errorMsg){
					if(null!=map_l_ConsigneeKey.get(ApplicationConstant.ERROR)){
						errorMsg.concat(map_l_ConsigneeKey.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=map_l_ConsigneeKey.get(ApplicationConstant.ERROR);
				}
				l_ConsigneeKey=map_l_ConsigneeKey.get(ApplicationConstant.LENGTH_CONSIGNEEKEY);
				HashMap<String,String> mapOrderKey=getCompleteValue(n_OrderKey, colLenMap.get(ApplicationConstant.LENGTH_N_ORDERKEY), ApplicationConstant.DRI_12X, transmitLogKey,ApplicationConstant.LENGTH_N_ORDERKEY);
				if(null!=errorMsg){
					if(null!=mapOrderKey.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapOrderKey.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapOrderKey.get(ApplicationConstant.ERROR);
				}
				n_OrderKey=mapOrderKey.get(ApplicationConstant.LENGTH_N_ORDERKEY);
				HashMap<String,String> map_l_OrderKey = getLength(orderKey,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_ORDERKEY); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
				if(null!=errorMsg){
					if(null!=map_l_OrderKey.get(ApplicationConstant.ERROR)){
						errorMsg.concat(map_l_OrderKey.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=map_l_OrderKey.get(ApplicationConstant.ERROR);
				}
				l_OrderKey=map_l_OrderKey.get(ApplicationConstant.LENGTH_ORDERKEY);
				HashMap<String,String> mapOrderLine=getCompleteValue(n_OrderLine, colLenMap.get(ApplicationConstant.LENGTH_N_ORDERLINE), ApplicationConstant.DRI_12X, transmitLogKey,ApplicationConstant.LENGTH_N_ORDERLINE);
				if(null!=errorMsg){
					if(null!=mapOrderLine.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapOrderLine.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapOrderLine.get(ApplicationConstant.ERROR);
				}
				n_OrderLine=mapOrderLine.get(ApplicationConstant.LENGTH_N_ORDERLINE);
				HashMap<String,String> map_l_sku = getLength(sku,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_SKU); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
				if(null!=errorMsg){
					if(null!=map_l_sku.get(ApplicationConstant.ERROR)){
						errorMsg.concat(map_l_sku.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=map_l_sku.get(ApplicationConstant.ERROR);
				}
				l_Sku=map_l_sku.get(ApplicationConstant.LENGTH_SKU);
				HashMap<String,String> mapQty=getCompleteValue(qty, colLenMap.get(ApplicationConstant.LENGTH_QTY), ApplicationConstant.DRI_12X, transmitLogKey,ApplicationConstant.LENGTH_QTY);
				if(null!=errorMsg){
					if(null!=mapQty.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapQty.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapQty.get(ApplicationConstant.ERROR);
				}
				qty=mapQty.get(ApplicationConstant.LENGTH_QTY);
				/**************End of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				if(null!=errorMsg){
					break inner;
				}
				
				//pre-loop data preparation
				preLoopData=dataRecordId.concat(l_OrderNumber).concat(l_SheetNo).concat(orderNumber)
					.concat(sheetNo).concat(orderTypeId).concat(l_OrderType).concat(orderType).concat(loadUnitCodeIdentifier)
					.concat(l_ToteId).concat(toteId).concat(waveAffiliation).concat(l_Wavekey).concat(l_ShopGroup)
					.concat(waveKey).concat(shopGroup).concat(n_ConsigneeKey);
				//loop data preparation
				 loop1=Integer.parseInt(n_ConsigneeKey);
				 loop2=Integer.parseInt(n_OrderKey);
				 loop3=Integer.parseInt(n_OrderLine);
				 String data1="";
					if(loop1>0){
						if(listLoop1.size()>0){
							boolean flag1=true;
							inner1:
							for(String str:listLoop1){
								if(str.contains(l_ConsigneeKey.concat(consigneeKey).concat(n_OrderKey))){
									flag1=false;
									break inner1;
								}
							}
							if(flag1){
								listLoop1.clear();
								listLoop2.clear();
								listLoop3.clear();
								data1=l_ConsigneeKey.concat(consigneeKey).concat(n_OrderKey);
								listLoop1.add(data1);
							}
						}else{
							data1=l_ConsigneeKey.concat(consigneeKey).concat(n_OrderKey);
							listLoop1.add(data1);
						}
						 if(null!=data1 && data1.length()>0){
								listLoop2.clear();
						 }
						 String data2="";
						 if(loop2>0){
							 if(listLoop2.size()>0){
								 boolean flag1=true;
								 boolean flag2=true;
								 inner2:
										for(String str:listLoop2){
											if(str.contains(data1.concat(l_OrderKey.concat(orderKey).concat(n_OrderLine)))){
												flag1=false;
												flag2=false;
												break inner2;
											}else if(str.contains(l_OrderKey.concat(orderKey).concat(n_OrderLine))){
												flag2=false;
												break inner2;
											}
										}
								 if(flag1){
									 data2=data1.concat(l_OrderKey.concat(orderKey).concat(n_OrderLine));
									 listLoop2.add(data2);
								 }else if(flag2){
									 data2=l_OrderKey.concat(orderKey).concat(n_OrderLine);
									 listLoop2.add(data2);
								 }
							 }else{
								 data2=data1.concat(l_OrderKey.concat(orderKey).concat(n_OrderLine));
								 listLoop2.add(data2);
							 }
							 if(null!=data2 && data2.length()>0){
									listLoop3.clear();
							 }
							 String data3="";
							 if(loop3>0){	
								 if(listLoop3.size()>0){
									 boolean flag1=true;
									 boolean flag2=true;
									 		inner3:
											for(String str:listLoop3){
												if(str.contains(data2.concat(l_Sku.concat(sku).concat(qty)))){
													flag1=false;
													flag2=false;
													break inner3;
												}else if(str.contains(l_Sku.concat(sku).concat(qty))){
													flag2=false;
													break inner3;
												}
											}
								if (flag1) {
										data3 = data2.concat(l_Sku.concat(sku).concat(qty));
										listLoop3.add(data3);
								}else if(flag2){
										 data3=l_Sku.concat(sku).concat(qty);
										 listLoop3.add(data3);
									 }
								 }else{
									data3=data2.concat(l_Sku.concat(sku).concat(qty));
									listLoop3.add(data3);
								 }
								 listLoop.add(data3);
							 }
						 }
					}
			}
			if (null == errorMsg) {
				String loopDataPacket = "";
				if (listLoop.size() > 0) {
					for (String data : listLoop) {
						loopDataPacket = loopDataPacket.concat(data);
					}
				}
				dataPacket = "";
				if(null!=preLoopData){
					dataPacket = preLoopData.concat(loopDataPacket);
				}else{
					errorMsg=ApplicationConstant.ERR_DET_MSG.replace(ApplicationConstant.PARAM_1, ApplicationConstant.DRI_12X) +transmitLogKey;
				}
			}
			rSet.close();
			pStmt.close();
		}catch(Exception e){
			errorMsg=e.toString();
			log.error("Exception occured in getDataPacket_12X method while executing query "+DBConstant.SELECT_OUT_12X+" "+e.toString());
		}
		if(null==dataPacket){
			if(null==errorMsg){
				//msg:Unable to retrieve data packet for dri param1 and transmitlogkey param2, please check the data
				errorMsg=ApplicationConstant.ERROR_MSG_DATAPACKET.replace(ApplicationConstant.PARAM_1, ApplicationConstant.DRI_12X).replace(ApplicationConstant.PARAM_2, transmitLogKey);
			}
		}
		log.info("The data packet is : "+dataPacket);
		dataPacketMap=new HashMap<String,String>();
		dataPacketMap.put(ApplicationConstant.DATAPACKET,dataPacket);
		dataPacketMap.put(ApplicationConstant.ERROR,errorMsg);
		return dataPacketMap;
	}

	private HashMap<String, String> getDataPacket_1LL(String transmitLogKey,HashMap<String,String> colLenMap,Connection con) {
		PreparedStatement pStmt = null;
		ResultSet rSet = null;
		String dataPacket=null;
		String errorMsg=null;
		HashMap<String,String> dataPacketMap=null;
		String preLoopData=null;
		String dataRecordId = null;
		String l_WaveKey = null;
		String l_WaveType = null;
		String l_WaveStatus = null;
		String waveKey = null;
		String waveType = null;
		String waveStatus = null;
		String lastLoadUnitId = null;
		String l_ShopGroup = null;
		String l_NoOfLoadUnit = null;
		String shopGroup = null;
		String n_UsedLoadUnit = null;
		try{
			//sql:select datarecordid,wavekey,wavetype,wavestatus,lastloadunitid,shopgroup,n_usedloadunit from TL_OUT_1LL where transmitlogkey=?
			pStmt = con.prepareStatement(DBConstant.SELECT_OUT_1LL);
			pStmt.setString(1,transmitLogKey);
			rSet = pStmt.executeQuery();
			inner:
			while (rSet.next()) {
				dataRecordId = rSet.getString(1);
				waveKey = rSet.getString(2);
				waveType = rSet.getString(3);
				waveStatus = rSet.getString(4);
				lastLoadUnitId = rSet.getString(5);
				shopGroup = rSet.getString(6);
				n_UsedLoadUnit = rSet.getString(7);
				
				/**************Start of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				errorMsg=validateLength(dataRecordId, colLenMap.get(ApplicationConstant.LENGTH_DATARECORDID), transmitLogKey, ApplicationConstant.DRI_1LL,ApplicationConstant.LENGTH_DATARECORDID);
				l_WaveKey =colLenMap.get(ApplicationConstant.LENGTH_WAVEKEY);// for fixed length fields we use colLenMap map.
				if(null!=errorMsg){
					if(null!=validateLength(waveKey, l_WaveKey, transmitLogKey, ApplicationConstant.DRI_1LL,ApplicationConstant.LENGTH_WAVEKEY)){
						errorMsg.concat(validateLength(waveKey, l_WaveKey, transmitLogKey, ApplicationConstant.DRI_1LL,ApplicationConstant.LENGTH_WAVEKEY));
					}
				}else{
					errorMsg=validateLength(waveKey, l_WaveKey, transmitLogKey, ApplicationConstant.DRI_1LL,ApplicationConstant.LENGTH_WAVEKEY);
				}
				l_WaveType =colLenMap.get(ApplicationConstant.LENGTH_WAVETYPE);
				if(null!=errorMsg){
					if(null!=validateLength(waveType, l_WaveType, transmitLogKey, ApplicationConstant.DRI_1LL,ApplicationConstant.LENGTH_WAVETYPE)){
						errorMsg.concat(validateLength(waveType, l_WaveType, transmitLogKey, ApplicationConstant.DRI_1LL,ApplicationConstant.LENGTH_WAVETYPE));
					}
					
				}else{
					errorMsg=validateLength(waveType, l_WaveType, transmitLogKey, ApplicationConstant.DRI_1LL,ApplicationConstant.LENGTH_WAVETYPE);
				}
				l_WaveStatus =colLenMap.get(ApplicationConstant.LENGTH_WAVESTATUS);
				if(null!=errorMsg){
					if(null!=validateLength(waveStatus, l_WaveStatus, transmitLogKey, ApplicationConstant.DRI_1LL,ApplicationConstant.LENGTH_WAVESTATUS)){
						errorMsg.concat(validateLength(waveStatus, l_WaveStatus, transmitLogKey, ApplicationConstant.DRI_1LL,ApplicationConstant.LENGTH_WAVESTATUS));
					}
				}else{
					errorMsg=validateLength(waveStatus, l_WaveStatus, transmitLogKey, ApplicationConstant.DRI_1LL,ApplicationConstant.LENGTH_WAVESTATUS);
				}
				if(null!=errorMsg){
					if(null!=validateLength(lastLoadUnitId, colLenMap.get(ApplicationConstant.LENGTH_LASTLOADUNITID), transmitLogKey, ApplicationConstant.DRI_1LL,ApplicationConstant.LENGTH_LASTLOADUNITID)){
						errorMsg.concat(validateLength(lastLoadUnitId, colLenMap.get(ApplicationConstant.LENGTH_LASTLOADUNITID), transmitLogKey, ApplicationConstant.DRI_1LL,ApplicationConstant.LENGTH_LASTLOADUNITID));	
					}
				}else{
					errorMsg=validateLength(lastLoadUnitId, colLenMap.get(ApplicationConstant.LENGTH_LASTLOADUNITID), transmitLogKey, ApplicationConstant.DRI_1LL,ApplicationConstant.LENGTH_LASTLOADUNITID);
				}
			    l_ShopGroup =colLenMap.get(ApplicationConstant.LENGTH_SHOPGROUP);
				HashMap<String,String> mapShopGroup=getCompleteValue(shopGroup, colLenMap.get(ApplicationConstant.LENGTH_SHOPGROUP), ApplicationConstant.DRI_1LL, transmitLogKey,ApplicationConstant.LENGTH_SHOPGROUP);
				if(null!=errorMsg){
					if(null!=mapShopGroup.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapShopGroup.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapShopGroup.get(ApplicationConstant.ERROR);
				}
				shopGroup=mapShopGroup.get(ApplicationConstant.LENGTH_SHOPGROUP);
				HashMap<String,String> map_l_NoOfLoadUnit= getLength(n_UsedLoadUnit,ApplicationConstant.CHARCOUNT_02,ApplicationConstant.LENGTH_N_USEDLOADUNIT); //getLength() method is used when length is not fixed, it helps to create exact length from the actual field value
				if(null!=errorMsg){
					if(null!=map_l_NoOfLoadUnit.get(ApplicationConstant.ERROR)){
						errorMsg.concat(map_l_NoOfLoadUnit.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=map_l_NoOfLoadUnit.get(ApplicationConstant.ERROR);
				}
				l_NoOfLoadUnit=map_l_NoOfLoadUnit.get(ApplicationConstant.LENGTH_N_USEDLOADUNIT);
				HashMap<String,String> mapNoOfLoadUnit=getCompleteValue(n_UsedLoadUnit, l_NoOfLoadUnit, ApplicationConstant.DRI_1LL, transmitLogKey,ApplicationConstant.LENGTH_USEDLOADUNIT);
				if(null!=errorMsg){
					if(null!=mapNoOfLoadUnit.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapNoOfLoadUnit.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapNoOfLoadUnit.get(ApplicationConstant.ERROR);
				}
				n_UsedLoadUnit=mapNoOfLoadUnit.get(ApplicationConstant.LENGTH_USEDLOADUNIT);
				/**************End of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				if(null!=errorMsg){
					break inner;
				}else{
				//data packet creation
				preLoopData=dataRecordId.concat(l_WaveKey).concat(l_WaveType)
						.concat(l_WaveStatus).concat(waveKey).concat(waveType).concat(waveStatus)
						.concat(lastLoadUnitId).concat(l_ShopGroup).concat(l_NoOfLoadUnit).concat(shopGroup).concat(n_UsedLoadUnit);
				}
			}
			if(null==errorMsg){
				dataPacket=preLoopData;
			}
			rSet.close();
			pStmt.close();
		}catch(Exception e){
			errorMsg=e.toString();
			log.error("Exception occured in getDataPacket_1LL method while executing query "+DBConstant.SELECT_OUT_1LL+" "+e.toString());
		}
		if(null==dataPacket){
			if(null==errorMsg){
			//msg:Unable to retrieve data packet for dri param1 and transmitlogkey param2, please check the data
			errorMsg=ApplicationConstant.ERROR_MSG_DATAPACKET.replace(ApplicationConstant.PARAM_1, ApplicationConstant.DRI_1LL).replace(ApplicationConstant.PARAM_2, transmitLogKey);
			}
		}
		log.info("The data packet is : "+dataPacket);
		dataPacketMap=new HashMap<String,String>();
		dataPacketMap.put(ApplicationConstant.DATAPACKET,dataPacket);
		dataPacketMap.put(ApplicationConstant.ERROR,errorMsg);
		return dataPacketMap;
	}

	private HashMap<String, String> getDataPacket_12D(String transmitLogKey,HashMap<String,String> colLenMap,Connection con) {
		PreparedStatement pStmt = null;
		ResultSet rSet = null;
		String dataPacket=null;
		String errorMsg=null;
		HashMap<String,String> dataPacketMap=null;
		String preLoopData=null;
		String dataRecordId = null;
		String l_OrderNumber = null;
		String l_SheetNo = null;
		String orderNumber = null;
		String sheetNo = null;
		try{
			//sql:select datarecordid,ordernumber,sheetno from TL_OUT_12D where transmitlogkey=?
			pStmt = con.prepareStatement(DBConstant.SELECT_OUT_12D);
			pStmt.setString(1,transmitLogKey);
			rSet = pStmt.executeQuery();
			inner:
			while (rSet.next()) {
				dataRecordId = rSet.getString(1);
				orderNumber = rSet.getString(2);
				sheetNo = rSet.getString(3);
				/**************Start of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				errorMsg=validateLength(dataRecordId, colLenMap.get(ApplicationConstant.LENGTH_DATARECORDID), transmitLogKey, ApplicationConstant.DRI_12D,ApplicationConstant.LENGTH_DATARECORDID);
				l_OrderNumber =colLenMap.get(ApplicationConstant.LENGTH_ORDERNUMBER);
				if(null!=errorMsg){
					if(null!=validateLength(orderNumber, l_OrderNumber, transmitLogKey, ApplicationConstant.DRI_12D,ApplicationConstant.LENGTH_ORDERNUMBER)){
						errorMsg.concat(validateLength(orderNumber, l_OrderNumber, transmitLogKey, ApplicationConstant.DRI_12D,ApplicationConstant.LENGTH_ORDERNUMBER));	
					}
				}else{
					errorMsg=validateLength(orderNumber, l_OrderNumber, transmitLogKey, ApplicationConstant.DRI_12D,ApplicationConstant.LENGTH_ORDERNUMBER);
				}
				l_SheetNo =colLenMap.get(ApplicationConstant.LENGTH_SHEETNO);
				HashMap<String,String> mapSheetNo=getCompleteValue(sheetNo, colLenMap.get(ApplicationConstant.LENGTH_SHEETNO), ApplicationConstant.DRI_12D, transmitLogKey,ApplicationConstant.LENGTH_SHEETNO);
				if(null!=errorMsg){
					if(null!=mapSheetNo.get(ApplicationConstant.ERROR)){
						errorMsg.concat(mapSheetNo.get(ApplicationConstant.ERROR));
					}
				}else{
					errorMsg=mapSheetNo.get(ApplicationConstant.ERROR);
				}
				sheetNo=mapSheetNo.get(ApplicationConstant.LENGTH_SHEETNO);
				/**************End of Validation of length and getting proper value of a string for example 1 to 01 and length of data column**************/
				if(null!=errorMsg){
					break inner;
				}else{
				//data packet creation
				preLoopData=dataRecordId.concat(l_OrderNumber).concat(l_SheetNo)
						.concat(orderNumber).concat(sheetNo);
				}
			}
			if(null==errorMsg){
				dataPacket=preLoopData;
			}
			rSet.close();
			pStmt.close();
		}catch(Exception e){
			errorMsg=e.toString();
			log.error("Exception occured in getDataPacket_12D method while executing query "+DBConstant.SELECT_OUT_12D+" "+e.toString());
		}
		if(null==dataPacket){
			if(null==errorMsg){
			//msg:Unable to retrieve data packet for dri param1 and transmitlogkey param2, please check the data
			errorMsg=ApplicationConstant.ERROR_MSG_DATAPACKET.replace(ApplicationConstant.PARAM_1, ApplicationConstant.DRI_12D).replace(ApplicationConstant.PARAM_2, transmitLogKey);
			}
		}
		log.info("The data packet is : "+dataPacket);
		dataPacketMap=new HashMap<String,String>();
		dataPacketMap.put(ApplicationConstant.DATAPACKET,dataPacket);
		dataPacketMap.put(ApplicationConstant.ERROR,errorMsg);
		return dataPacketMap;
	}
	private HashMap<String,String> getLength(String data,String chars,String fieldName){
		String length=null;
		String errorMsg=null;
		HashMap<String,String> map=null;
		try{
			map=new HashMap<String,String>();
			if(null!=data){
				int len=String.valueOf(data.length()).length();
				int charCount=Integer.parseInt(chars.trim());
				if(len==charCount){
					length=String.valueOf(data.length());
				}else if(len<charCount && len!=0){
					int i=charCount-len;
					String dataLen="";
					while(i>0){
						dataLen=dataLen.concat(ApplicationConstant.ZERO);
						i--;
					}
					length=dataLen.concat(String.valueOf(data.length()));
				}
			}else{
				errorMsg=fieldName+" Column value found null";
			}
		}catch(Exception e){
			errorMsg="The exception occured while creating length value in getLength Method "+e.toString();
			log.error(errorMsg);
		}
		map.put(fieldName, length);
		map.put(ApplicationConstant.ERROR, errorMsg);
		return map;
	}
	private String validateLength(String data,String actualLength,String transmitLogKey,String dri,String fieldName){
		String errorMsg=null;
		try{
			if(null!=data){
				if(data.length()!=Integer.parseInt(actualLength.trim())){
					//msg: Please check the length of param1 for dri param2 and transmitlogkey param3 , length must be param4 found: param5
					errorMsg=ApplicationConstant.LENGTH_ERROR_MSG
							.replace(ApplicationConstant.PARAM_1, fieldName)
						    .replace(ApplicationConstant.PARAM_2, dri)
						    .replace(ApplicationConstant.PARAM_3, transmitLogKey)
						    .replace(ApplicationConstant.PARAM_4, String.valueOf(Integer.parseInt(actualLength)))
						    .replace(ApplicationConstant.PARAM_5, String.valueOf(data.length()));
				}
			}else{
				errorMsg=fieldName+" Column value found null";
			}
			
		}catch(Exception e){
			errorMsg=e.toString();
			log.error("Exception occured in validateLength method: "+e.toString());
			
		}
		return errorMsg;
	}
	private HashMap<String,String> getCompleteValue(String data,String aLength,String dri,String transmitLogKey,String consKey){
		String errorMsg=null;
		String stringQty=null;
		HashMap<String,String> map=null; 
		try{
			if(null!=data){
				int actualLength=Integer.parseInt(aLength.trim());
				int currentlength=data.length();
				if(currentlength<actualLength){
					int i=actualLength-currentlength;
					String dataLen="";
					while(i>0){
						dataLen=dataLen.concat(ApplicationConstant.ZERO);
						i--;
					}
					stringQty=dataLen.concat(data);
				}else if (currentlength==actualLength){
					stringQty=data;
				}else{
					errorMsg=ApplicationConstant.LENGTH_ERROR_MSG
							.replace(ApplicationConstant.PARAM_1, ApplicationConstant.LENGTH_QTY)
						    .replace(ApplicationConstant.PARAM_2, dri)
						    .replace(ApplicationConstant.PARAM_3, transmitLogKey)
						    .replace(ApplicationConstant.PARAM_4, String.valueOf(actualLength))
						    .replace(ApplicationConstant.PARAM_5, String.valueOf(data.length()));
				}
			}else{
				errorMsg=consKey+" Column value found null";
			}
		}catch(Exception e){
			errorMsg=e.toString();
			log.error("Exception occured in getStringQty method for : "+consKey+" "+e.toString());
		}
		map=new HashMap<String,String>();
		map.put(consKey, stringQty);
		map.put(ApplicationConstant.ERROR, errorMsg);
		return map;
	}
	private String validate12X(String transmitLogKey,Connection con) throws SQLException{
		PreparedStatement pStmt1 = null;
		PreparedStatement pStmt2 = null;
		PreparedStatement pStmt3 = null;
		PreparedStatement pStmt4 = null;
		ResultSet rSet1=null;
		ResultSet rSet2=null;
		ResultSet rSet3=null;
		ResultSet rSet4=null;
		String errorMsg=null;
		String waveKey=null;
		try {
			//sql:select distinct wavekey from tl_out_12x where transmitlogkey=? order by wavekey
			pStmt1 = con.prepareStatement(DBConstant.SELECT_WAVEKEY_12X);
			pStmt1.setString(1, transmitLogKey);
			rSet1=pStmt1.executeQuery();
			if(rSet1.next()){
				waveKey=rSet1.getString(1);
			}
			rSet1.close();
			pStmt1.close();
			if(null!=waveKey){
				//sql:select distinct consigneekey,n_consigneekey from tl_out_12x where transmitlogkey=? and wavekey=? order by consigneekey
				pStmt2 = con.prepareStatement(DBConstant.SELECT_CONSKEY_12X);
				pStmt2.setString(1, transmitLogKey);
				pStmt2.setString(2, waveKey);
				rSet2=pStmt2.executeQuery();
				ArrayList<String> consigneeKeyList=new ArrayList<String>();
				ArrayList<String> n_consigneeKeyList=new ArrayList<String>();
				while(rSet2.next()){
					String consigneeKey=rSet2.getString(1);
					String n_consigneeKey=rSet2.getString(2);
					if(!consigneeKeyList.contains(consigneeKey)){
						consigneeKeyList.add(consigneeKey);
					}
					if(n_consigneeKeyList.size()<1){
						n_consigneeKeyList.add(n_consigneeKey);
					}else{
						if(!n_consigneeKeyList.contains(n_consigneeKey)){
							errorMsg="Please check number of consigneekey for wavekey "+waveKey+" and transmitlogkey "+transmitLogKey;
							return errorMsg;
						}
					}
				}
				rSet2.close();
				pStmt2.close();
				int n_consKey=Integer.parseInt(n_consigneeKeyList.get(0));
				if (n_consKey != consigneeKeyList.size()) {
					errorMsg = "Please check number of consigneekey for wavekey "+ waveKey + " and transmitlogkey " + transmitLogKey;
					return errorMsg;
				}else{
					for(String consignKey:consigneeKeyList){
						//sql:select distinct orderkey,n_orderkey from tl_out_12x where transmitlogkey=? and wavekey=? and consigneekey=? order by orderkey";
						pStmt3 = con.prepareStatement(DBConstant.SELECT_ORDERKEY_12X);
						pStmt3.setString(1, transmitLogKey);
						pStmt3.setString(2, waveKey);
						pStmt3.setString(3, consignKey);
						rSet3=pStmt3.executeQuery();
						ArrayList<String> orderKeyList=new ArrayList<String>();
						ArrayList<String> n_orderKeyList=new ArrayList<String>();
						while(rSet3.next()){
							String orderKey=rSet3.getString(1);
							String n_orderKey=rSet3.getString(2);
							if(!orderKeyList.contains(orderKey)){
								orderKeyList.add(orderKey);
							}
							if(n_orderKeyList.size()<1){
								n_orderKeyList.add(n_orderKey);
							}else{
								if(!n_orderKeyList.contains(n_orderKey)){
									errorMsg="Please check number of orderKey for consigneekey "+consignKey+" and wavekey "+waveKey+" and transmitlogkey "+transmitLogKey;
									return errorMsg;
								}
							}
						}
						rSet3.close();
						pStmt3.close();
						int n_ordrKey=Integer.parseInt(n_orderKeyList.get(0));
						if (n_ordrKey != orderKeyList.size()) {
							errorMsg="Please check number of orderKey for consigneekey "+consignKey+" and wavekey "+waveKey+" and transmitlogkey "+transmitLogKey;
							return errorMsg;
						}else{
							for(String ordrKey:orderKeyList){
								//sql:select distinct sku,n_orderline from tl_out_12x where  transmitlogkey=? and wavekey=? and consigneekey=? and orderkey=? order by sku
								pStmt4 = con.prepareStatement(DBConstant.SELECT_SKU_12X);
								pStmt4.setString(1, transmitLogKey);
								pStmt4.setString(2, waveKey);
								pStmt4.setString(3, consignKey);
								pStmt4.setString(4, ordrKey);
								rSet4=pStmt4.executeQuery();
								ArrayList<String> skuList=new ArrayList<String>();
								ArrayList<String> n_skuList=new ArrayList<String>();
								while(rSet4.next()){
									String sku=rSet4.getString(1);
									String n_sku=rSet4.getString(2);
									if(!skuList.contains(sku)){
										skuList.add(sku);
									}
									if(n_skuList.size()<1){
										n_skuList.add(n_sku);
									}else{
										if(!n_skuList.contains(n_sku)){
											errorMsg="Please check number of sku for orderkey "+ordrKey+" and consigneekey "+consignKey+" and wavekey "+waveKey+" and transmitlogkey "+transmitLogKey;
											return errorMsg;
										}
									}
								}
								rSet4.close();
								pStmt4.close();
								int no_sku=Integer.parseInt(n_skuList.get(0));
								if (no_sku != skuList.size()) {
									errorMsg="Please check number of sku for orderkey "+ordrKey+" consigneekey "+consignKey+" and wavekey "+waveKey+" and transmitlogkey "+transmitLogKey;
									return errorMsg;
								}
							}
						}
					}
				}
			}else{
				errorMsg="Wavekey found null for transmitlogkey "+transmitLogKey;
				return errorMsg;
			}
		} catch (SQLException sqlException) {
			errorMsg="Exception occured in validate12X method while validating data "+sqlException.toString();
			log.error(errorMsg);
		}catch(Exception e){
			errorMsg="Exception occured in validate12X method while validating data "+e.toString();
			log.error(errorMsg);
		}
		return errorMsg;
	}

	private String validateWave(String transmitLogKey,String dri,Connection con) throws SQLException {
		PreparedStatement pStmt0 = null;
		PreparedStatement pStmt1 = null;
		PreparedStatement pStmt2 = null;
		PreparedStatement pStmt3 = null;
		PreparedStatement pStmt4 = null;
		ResultSet rSet0 = null;
		ResultSet rSet1 = null;
		ResultSet rSet2 = null;
		ResultSet rSet3 = null;
		ResultSet rSet4 = null;
		String errorMsg = null;
		String waveKey = null;
		try {
			// sql:select distinct wavekey from tl_out_ where transmitlogkey=? order by wavekey
			String query0=DBConstant.SELECT_WAVEKEY;
			query0=query0.replace(ApplicationConstant.TL_OUT, ApplicationConstant.TL_OUT+dri);
			pStmt0 = con.prepareStatement(query0);
			pStmt0.setString(1, transmitLogKey);
			rSet0 = pStmt0.executeQuery();
			if (rSet0.next()) {
				waveKey = rSet0.getString(1);
			}
			rSet0.close();
			pStmt0.close();
			if (null != waveKey) {
				// sql:select distinct shopgroup, n_shopgroup from tl_out_ where transmitlogkey=? and wavekey=? order by shopgroup
				String query1=DBConstant.SELECT_SHOPGROUP;
				query1=query1.replace(ApplicationConstant.TL_OUT, ApplicationConstant.TL_OUT+dri);
				pStmt1 = con.prepareStatement(query1);
				pStmt1.setString(1, transmitLogKey);
				pStmt1.setString(2, waveKey);
				rSet1 = pStmt1.executeQuery();
				ArrayList<String> shopGroupList = new ArrayList<String>();
				ArrayList<String> n_shopGroupList = new ArrayList<String>();
				while (rSet1.next()) {
					String shopGroup = rSet1.getString(1);
					String n_shopGroup = rSet1.getString(2);
					if (!shopGroupList.contains(shopGroup)) {
						shopGroupList.add(shopGroup);
					}
					if (n_shopGroupList.size() < 1) {
						n_shopGroupList.add(n_shopGroup);
					} else {
						if (!n_shopGroupList.contains(n_shopGroup)) {
							errorMsg = "Please check number of shopGroup for wavekey "+ waveKey+ " and transmitlogkey "+ transmitLogKey;
							return errorMsg;
						}
					}
				}
				rSet1.close();
				pStmt1.close();
				int n_shGroup = Integer.parseInt(n_shopGroupList.get(0));
				if (n_shGroup != shopGroupList.size()) {
					errorMsg = "Please check number of shopGroup for wavekey "+ waveKey + " and transmitlogkey " + transmitLogKey;
					return errorMsg;
				} else {
					for (String shopGrp : shopGroupList) {
						// sql:select distinct consigneekey,n_consigneekey from tl_out_1xw where transmitlogkey=? and wavekey=? and shopgroup=? order by consigneekey
						String query2=DBConstant.SELECT_CONSKEY;
						query2=query2.replace(ApplicationConstant.TL_OUT, ApplicationConstant.TL_OUT+dri);
						pStmt2 = con.prepareStatement(query2);
						pStmt2.setString(1, transmitLogKey);
						pStmt2.setString(2, waveKey);
						pStmt2.setString(3, shopGrp);
						rSet2 = pStmt2.executeQuery();
						ArrayList<String> consigneeKeyList = new ArrayList<String>();
						ArrayList<String> n_consigneeKeyList = new ArrayList<String>();
						while (rSet2.next()) {
							String consigneeKey = rSet2.getString(1);
							String n_consigneeKey = rSet2.getString(2);
							if (!consigneeKeyList.contains(consigneeKey)) {
								consigneeKeyList.add(consigneeKey);
							}
							if (n_consigneeKeyList.size() < 1) {
								n_consigneeKeyList.add(n_consigneeKey);
							} else {
								if (!n_consigneeKeyList.contains(n_consigneeKey)) {
									errorMsg = "Please check number of consigneekey for shop group "+ shopGrp+ " and for wavekey "+ waveKey+ " and transmitlogkey "+ transmitLogKey;
									return errorMsg;
								}
							}
						}
						rSet2.close();
						pStmt2.close();
						int n_consKey = Integer.parseInt(n_consigneeKeyList.get(0));
						if (n_consKey != consigneeKeyList.size()) {
							errorMsg = "Please check number of consigneekey for shop group "+ shopGrp+" and wavekey "+ waveKey+ " and transmitlogkey "+ transmitLogKey;
							return errorMsg;
						} else {
							for (String consignKey : consigneeKeyList) {
								// sql:select distinct orderkey,n_orderkey from tl_out_1xw where transmitlogkey=? and wavekey=? and shopgroup=? and consigneekey=? order by orderkey
								String query3=DBConstant.SELECT_ORDERKEY;
								query3=query3.replace(ApplicationConstant.TL_OUT, ApplicationConstant.TL_OUT+dri);
								pStmt3 = con.prepareStatement(query3);
								pStmt3.setString(1, transmitLogKey);
								pStmt3.setString(2, waveKey);
								pStmt3.setString(3, shopGrp);
								pStmt3.setString(4, consignKey);
								rSet3 = pStmt3.executeQuery();
								ArrayList<String> orderKeyList = new ArrayList<String>();
								ArrayList<String> n_orderKeyList = new ArrayList<String>();
								while (rSet3.next()) {
									String orderKey = rSet3.getString(1);
									String n_orderKey = rSet3.getString(2);
									if (!orderKeyList.contains(orderKey)) {
										orderKeyList.add(orderKey);
									}
									if (n_orderKeyList.size() < 1) {
										n_orderKeyList.add(n_orderKey);
									} else {
										if (!n_orderKeyList.contains(n_orderKey)) {
											errorMsg = "Please check number of orderKey for consigneekey "+ consignKey+ " and shop group "+ shopGrp+ " and wavekey "+ waveKey+ " and transmitlogkey "+ transmitLogKey;
											return errorMsg;
										}
									}
								}
								rSet3.close();
								pStmt3.close();
								int n_ordrKey = Integer.parseInt(n_orderKeyList.get(0));
								if (n_ordrKey != orderKeyList.size()) {
									errorMsg = "Please check number of orderKey for consigneekey "+ consignKey+ " and shop group "+ shopGrp+ " and wavekey "+ waveKey+ " and transmitlogkey "+ transmitLogKey;
									return errorMsg;
								} else {
									for (String ordrKey : orderKeyList) {
										// sql:select distinct sku,n_orderline from tl_out_1xw where transmitlogkey=? and wavekey=? and shopgroup=? and consigneekey=? and orderkey=? order by sku
										String query4=DBConstant.SELECT_SKU;
										query4=query4.replace(ApplicationConstant.TL_OUT, ApplicationConstant.TL_OUT+dri);
										pStmt4 = con.prepareStatement(query4);
										pStmt4.setString(1, transmitLogKey);
										pStmt4.setString(2, waveKey);
										pStmt4.setString(3, shopGrp);
										pStmt4.setString(4, consignKey);
										pStmt4.setString(5, ordrKey);
										rSet4 = pStmt4.executeQuery();
										ArrayList<String> skuList = new ArrayList<String>();
										ArrayList<String> n_skuList = new ArrayList<String>();
										while (rSet4.next()) {
											String sku = rSet4.getString(1);
											String n_sku = rSet4.getString(2);
											if (!skuList.contains(sku)) {
												skuList.add(sku);
											}
											if (n_skuList.size() < 1) {
												n_skuList.add(n_sku);
											} else {
												if (!n_skuList.contains(n_sku)) {
													errorMsg = "Please check number of sku for orderkey "+ ordrKey+ " and consigneekey "+ consignKey+ " and shop group "+ shopGrp+ " and wavekey "+ waveKey+ " and transmitlogkey "+ transmitLogKey;
													return errorMsg;
												}
											}
										}
										rSet4.close();
										pStmt4.close();
										int no_sku = Integer.parseInt(n_skuList.get(0));
										if (no_sku != skuList.size()) {
											errorMsg = "Please check number of sku for orderkey "+ ordrKey+ " and consigneekey "+ consignKey+ " and shop group "+ shopGrp+ " and wavekey "+ waveKey+ " and transmitlogkey "+ transmitLogKey;
											return errorMsg;
										}
									}
								}
							}
						}
					}
				}
			} else { 
				errorMsg = "Wavekey found null for transmitlogkey "+ transmitLogKey;
				return errorMsg;
			}
		} catch (SQLException sqlException) {
			errorMsg = "Exception occured in validate1XW method while validating data "	+ sqlException.toString();
			log.error(errorMsg);
			sqlException.printStackTrace();
		} catch (Exception e) {
			errorMsg = "Exception occured in validate1XW method while validating data "	+ e.toString();
			log.error(errorMsg);
		}
		return errorMsg;
	}
	private String validate12N(String transmitLogKey,Connection con) throws Exception{
		PreparedStatement pStmt1 = null;
		ResultSet rSet1 = null;
		String errorMsg = null;
		try {
			// sql:select distinct targetstation,n_station from tl_out_12N where transmitlogkey=? order by targetstation
			pStmt1 = con.prepareStatement(DBConstant.SELECT_TARGETSTATION_12N);
			pStmt1.setString(1, transmitLogKey);
			rSet1 = pStmt1.executeQuery();
			ArrayList<String> targetstationList = new ArrayList<String>();
			ArrayList<String> n_targetstationList= new ArrayList<String>();
			while (rSet1.next()) {
				String targetstation = rSet1.getString(1);
				String n_targetstation = rSet1.getString(2);
				if (!targetstationList.contains(targetstation)) {
					targetstationList.add(targetstation);
				}
				if (n_targetstationList.size() < 1) {
					n_targetstationList.add(n_targetstation);
				} else {
					if (!n_targetstationList.contains(n_targetstation)) {
						errorMsg = "Please check number of target station for trasmitlogkey "+ transmitLogKey;
						return errorMsg;
					}
				}
			}
			rSet1.close();
			pStmt1.close();
			int no_targetstation = Integer.parseInt(n_targetstationList.get(0));
			if (no_targetstation != targetstationList.size()) {
				errorMsg = "Please check number of target station for trasmitlogkey "+ transmitLogKey;
				return errorMsg;
			}
		}catch (SQLException sqlException) {
			errorMsg = "Exception occured in validate12N method while validating data "	+ sqlException.toString();
			log.error(errorMsg);
			sqlException.printStackTrace();
		} catch (Exception e) {
			errorMsg = "Exception occured in validate12N method while validating data "	+ e.toString();
			log.error(errorMsg);
		}
		return errorMsg;
	}
}