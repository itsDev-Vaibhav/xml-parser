package com.vin.socket.inbound;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.vin.socket.config.Config;
import com.vin.socket.constant.ApplicationConstant;
import com.vin.socket.constant.DBConstant;
import com.vin.socket.util.Util;

public class Test {

	/**
	 * @param args
	 */
	private static Logger log = Logger.getLogger(Test.class);
	public static void main(String[] args) {
		Test st= new Test();
		try {
			st.processDataPacket() ;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub

	}
	private  void processDataPacket() throws IOException {
		String errorMsg=null;
		HashMap<String,String> map=null;
		String emailStatus=ApplicationConstant.NO;
		String dataPacket=null; 
		try {
			String Str1 = "000006432E13035100000002564001D135100000002564E06095736U06sorter";
			ArrayList<String> lst=new ArrayList<String>();
			lst.add(Str1);
			for(String str: lst){
				dataPacket=str;
				log.info("the data packet is : "+dataPacket);
				map=this.validateDataPacket(dataPacket);
				if(map.size()>0){
					errorMsg=this.insertToStage(map);//inserting data to stage table
					if(null==errorMsg && map.get(ApplicationConstant.PROCESSFLAG).equals(ApplicationConstant.ERROR)){
						errorMsg=map.get(ApplicationConstant.STATUS_MSG)+" found for data packet "+map.get(ApplicationConstant.DATAPACKET)+" and DRI "+map.get(ApplicationConstant.DRI);
						if(Config.SEND_JALERT.equals(ApplicationConstant.YES)){
							String errMsg = "<i>Attention</i><br><br>";
							errMsg += "An Exception occured in warehouse :"+Config.INSTANCE_NAME ;
							errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
							errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
							Util.SendMailSSL(Config.EMAIL_TO, "Import: Exception while datapacket processing", errMsg);
							emailStatus=ApplicationConstant.YES;
							}
						Util.insertToErrorLog("ImportSocketClient",map.get(ApplicationConstant.DRI),errorMsg,emailStatus);
						errorMsg=null;
					}
				}
		}
			}catch (Exception e) {
				errorMsg=ApplicationConstant.I_SOCKET_RECEIVE_EXCEPTION+e.toString();
				log.error(errorMsg);
			}
		if(null!=errorMsg && null!=dataPacket){
			if(Config.SEND_JALERT.equals(ApplicationConstant.YES)){
				String errMsg = "<i>Attention</i><br><br>";
				errMsg += "An Exception occured in warehouse :"+Config.INSTANCE_NAME ;
				errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
				errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
				Util.SendMailSSL(Config.EMAIL_TO, "Import: Exception while datapacket processing", errMsg);
				emailStatus=ApplicationConstant.YES;
				}
			if(null!=map){
				Util.insertToErrorLog("ImportSocketClient",map.get(ApplicationConstant.DRI),errorMsg,emailStatus);
			}
		}
	}
	private String insertToStage(HashMap<String,String> map){
		Connection con = null;
		PreparedStatement stmt = null;
		String errorMsg=null;
		try {
			con = Util.getConnection();
			if(null!=con){
			//sql:insert into  tl_in_data (BYTECOUNT,DATARECORDID,DATAPACKET,RETURNSTATUS,MSG,PROCESSFLAG,ADDDATE) values(?,?,?,?,?,?,sysdate)
			stmt = con.prepareStatement(DBConstant.INSERT_IN_DATA);
			stmt.setString(1, map.get(ApplicationConstant.BYTECOUNT));
			stmt.setString(2, map.get(ApplicationConstant.DRI));
			stmt.setString(3, map.get(ApplicationConstant.DATAPACKET));
			stmt.setString(4, map.get(ApplicationConstant.STATUS));
			stmt.setString(5, map.get(ApplicationConstant.STATUS_MSG));
			stmt.setString(6, map.get(ApplicationConstant.PROCESSFLAG));
			stmt.executeUpdate();
			}
		} catch (Exception exception) {
			errorMsg = ApplicationConstant.IMPORT_SOCKET_EXCEPTION
					.replace(ApplicationConstant.PARAM_1,DBConstant.INSERT_IN_DATA)
					.replace(ApplicationConstant.PARAM_2,map.get(ApplicationConstant.DRI))
					.replace(ApplicationConstant.PARAM_3,map.get(ApplicationConstant.DATAPACKET))+" "+exception.toString();
			log.error(errorMsg);
		} finally {
			try {
				if(null!=con){
					stmt.close();
					con.close();
				}
			} catch (SQLException sqlException) {
				errorMsg = ApplicationConstant.IMPORT_SOCKET_EXCEPTION
						.replace(ApplicationConstant.PARAM_1,DBConstant.INSERT_IN_DATA)
						.replace(ApplicationConstant.PARAM_2,map.get(ApplicationConstant.DRI))
						.replace(ApplicationConstant.PARAM_3,map.get(ApplicationConstant.DATAPACKET))+" "+sqlException.toString();
				log.error(errorMsg);
			}catch (Exception exception) {
				errorMsg = ApplicationConstant.IMPORT_SOCKET_EXCEPTION
						.replace(ApplicationConstant.PARAM_1,DBConstant.INSERT_IN_DATA)
						.replace(ApplicationConstant.PARAM_2,map.get(ApplicationConstant.DRI))
						.replace(ApplicationConstant.PARAM_3,map.get(ApplicationConstant.DATAPACKET))+" "+exception.toString();
				log.error(errorMsg);
			} 
		}
		if(null==errorMsg){
			if(null!=map.get(ApplicationConstant.ERR)){
				errorMsg=map.get(ApplicationConstant.ERR);
			}
		}else{
			if(null!=map.get(ApplicationConstant.ERR)){
				errorMsg=map.get(ApplicationConstant.ERR)+" and exception occurred while inserting data into tlv_in_data table "+errorMsg;
			}
		}
		return errorMsg;
	}
	private HashMap<String,String> validateDataPacket(String dataPacket){
		HashMap<String,String> map=new HashMap<String,String>();
		boolean errorFlag=false;
		String byteCountStr=null;
		if(dataPacket.length()>7){
			byteCountStr=dataPacket.substring(0,7);
			if(Util.isNumeric(byteCountStr)){
				int byteCount=Integer.parseInt(byteCountStr);
				if(byteCount==dataPacket.length()){
					map.put(ApplicationConstant.STATUS, ApplicationConstant.STATUS_00);
					map.put(ApplicationConstant.STATUS_MSG, Config.STATUS_MAP.get(ApplicationConstant.STATUS_00));
					map.put(ApplicationConstant.PROCESSFLAG,ApplicationConstant.ZERO);
				}else{
					map.put(ApplicationConstant.STATUS, ApplicationConstant.STATUS_10);
					map.put(ApplicationConstant.STATUS_MSG, Config.STATUS_MAP.get(ApplicationConstant.STATUS_10));
					map.put(ApplicationConstant.PROCESSFLAG,ApplicationConstant.ERROR);
				}
				dataPacket=dataPacket.substring(7,dataPacket.length());
				if(dataPacket.length()>2){
					String dri=dataPacket.substring(0,3);
					map.put(ApplicationConstant.DRI, dri);
					map.put(ApplicationConstant.DATAPACKET, dataPacket);
					map.put(ApplicationConstant.BYTECOUNT, byteCountStr);
				}else{
					errorFlag=true;
				}
			}else{
				errorFlag=true;
			}
		}else{
			errorFlag=true;
		}
		if(errorFlag){
			map.put(ApplicationConstant.STATUS, ApplicationConstant.STATUS_99);
			map.put(ApplicationConstant.DRI, ApplicationConstant.ERR);
			map.put(ApplicationConstant.DATAPACKET, dataPacket);
			map.put(ApplicationConstant.BYTECOUNT, byteCountStr);
			map.put(ApplicationConstant.PROCESSFLAG,ApplicationConstant.ERROR);
			map.put(ApplicationConstant.STATUS_MSG, Config.STATUS_MAP.get(ApplicationConstant.STATUS_99));
		}
		return map;
	}

}
