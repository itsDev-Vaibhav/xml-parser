package com.vin.socket.inbound;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ConnectException;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.vin.socket.config.Config;
import com.vin.socket.constant.ApplicationConstant;
import com.vin.socket.constant.DBConstant;
import com.vin.socket.util.Util;

public class ImportSocketClient {

	private static Logger log = Logger.getLogger(ImportSocketClient.class);
	
	public static void main(String[] args){
	if (Config.IMPORT_SOCKET_CLIENT.equals(ApplicationConstant.YES)) {
		ImportSocketClient importSocketClient= new ImportSocketClient();
		Socket socket= importSocketClient.getSocketConnction(Config.KISOFT_SERVER_IP, Config.KISOFT_SERVER_PORT_IN);
		String errorMsg=null;
		String emailStatus=ApplicationConstant.NO;
	if(null!=socket){
		while (null!=socket) {
			try {
				socket.setSoTimeout(Integer.parseInt(Config.SOCKET_TIMEOUT));
				socket.setTcpNoDelay(true);
				BufferedReader clientIn = new BufferedReader(new InputStreamReader(socket.getInputStream(), ApplicationConstant.ISO_STANDARD));//input stream created to receive data packet from WCS
				//BufferedWriter clientOut= new BufferedWriter( new OutputStreamWriter( socket.getOutputStream() ) );
				DataOutputStream clientOut = new DataOutputStream(socket.getOutputStream());//output stream created to send data packet to WCS
				socket = importSocketClient.processDataPacket(socket,clientIn,clientOut);//send data packet to WCS
				clientIn=null;
				clientOut=null;
			} catch (UnknownHostException e) {
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+ e.toString();
				log.error(errorMsg);
			} catch (IOException e) {
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+ e.toString();
				log.error(errorMsg);
			} catch (Exception e) {
				errorMsg=ApplicationConstant.I_SOCKET_RECEIVE_EXCEPTION+ e.toString();
				e.printStackTrace();
				log.error(errorMsg);
			}
			if(null==socket){
				socket= importSocketClient.getSocketConnction(Config.KISOFT_SERVER_IP, Config.KISOFT_SERVER_PORT_IN);
			}
		}
		}else{
			if (Config.IMPORT_SOCKET_CLIENT.equals(ApplicationConstant.YES)) {
			errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION;
			log.error(errorMsg);
			}
		}
		if(null!=errorMsg){
			if(Config.SEND_JALERT.equals(ApplicationConstant.YES)){
				String errMsg = "<i>Attention</i><br><br>";
				errMsg += "An Exception occured in warehouse :"+Config.INSTANCE_NAME ;
				errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
				errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
				Util.SendMailSSL(Config.EMAIL_TO, "ImportSocketClient: Socket Connection Exception", errMsg);
				emailStatus=ApplicationConstant.YES;
				}
			Util.insertToErrorLog("ImportSocketClient","Import: Socket Connection Exception",errorMsg,emailStatus);
		}
	}
	}
	
	private Socket getSocketConnction(String ip,String port){
		Socket socket=null;
		long start_time = System.currentTimeMillis();
		long wait_time =Long.parseLong(Config.WAIT_TIME);
		long end_time = start_time + wait_time;
		String errorMsg=null;
		while(null==socket && System.currentTimeMillis()<end_time){
			try {
				socket = new Socket(ip,Integer.parseInt(port));
			}catch (SocketTimeoutException e) {
				errorMsg=ApplicationConstant.I_SOCKET_RECEIVE_EXCEPTION+e.toString();
				log.error(errorMsg);
			}catch(ConnectException e){
				log.info("This is ConnectException ");
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+e.toString();
				log.error(errorMsg);
			}catch(SocketException e){
				log.info("This is SocketException ");
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+e.toString();
				log.error(errorMsg);
			}catch (IOException e) {
				log.info("This is IOException ");
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+e.toString();
				log.error(errorMsg);
			}catch (Exception e) {
				errorMsg=ApplicationConstant.I_SOCKET_RECEIVE_EXCEPTION+e.toString();
				log.error(errorMsg);
			}
			if(null==socket){
				log.error("Trying to reconnect.....");
			}
		}
		return socket;
	}
	private  Socket processDataPacket(Socket socket,BufferedReader clientIn,DataOutputStream  clientOut) throws IOException {
		String errorMsg=null;
		HashMap<String,String> map=null;
		String emailStatus=ApplicationConstant.NO;
		String dataPacket=null; 
		try {
				int i=0;
				StringBuilder dp=new StringBuilder();
				/*clientIn.readLine();
				dataPacket=clientIn.readLine();
				clientIn.readLine();*/
				while((i = clientIn.read())!=ApplicationConstant.CR_BYTE) {
			         if(i!=ApplicationConstant.LF_BYTE){
			        	 if(i!=-1){
			        		 dp.append((char)i);
			        	 }else{
			        		 throw new ConnectException(ApplicationConstant.I_SOCKET_CON_EXCEPTION);
			        	 }
			         }
		         }
				dataPacket=dp.toString();
			    dp=null;
				log.info(getTime()+" the data packet is : "+dataPacket);
				map=this.validateDataPacket(dataPacket);
				if(map.get(ApplicationConstant.STATUS).equals(ApplicationConstant.STATUS_00)){
				 errorMsg=parseDataPacket(map.get(ApplicationConstant.DRI), dataPacket);
				 if(null!=errorMsg){
					 map.put(ApplicationConstant.PROCESSFLAG,ApplicationConstant.ERROR);
					 map.put(ApplicationConstant.STATUS, ApplicationConstant.STATUS_99);
					 map.put(ApplicationConstant.STATUS_MSG, Config.STATUS_MAP.get(ApplicationConstant.STATUS_99));
					 map.put(ApplicationConstant.ERR, errorMsg);
				 }
				}
				log.info("message parsed at : "+getTime());
				errorMsg=this.insertToStage(map);//inserting data to stage table
				String statusMsg=null;
				if(map.size()>0){
					statusMsg=this.createStatusMsg(map);
					clientOut.write(statusMsg.getBytes());
					clientOut.flush();
					/*clientOut.write(statusMsg);
					clientOut.newLine();
					clientOut.flush();*/
					log.info(getTime()+" Status msg is: "+statusMsg);
					if(null==errorMsg && map.get(ApplicationConstant.PROCESSFLAG).equals(ApplicationConstant.ERROR)){
						errorMsg=map.get(ApplicationConstant.STATUS_MSG)+" found for data packet "+map.get(ApplicationConstant.DATAPACKET)+" and DRI "+map.get(ApplicationConstant.DRI);
						if(Config.SEND_JALERT.equals(ApplicationConstant.YES)){
							String errMsg = "<i>Attention</i><br><br>";
							errMsg += "An Exception occured in warehouse :"+Config.INSTANCE_NAME ;
							errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
							errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
							Util.SendMailSSL(Config.EMAIL_TO, "Import: Exception while datapacket processing", errMsg);
							emailStatus=ApplicationConstant.YES;
							}
						Util.insertToErrorLog("ImportSocketClient",map.get(ApplicationConstant.DRI),errorMsg,emailStatus);
						errorMsg=null;
					}
				}
			}catch (SocketTimeoutException e) {
				errorMsg=ApplicationConstant.I_SOCKET_RECEIVE_EXCEPTION+e.toString();
				//log.error(errorMsg);
				socket.close();
				clientOut.close();
				clientIn.close();
				socket=null;
				socket= this.getSocketConnction(Config.KISOFT_SERVER_IP, Config.KISOFT_SERVER_PORT_IN);
			}catch(ConnectException e){
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+e.toString();
				socket.close();
				clientOut.close();
				clientIn.close();
				socket=null;
				socket= this.getSocketConnction(Config.KISOFT_SERVER_IP, Config.KISOFT_SERVER_PORT_IN);
				log.error(errorMsg);
			}catch(SocketException e){
				log.info("This is SocketException ");
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+e.toString();
				socket.close();
				clientOut.close();
				clientIn.close();
				socket=null;
				socket= this.getSocketConnction(Config.KISOFT_SERVER_IP, Config.KISOFT_SERVER_PORT_IN);
				log.error(errorMsg);
			}catch (IOException e) {
				log.info("This is IOException ");
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+e.toString();
				log.error(errorMsg);
			}catch (Exception e) {
				errorMsg=ApplicationConstant.I_SOCKET_RECEIVE_EXCEPTION+e.toString();
				log.error(errorMsg);
			}
		if(null!=errorMsg && null!=dataPacket){
			if(Config.SEND_JALERT.equals(ApplicationConstant.YES)){
				String errMsg = "<i>Attention</i><br><br>";
				errMsg += "An Exception occured in warehouse :"+Config.INSTANCE_NAME ;
				errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
				errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
				Util.SendMailSSL(Config.EMAIL_TO, "Import: Exception while datapacket processing", errMsg);
				emailStatus=ApplicationConstant.YES;
				}
			if(null!=map){
				Util.insertToErrorLog("ImportSocketClient",map.get(ApplicationConstant.DRI),errorMsg,emailStatus);
			}
		}
		if(null==socket){
			clientOut.close();
			clientIn.close();
			socket= this.getSocketConnction(Config.KISOFT_SERVER_IP, Config.KISOFT_SERVER_PORT_IN);
		}
		return socket;
	}
	private HashMap<String,String> validateDataPacket(String dataPacket){
		HashMap<String,String> map=new HashMap<String,String>();
		boolean errorFlag=false;
		String byteCountStr=null;
		if(dataPacket.length()>7){
			byteCountStr=dataPacket.substring(0,7);
			if(Util.isNumeric(byteCountStr)){
				int byteCount=Integer.parseInt(byteCountStr);
				if(byteCount==dataPacket.length()){
					map.put(ApplicationConstant.STATUS, ApplicationConstant.STATUS_00);
					map.put(ApplicationConstant.STATUS_MSG, Config.STATUS_MAP.get(ApplicationConstant.STATUS_00));
					map.put(ApplicationConstant.PROCESSFLAG,ApplicationConstant.ZERO);
				}else{
					map.put(ApplicationConstant.STATUS, ApplicationConstant.STATUS_10);
					map.put(ApplicationConstant.STATUS_MSG, Config.STATUS_MAP.get(ApplicationConstant.STATUS_10));
					map.put(ApplicationConstant.PROCESSFLAG,ApplicationConstant.ERROR);
				}
				dataPacket=dataPacket.substring(7,dataPacket.length());
				if(dataPacket.length()>2){
					String dri=dataPacket.substring(0,3);
					map.put(ApplicationConstant.DRI, dri);
					map.put(ApplicationConstant.DATAPACKET, dataPacket);
					map.put(ApplicationConstant.BYTECOUNT, byteCountStr);
				}else{
					errorFlag=true;
				}
			}else{
				errorFlag=true;
			}
		}else{
			errorFlag=true;
		}
		if(errorFlag){
			map.put(ApplicationConstant.STATUS, ApplicationConstant.STATUS_99);
			map.put(ApplicationConstant.DRI, ApplicationConstant.ERR);
			map.put(ApplicationConstant.DATAPACKET, dataPacket);
			map.put(ApplicationConstant.BYTECOUNT, byteCountStr);
			map.put(ApplicationConstant.PROCESSFLAG,ApplicationConstant.ERROR);
			map.put(ApplicationConstant.STATUS_MSG, Config.STATUS_MAP.get(ApplicationConstant.STATUS_99));
		}
		return map;
	}
	
	private String createStatusMsg(HashMap<String,String> map ){
		String statusMsg=null; 
		try{
		String dri=Config.IMPORT_STATUS_INT_MAP.get(map.get(ApplicationConstant.DRI));
		if(null==dri){
			dri=ApplicationConstant.ERR;
		}
		String statusMsgTemplate= Config.STATUS_MSG_TEMPLATE;
		statusMsg = statusMsgTemplate
				.replace(ApplicationConstant.LF, ApplicationConstant.LF_CHARACTER)
				.replace(ApplicationConstant.BYTECOUNT, this.getByteCount(map))
				.replace(ApplicationConstant.DRI, dri)
				.replace(ApplicationConstant.STATUS,map.get(ApplicationConstant.STATUS))
				.replace(ApplicationConstant.CR, ApplicationConstant.CR_CHARACTER);
		}catch(Exception e){
			log.error("Exception occured in createStatusMsg method "+e.toString());
		}
		return statusMsg;
	}
	private String getByteCount(HashMap<String,String> map){
		String byteCount=null; 
		try{
		int driLength= map.get(ApplicationConstant.DRI).length();
		int statusLength= map.get(ApplicationConstant.STATUS).length();
		int totalByteCount=driLength+statusLength+7;
		String byteCountLength=String.valueOf(totalByteCount);
		int len=byteCountLength.length();
		int totalZero=7-len;
		String zero="";
		for(int i=0;i<totalZero;i++){
			zero=zero.concat(ApplicationConstant.ZERO); 
		}
		byteCount=zero.concat(byteCountLength);
		}catch(Exception e){
			log.error("Exception occured in getByteCount method "+e.toString());
		}
		return byteCount;
	}
	
	private String insertToStage(HashMap<String,String> map){
		Connection con = null;
		PreparedStatement stmt = null;
		String errorMsg=null;
		try {
			con = Util.getConnection();
			if(null!=con){
			//sql:insert into  tl_in_data (BYTECOUNT,DATARECORDID,DATAPACKET,RETURNSTATUS,MSG,PROCESSFLAG,ADDDATE) values(?,?,?,?,?,?,sysdate)
			stmt = con.prepareStatement(DBConstant.INSERT_IN_DATA);
			stmt.setString(1, map.get(ApplicationConstant.BYTECOUNT));
			stmt.setString(2, map.get(ApplicationConstant.DRI));
			stmt.setString(3, map.get(ApplicationConstant.DATAPACKET));
			stmt.setString(4, map.get(ApplicationConstant.STATUS));
			stmt.setString(5, map.get(ApplicationConstant.STATUS_MSG));
			stmt.setString(6, map.get(ApplicationConstant.PROCESSFLAG));
			stmt.executeUpdate();
			}
		} catch (SQLException sqlException) {
			errorMsg = ApplicationConstant.IMPORT_SOCKET_EXCEPTION
					.replace(ApplicationConstant.PARAM_1,DBConstant.INSERT_IN_DATA)
					.replace(ApplicationConstant.PARAM_2,map.get(ApplicationConstant.DRI))
					.replace(ApplicationConstant.PARAM_3,map.get(ApplicationConstant.DATAPACKET))+" "+sqlException.toString();
			log.error(errorMsg);
		}catch (Exception exception) {
			errorMsg = ApplicationConstant.IMPORT_SOCKET_EXCEPTION
					.replace(ApplicationConstant.PARAM_1,DBConstant.INSERT_IN_DATA)
					.replace(ApplicationConstant.PARAM_2,map.get(ApplicationConstant.DRI))
					.replace(ApplicationConstant.PARAM_3,map.get(ApplicationConstant.DATAPACKET))+" "+exception.toString();
			log.error(errorMsg);
		} finally {
			try {
				if(null!=con){
					stmt.close();
					con.close();
				}
			} catch (SQLException sqlException) {
				errorMsg = ApplicationConstant.IMPORT_SOCKET_EXCEPTION
						.replace(ApplicationConstant.PARAM_1,DBConstant.INSERT_IN_DATA)
						.replace(ApplicationConstant.PARAM_2,map.get(ApplicationConstant.DRI))
						.replace(ApplicationConstant.PARAM_3,map.get(ApplicationConstant.DATAPACKET))+" "+sqlException.toString();
				log.error(errorMsg);
			}catch (Exception exception) {
				errorMsg = ApplicationConstant.IMPORT_SOCKET_EXCEPTION
						.replace(ApplicationConstant.PARAM_1,DBConstant.INSERT_IN_DATA)
						.replace(ApplicationConstant.PARAM_2,map.get(ApplicationConstant.DRI))
						.replace(ApplicationConstant.PARAM_3,map.get(ApplicationConstant.DATAPACKET))+" "+exception.toString();
				log.error(errorMsg);
			} 
		}
		if(null==errorMsg){
			if(null!=map.get(ApplicationConstant.ERR)){
				errorMsg=map.get(ApplicationConstant.ERR);
			}
		}else{
			if(null!=map.get(ApplicationConstant.ERR)){
				errorMsg=map.get(ApplicationConstant.ERR)+" and exception occurred while inserting data into tlv_in_data table "+errorMsg;
			}
		}
		return errorMsg;
	}
	private static String parseDataPacket(String dri,String pDataPacket){
		LinkedHashMap<String,String> dataMap=new LinkedHashMap<String, String>();
		LinkedHashMap<String,Object> packetMap=new LinkedHashMap<String,Object>();
		String errorMsg=null;
		String dataPacket=null;
		try{
		dataPacket=pDataPacket.substring(7,pDataPacket.length());
		String template=Config.IMPORT_PARSE_TEMPLATE.get(dri);
		String tempArr[]=template.split(ApplicationConstant.COMMA);
		for(String index:tempArr){
			int i=1;
			if(!index.contains(ApplicationConstant.LOOP)){
			String[] indexArr=index.split(Pattern.quote(ApplicationConstant.ASTRICK) );
			dataMap.put(ApplicationConstant.DATA+ApplicationConstant.ZERO, ApplicationConstant.SERIALKEY);
			for(String inde:indexArr){
				if(inde.contains(ApplicationConstant.DASH)){
					inde=dataMap.get(ApplicationConstant.DATA+ApplicationConstant.LENGTH+(i-1));
					String data=dataPacket.substring(0,Integer.parseInt(inde));
					dataMap.put(ApplicationConstant.DATA+i, data);
					dataPacket=dataPacket.substring(Integer.parseInt(inde));
				}else{
					if(inde.contains(ApplicationConstant.LENGTH)){
						String [] lenStr=inde.split(ApplicationConstant.UNDERSCORE);
						inde=lenStr[0];
						String data=dataPacket.substring(0,Integer.parseInt(inde));
						dataMap.put(ApplicationConstant.DATA+ApplicationConstant.LENGTH+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(inde));
					}else{
						String data=dataPacket.substring(0,Integer.parseInt(inde));
						dataMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(inde));
					}
				}
				i++;
			}
		}
		}
		if(null!=tempArr && tempArr.length>1){
		String []loop=template.substring(template.indexOf(ApplicationConstant.LOOP)).replace(ApplicationConstant.LOOP+ApplicationConstant.ASTRICK, ApplicationConstant.EMPTYSTRING) .split(ApplicationConstant.COMMA);
		if(null!=loop && loop.length<4 ){
		String loop1=loop[0];
		String loop2=loop[1];
		String loop3=loop[2];
		String [] loopArr1=loop1.split(Pattern.quote(ApplicationConstant.ASTRICK));
		String [] loopArr2=loop2.split(Pattern.quote(ApplicationConstant.ASTRICK));
		String [] loopArr3=loop3.split(Pattern.quote(ApplicationConstant.ASTRICK));
		int s1=Integer.parseInt(dataMap.get(ApplicationConstant.DATA+(dataMap.size()-1)));
		int i=0;
		LinkedHashMap<String,String> lpMap=new LinkedHashMap<String,String>();
		LinkedHashMap<String,String> myMap= null;
		ArrayList<LinkedHashMap<String,String>> list=new ArrayList<LinkedHashMap<String,String>>();
		while(s1>0){
			String dRow1="";
		for(String shop:loopArr1){
			if(shop.contains(ApplicationConstant.DASH)){
				shop=lpMap.get(ApplicationConstant.DATA+(i-1));
				dRow1=dRow1.concat(dataPacket.substring(0,Integer.parseInt(shop))).concat(ApplicationConstant.COMMA);
				String data=dataPacket.substring(0,Integer.parseInt(shop));
				lpMap.put(ApplicationConstant.DATA+i, data);
				dataPacket=dataPacket.substring(Integer.parseInt(shop));
			}else{
				if(shop.contains(ApplicationConstant.LENGTH)){
					String [] lenStr=shop.split(ApplicationConstant.UNDERSCORE);
					shop=lenStr[0];
					String data=dataPacket.substring(0,Integer.parseInt(shop));
					lpMap.put(ApplicationConstant.DATA+i, data);
					dataPacket=dataPacket.substring(Integer.parseInt(shop));
				}else{
					dRow1=dRow1.concat(dataPacket.substring(0,Integer.parseInt(shop))).concat(ApplicationConstant.COMMA);
					String data=dataPacket.substring(0,Integer.parseInt(shop));
					lpMap.put(ApplicationConstant.DATA+i, data);
					dataPacket=dataPacket.substring(Integer.parseInt(shop));
				}
			}
			i++;
		}
		dRow1=dRow1.substring(0,dRow1.length()-1);
		s1--;
		int s2=Integer.parseInt(lpMap.get(ApplicationConstant.DATA+(i-1)));
		while(s2>0){
			String dRow2="";
			for(String order:loopArr2){
				if(order.contains(ApplicationConstant.DASH)){
					order=lpMap.get(ApplicationConstant.DATA+(i-1));
					dRow2=dRow2.concat(dataPacket.substring(0,Integer.parseInt(order))).concat(ApplicationConstant.COMMA);
					String data=dataPacket.substring(0,Integer.parseInt(order));
					lpMap.put(ApplicationConstant.DATA+i, data);
					dataPacket=dataPacket.substring(Integer.parseInt(order));
				}else{
					if(order.contains(ApplicationConstant.LENGTH)){
						String [] lenStr=order.split(ApplicationConstant.UNDERSCORE);
						order=lenStr[0];
						String data=dataPacket.substring(0,Integer.parseInt(order));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(order));
					}else{
						dRow2=dRow2.concat(dataPacket.substring(0,Integer.parseInt(order))).concat(ApplicationConstant.COMMA);
						String data=dataPacket.substring(0,Integer.parseInt(order));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(order));
					}
				}
				i++;
			}
			dRow2=dRow2.substring(0,dRow2.length()-1);
			dRow2=dRow1.concat(ApplicationConstant.COMMA).concat(dRow2);
			s2--;
			int s3=Integer.parseInt(lpMap.get(ApplicationConstant.DATA+(i-1)));
			while(s3>0){
				String dRow3="";
				for(String article:loopArr3){
					if(article.contains(ApplicationConstant.DASH)){
						article=lpMap.get(ApplicationConstant.DATA+(i-1));
						dRow3=dRow3.concat(dataPacket.substring(0,Integer.parseInt(article))).concat(ApplicationConstant.COMMA);
						String data=dataPacket.substring(0,Integer.parseInt(article));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(article));
					}else{
						if(article.contains(ApplicationConstant.LENGTH)){
							String [] lenStr=article.split(ApplicationConstant.UNDERSCORE);
							article=lenStr[0];
							String data=dataPacket.substring(0,Integer.parseInt(article));
							lpMap.put(ApplicationConstant.DATA+i, data);
							dataPacket=dataPacket.substring(Integer.parseInt(article));
						}else{
							dRow3=dRow3.concat(dataPacket.substring(0,Integer.parseInt(article))).concat(ApplicationConstant.COMMA);
							String data=dataPacket.substring(0,Integer.parseInt(article));
							lpMap.put(ApplicationConstant.DATA+i, data);
							dataPacket=dataPacket.substring(Integer.parseInt(article));
						}
					}
					i++;
				}
				dRow3=dRow3.substring(0,dRow3.length()-1);
				dRow3=dRow2.concat(ApplicationConstant.COMMA).concat(dRow3);
				s3--;
				myMap=new LinkedHashMap<String,String>();
				myMap.put(ApplicationConstant.LOOP, dRow3);
				list.add(myMap);
			}
		}
		}
		packetMap.put(ApplicationConstant.DETAIL, list);
		}else{
                /***************short and pack starts******************/
			
			String loop1=loop[0];
			String loop2=loop[1];
			String loop3=loop[2];
			String loop4=loop[3];
			String [] loopArr1=loop1.split(Pattern.quote(ApplicationConstant.ASTRICK));
			String [] loopArr2=loop2.split(Pattern.quote(ApplicationConstant.ASTRICK));
			String [] loopArr3=loop3.split(Pattern.quote(ApplicationConstant.ASTRICK));
			String [] loopArr4=loop4.split(Pattern.quote(ApplicationConstant.ASTRICK));
			int s1=Integer.parseInt(dataMap.get(ApplicationConstant.DATA+(dataMap.size()-1)));
			int i=0;
			LinkedHashMap<String,String> lpMap=new LinkedHashMap<String,String>();
			LinkedHashMap<String,String> myMap= null;
			ArrayList<LinkedHashMap<String,String>> list=new ArrayList<LinkedHashMap<String,String>>();
			while(s1>0){
				String dRow1="";
			for(String shop:loopArr1){
				if(shop.contains(ApplicationConstant.DASH)){
					shop=lpMap.get(ApplicationConstant.DATA+(i-3));
					dRow1=dRow1.concat(dataPacket.substring(0,Integer.parseInt(shop))).concat(ApplicationConstant.COMMA);
					String data=dataPacket.substring(0,Integer.parseInt(shop));
					lpMap.put(ApplicationConstant.DATA+i, data);
					dataPacket=dataPacket.substring(Integer.parseInt(shop));
				}else{
					if(shop.contains(ApplicationConstant.LENGTH)){
						String [] lenStr=shop.split(ApplicationConstant.UNDERSCORE);
						shop=lenStr[0];
						String data=dataPacket.substring(0,Integer.parseInt(shop));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(shop));
					}else{
						dRow1=dRow1.concat(dataPacket.substring(0,Integer.parseInt(shop))).concat(ApplicationConstant.COMMA);
						String data=dataPacket.substring(0,Integer.parseInt(shop));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(shop));
					}
				}
				i++;
			}
			dRow1=dRow1.substring(0,dRow1.length()-1);
			s1--;
			int s2=Integer.parseInt(lpMap.get(ApplicationConstant.DATA+(i-1)));
			while(s2>0){
				String dRow2="";
				for(String loadUnit:loopArr2){
					if(loadUnit.contains(ApplicationConstant.LENGTH)){
						String [] lenStr=loadUnit.split(ApplicationConstant.UNDERSCORE);
						loadUnit=lenStr[0];
						String data=dataPacket.substring(0,Integer.parseInt(loadUnit));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(loadUnit));
					}else{
						dRow2=dRow2.concat(dataPacket.substring(0,Integer.parseInt(loadUnit))).concat(ApplicationConstant.COMMA);
						String data=dataPacket.substring(0,Integer.parseInt(loadUnit));
						lpMap.put(ApplicationConstant.DATA+i, data);
						dataPacket=dataPacket.substring(Integer.parseInt(loadUnit));
					}
					i++;
				}
				dRow2=dRow2.substring(0,dRow2.length()-1);
				dRow2=dRow1.concat(ApplicationConstant.COMMA).concat(dRow2);
				s2--;
				int s3=Integer.parseInt(lpMap.get(ApplicationConstant.DATA+(i-1)));
				while(s3>0){
					String dRow3="";
					for(String order:loopArr3){
						if(order.contains(ApplicationConstant.DASH)){
							order=lpMap.get(ApplicationConstant.DATA+(i-2));
							dRow3=dRow3.concat(dataPacket.substring(0,Integer.parseInt(order))).concat(ApplicationConstant.COMMA);
							String data=dataPacket.substring(0,Integer.parseInt(order));
							lpMap.put(ApplicationConstant.DATA+i, data);
							dataPacket=dataPacket.substring(Integer.parseInt(order));
						}else{
							if(order.contains(ApplicationConstant.LENGTH)){
								String [] lenStr=order.split(ApplicationConstant.UNDERSCORE);
								order=lenStr[0];
								String data=dataPacket.substring(0,Integer.parseInt(order));
								lpMap.put(ApplicationConstant.DATA+i, data);
								dataPacket=dataPacket.substring(Integer.parseInt(order));
							}else{
								dRow3=dRow3.concat(dataPacket.substring(0,Integer.parseInt(order))).concat(ApplicationConstant.COMMA);
								String data=dataPacket.substring(0,Integer.parseInt(order));
								lpMap.put(ApplicationConstant.DATA+i, data);
								dataPacket=dataPacket.substring(Integer.parseInt(order));
							}
						}
						i++;
					}
					dRow3=dRow3.substring(0,dRow3.length()-1);
					dRow3=dRow2.concat(ApplicationConstant.COMMA).concat(dRow3);
					s3--;
					int s4=Integer.parseInt(lpMap.get(ApplicationConstant.DATA+(i-1)));
					while(s4>0){
						String dRow4="";
						for(String article:loopArr4){
							if(article.contains(ApplicationConstant.DASH)){
								article=lpMap.get(ApplicationConstant.DATA+(i-2));
								dRow4=dRow4.concat(dataPacket.substring(0,Integer.parseInt(article))).concat(ApplicationConstant.COMMA);
								String data=dataPacket.substring(0,Integer.parseInt(article));
								lpMap.put(ApplicationConstant.DATA+i, data);
								dataPacket=dataPacket.substring(Integer.parseInt(article));
							}else{
								if(article.contains(ApplicationConstant.LENGTH)){
									String [] lenStr=article.split(ApplicationConstant.UNDERSCORE);
									article=lenStr[0];
									String data=dataPacket.substring(0,Integer.parseInt(article));
									lpMap.put(ApplicationConstant.DATA+i, data);
									dataPacket=dataPacket.substring(Integer.parseInt(article));
								}else{
									dRow4=dRow4.concat(dataPacket.substring(0,Integer.parseInt(article))).concat(ApplicationConstant.COMMA);
									String data=dataPacket.substring(0,Integer.parseInt(article));
									lpMap.put(ApplicationConstant.DATA+i, data);
									dataPacket=dataPacket.substring(Integer.parseInt(article));
								}
							}
							i++;
						}
						dRow4=dRow4.substring(0,dRow4.length()-1);
						dRow4=dRow3.concat(ApplicationConstant.COMMA).concat(dRow4);
						s4--;
					myMap=new LinkedHashMap<String,String>();
					myMap.put(ApplicationConstant.LOOP, dRow4);
					list.add(myMap);
					}
				}
			}
			}
			packetMap.put(ApplicationConstant.DETAIL, list);
			/***************short and pack ends******************/
		}
		}
		
		Iterator<Map.Entry<String, String>> entries = dataMap.entrySet().iterator();
		while(entries.hasNext()){
			Map.Entry<String, String> entry = entries.next();
			if(entry.getKey().contains(ApplicationConstant.LENGTH)){
				entries.remove();
			}
		}
		}catch(Exception e){
			errorMsg=ApplicationConstant.IMPORT_EXCEPTION_MSG.replace(ApplicationConstant.PARAM_1, dri).replace(ApplicationConstant.PARAM_2, pDataPacket)+" "+ e.toString();
			log.error(errorMsg);
		}
		if(dataPacket.length()>0){
			errorMsg=ApplicationConstant.IMPORT_EXCEPTION_MSG.replace(ApplicationConstant.PARAM_1, dri).replace(ApplicationConstant.PARAM_2, pDataPacket)+" [Wrong data in message] ";
		}
		return errorMsg;
	}
	private String getTime(){
		  SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss:SSS");
		  String time=format.format(new Date());
		  return time;
	}
}
