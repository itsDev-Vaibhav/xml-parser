package com.vin.socket.constant;


public interface DBConstant {
	//for Socket import interface
	public String INSERT_IN_DATA="insert into  tlv_in_data (BYTECOUNT,DATARECORDID,DATAPACKET,RETURNSTATUS,MSG,PROCESSFLAG,ADDDATE) values(?,?,?,?,?,?,sysdate)";
	
	/*****************************************************************NOTE*******************************************************************************
	 * for inserting extracted data from data_packet into import tables, insert query is dynamically generated through code 
	 * The java file name ImportDataParser and method is createInsertSql() used for it.
	 * In the method createInsertSql() we are getting specific table name from ImportParseTable.properties  
	 * with the help of IMPORT_PARSE_TABLE map variable of Config.java file that contains mapping of import interface name and table name.
	 *************************************************************************************************************************************************/
	//insert to error log table
	public String INSERT_TO_ERRORLOG="Insert into tl_ERROR_LOG (PROGRAMNAME, ERRORKEY, ERRORMESSAGE,EMAIL_ALERT) Values (?, ?, ?, ?)";
}
