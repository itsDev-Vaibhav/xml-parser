package com.vin.socket.util;

import org.apache.commons.dbcp2.BasicDataSource;

import com.vin.socket.config.Config;

public class ConnectionPool {
	private static BasicDataSource dataSource;

	public static BasicDataSource getDataSource() {
		if (dataSource == null) {
			BasicDataSource ds = new BasicDataSource();
			ds.setUrl(Config.URL);
			ds.setUsername(Config.DBUSER);
			ds.setPassword(Config.PASS);
			ds.setMinIdle(2);
			ds.setMaxIdle(7);
			ds.setMaxOpenPreparedStatements(100);
			dataSource = ds;
		}
		return dataSource;

	}
}