package com.vin.socket.constant;


public interface DBConstant {
	//for Socket import interface
	public String INSERT_IN_DATA="insert into  tl_in_data (BYTECOUNT,DATARECORDID,DATAPACKET,RETURNSTATUS,MSG,PROCESSFLAG,ADDDATE) values(?,?,?,?,?,?,sysdate)";
	
	/*****************************************************************NOTE*******************************************************************************
	 * for inserting extracted data from data_packet into import tables, insert query is dynamically generated through code 
	 * The java file name ImportDataParser and method is createInsertSql() used for it.
	 * In the method createInsertSql() we are getting specific table name from ImportParseTable.properties  
	 * with the help of IMPORT_PARSE_TABLE map variable of Config.java file that contains mapping of import interface name and table name.
	 *************************************************************************************************************************************************/
	//for Socket Export interface
	//COUNT_ART_MST_HEADER is being used in two classes ExportSocketClient and ExportDataComposer
	public String COUNT_ART_MST_DATA="select count(distinct TRANSMITLOGKEY)  from tlv_out_data where processflag in (?,?) and datarecordid=?";
	public String SELECT_ART_MST_DATA = "select * from (select transmitlogkey,DATAPACKET  from tlv_out_data where processflag=? and datarecordid=? order by transmitlogkey) where rownum<101";
	public String SELECT_OUT_DATA="select transmitlogkey,DATAPACKET  from tlv_out_data where processflag=? and datarecordid=? order by transmitlogkey";
	public String UPDATE_OUT_DATA="update tlv_out_data set PROCESSFLAG=?,RETURNSTATUS=?,MSG=?,PROCESSDATE =systimestamp where processflag=? and transmitlogkey=? and datarecordid=?";
	public String UPDATE_ART_MST_DATA="update tlv_out_data set PROCESSFLAG=?,PROCESSDATE =sysdate where processflag=? and datarecordid=?";
	
	//insert to error log table
	public String INSERT_TO_ERRORLOG="Insert into tl_ERROR_LOG (PROGRAMNAME, ERRORKEY, ERRORMESSAGE,EMAIL_ALERT) Values (?, ?, ?, ?)";
}
