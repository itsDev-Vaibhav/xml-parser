package com.vin.socket.startProcess;


public class StartSocketProcess {
	//private static Logger log = Logger.getLogger(StartSocketProcess.class);

	public static void main(String[] args) {/*
		log.info("starting StartSocketProcess main  method");
		try {
			if (Config.IMPORT_SOCKET_CLIENT.equals(ApplicationConstant.YES)) {
				ImportSocketClient iClient = new ImportSocketClient();
				iClient.startImportSocket();
			}
			if (Config.EXPORT_SOCKET_CLIENT.equals(ApplicationConstant.YES)) {
				ExportSocketClient eClient = new ExportSocketClient();
				eClient.startExportSocket();
			}
			
		} catch (Exception e) {
			log.error("Exception occured in  StartSocketProcess main method " + e);
		}
		log.info("starting StartSocketProcess main  method");
	*/}

}
