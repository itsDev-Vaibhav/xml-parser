package com.vin.socket.outbound;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.vin.socket.config.Config;
import com.vin.socket.constant.ApplicationConstant;
import com.vin.socket.constant.DBConstant;
import com.vin.socket.util.Util;

public class ExportSocketClient {


	private static Logger log = Logger.getLogger(ExportSocketClient.class);
	
	
	public static void main(String[] args) throws Exception{
	if (Config.EXPORT_SOCKET_CLIENT.equals(ApplicationConstant.YES)) {
		ExportSocketClient exportSocketClient= new ExportSocketClient();
		Socket socket= exportSocketClient.getSocketConnction(Config.KISOFT_SERVER_IP, Config.KISOFT_SERVER_PORT_OUT); //getting socket connection
		String errorMsg=null;
		String emailStatus=ApplicationConstant.NO;
		if(null!=socket){
			try {
				while (null!=socket) {
					socket.setSoTimeout(Integer.parseInt(Config.SOCKET_TIMEOUT));//setting connection time out to get response from server
					BufferedReader clientIn =null;
					BufferedWriter clientOut= null;
					ArrayList<String> arrayList = new ArrayList<String>(Arrays.asList(Config.EXPORT_STATUS_INT_MAP.get(ApplicationConstant.DRI).split(ApplicationConstant.COMMA))); 
					outer:
					for(String dri: arrayList){
						 clientIn = new BufferedReader(new InputStreamReader(socket.getInputStream(), ApplicationConstant.ISO_STANDARD));//Input stream created to receive data from server
						 clientOut= new BufferedWriter( new OutputStreamWriter( socket.getOutputStream() ) );//output stream created to send data to server
						if(!(dri.equals(ApplicationConstant.DRI_1A0)||dri.equals(ApplicationConstant.DRI_1A1)|| dri.equals(ApplicationConstant.DRI_1A9))){
							if(dri.equals(ApplicationConstant.DRI_1AN) || dri.equals(ApplicationConstant.DRI_1AD)){ //need to add timing to run this interface
								if(exportSocketClient.isValidTimeToRun(dri)){
									 socket = exportSocketClient.processArtMasterData(socket, clientIn,clientOut, dri);// sending Article Master data to server
								}
							 }else{
								 if(exportSocketClient.isValidTimeToRun(dri)){
									HashMap<String,Object> socketMap = exportSocketClient.processDataPacket(socket,clientIn, clientOut,dri);// sending other data to server except Article master data
									socket=(Socket) socketMap.get(ApplicationConstant.SOCKET);
									String socketMsg=(String) socketMap.get(ApplicationConstant.ERROR);
									if(null!=socketMsg){
										break outer;
									}
								 }
							 }
						}
					}
			}
			} catch (UnknownHostException e) {
				errorMsg=ApplicationConstant.E_SOCKET_CON_EXCEPTION+e.toString();
				log.error(errorMsg);
				
			} catch (IOException e) {
				errorMsg=ApplicationConstant.E_SOCKET_CON_EXCEPTION+e.toString();
				log.error(errorMsg);
			}
		}else{
			errorMsg=ApplicationConstant.E_SOCKET_CON_EXCEPTION;
			log.error(errorMsg);
			
		}
		if(null!=errorMsg){
			if(Config.SEND_JALERT.equals(ApplicationConstant.YES)){
				String errMsg = "<i>Attention</i><br><br>";
				errMsg += "An Exception occured in warehouse :"+Config.INSTANCE_NAME ;
				errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
				errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
				Util.SendMailSSL(Config.EMAIL_TO, "Export: Socket Connection exception occured", errMsg);
				emailStatus=ApplicationConstant.YES;
				}
			Util.insertToErrorLog("ExportSocketClient","Export: Socket Connection Exception",errorMsg,emailStatus);
		}
	}
}

	private HashMap<String,Object> processDataPacket(Socket socket, BufferedReader clientIn,BufferedWriter clientOut,String dri)throws IOException {
		//HashMap<String, String> map =null;
		String errorMsg=null;
		String emailStatus=ApplicationConstant.NO;
		String transmitLogKey=null;
		try {
			
			ArrayList<HashMap<String,String>> list=	this.getDataPacket(dri); //get list of map of serialkey and dataPacket
		for(HashMap<String, String> map: list){
		// map = (HashMap<String, String>) 
			if (null != map) {
				String retStatus = null;
				String status =null;
				String dataPacket = map.get(ApplicationConstant.DATAPACKET);
				dataPacket=ApplicationConstant.LF_CHARACTER.concat(dataPacket).concat(ApplicationConstant.CR_CHARACTER);
				transmitLogKey = map.get(ApplicationConstant.TRANSMITLOGKEY);
				clientOut.write(dataPacket);
				clientOut.newLine();
				clientOut.flush();
				int i = 0;
				log.info("The data packet sent is: "+dataPacket);
				StringBuilder statusMsg = new StringBuilder();
				while ((i = clientIn.read()) != ApplicationConstant.CR_BYTE) {
					if (i != ApplicationConstant.LF_BYTE) {
						if(i!=-1){
							statusMsg.append((char)i);
			        	 }else{
			        		 throw new ConnectException(ApplicationConstant.I_SOCKET_CON_EXCEPTION);
			        	 }
					}
				}
				retStatus = statusMsg.toString();
				log.info("return status is: "+retStatus);
				HashMap<String,String>statusMap = this.getStatusMsg(retStatus,dri);
				status=statusMap.get(ApplicationConstant.STATUS);
				errorMsg=statusMap.get(ApplicationConstant.ERROR);
				if(null!=errorMsg || !status.equals(ApplicationConstant.STATUS_00)){
					String statusDesr=null;
					if(null==status){
						statusDesr=errorMsg;
					}else{
						statusDesr=Config.STATUS_MAP.get(status);
						if(null==statusDesr){
							statusDesr="Unknown return status code found : "+status;
						}
					}
					if(Config.SEND_JALERT.equals(ApplicationConstant.YES)){
						String errMsg = "<i>Attention</i><br><br>";
						errMsg += "An Exception occured in warehouse :"+Config.INSTANCE_NAME +" for dri: "+dri+" and transmitlogkey: "+transmitLogKey;
						errMsg += "<br>The exception is given below :<br><br>"+statusDesr ;
						errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
						Util.SendMailSSL(Config.EMAIL_TO, "Export: Exception occured, while exporting data to WCS", errMsg+" "+errorMsg);
						emailStatus=ApplicationConstant.YES;
						}
					Util.insertToErrorLog(dri,transmitLogKey,statusDesr,emailStatus);
				}
				errorMsg=this.updateRetStatusData(transmitLogKey,status,retStatus,dri,errorMsg);//updating processflag=as per result
			}
		}
			}catch (SocketTimeoutException e) {
				errorMsg=ApplicationConstant.I_SOCKET_RECEIVE_EXCEPTION+" for dri "+dri+" and transmitlogkey "+transmitLogKey+e.toString();
				log.error(errorMsg);
				socket.close();
				clientOut.close();
				clientIn.close();
				socket=null;
				socket= this.getSocketConnction(Config.KISOFT_SERVER_IP, Config.KISOFT_SERVER_PORT_OUT);
			}catch(ConnectException e){
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+e.toString();
				socket.close();
				clientOut.close();
				clientIn.close();
				socket=null;
				socket= this.getSocketConnction(Config.KISOFT_SERVER_IP, Config.KISOFT_SERVER_PORT_OUT);
				log.error(errorMsg);
			}catch(SocketException e){
				log.error("This is SocketException ");
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+e.toString();
				socket.close();
				clientOut.close();
				clientIn.close();
				socket=null;
				socket= this.getSocketConnction(Config.KISOFT_SERVER_IP, Config.KISOFT_SERVER_PORT_OUT);
				log.error(errorMsg);
			}catch (IOException e) {
				log.error("This is IOException ");
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+e.toString();
				log.error(errorMsg);
			}catch (Exception e) {
				errorMsg=ApplicationConstant.I_SOCKET_RECEIVE_EXCEPTION+e.toString();
				log.error(errorMsg);
			}
		if(null!=errorMsg){
			if(Config.SEND_JALERT.equals(ApplicationConstant.YES)){
				String errMsg = "<i>Attention</i><br><br>";
				errMsg += "An Exception occured in warehouse :"+Config.INSTANCE_NAME ;
				errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
				errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
				Util.SendMailSSL(Config.EMAIL_TO, "Export: Exception occured, while exporting data to WCS", errMsg);
				emailStatus=ApplicationConstant.YES;
				}
			Util.insertToErrorLog("ExportSocketClient","Export: Exception occured while DataPacket Sending for dri "+dri+" and transmitlogkey "+transmitLogKey,errorMsg,emailStatus);
		}
		HashMap<String,Object> map= new HashMap<String,Object>();
		map.put(ApplicationConstant.SOCKET, socket);
		map.put(ApplicationConstant.ERROR, errorMsg);
		return map;
	}
	private  Socket processArtMasterData(Socket socket, BufferedReader clientIn,BufferedWriter clientOut,String dri)throws IOException {
		ArrayList<HashMap<String, String>> mapList =null;
		String errorMsg=null;
		String emailStatus=ApplicationConstant.NO;
		String artMasterType=null;
		boolean dataSent=false;
		try {
			int count=getArtMstCount(dri,ApplicationConstant.ZERO,ApplicationConstant.IN_PROCESS);
			if (count > 0) {
				artMasterType = Config.ARTICLE_MASTER;
				if (null != artMasterType) {
					String aDataPacket =null;
					String aDri=null;
					if (artMasterType.equals(ApplicationConstant.DRI_1A0)) {
						aDri=ApplicationConstant.DRI_1A0;
						aDataPacket = ApplicationConstant.ART_MASTER_1A0;
					} else if (artMasterType.equals(ApplicationConstant.DRI_1A1)) {
						aDri=ApplicationConstant.DRI_1A1;
						aDataPacket = ApplicationConstant.ART_MASTER_1A1;
					}
					aDataPacket = ApplicationConstant.LF_CHARACTER.concat(aDataPacket).concat(ApplicationConstant.CR_CHARACTER);
					String aRetStatus = null;
					String aStatus = null;
					clientOut.write(aDataPacket);
					clientOut.newLine();
					clientOut.flush();
					int i = 0;
					log.info("The data packet sent is: "+aDataPacket);
					StringBuilder statusMsg = new StringBuilder();
					while ((i = clientIn.read()) != ApplicationConstant.CR_BYTE) {
						if (i != ApplicationConstant.LF_BYTE) {
							if(i!=-1){
								statusMsg.append((char)i);
				        	 }else{
				        		 throw new ConnectException(ApplicationConstant.I_SOCKET_CON_EXCEPTION);
				        	 }
						}
					}
					dataSent=true;
					aRetStatus = statusMsg.toString();
					log.info("The return status is: "+aRetStatus);
					HashMap<String,String>aStatusMap = this.getStatusMsg(aRetStatus,aDri);
					aStatus=aStatusMap.get(ApplicationConstant.STATUS);
					errorMsg=aStatusMap.get(ApplicationConstant.ERROR);
					String aStatusDesr=Config.STATUS_MAP.get(aStatus);
					if(null==aStatusDesr){
						aStatusDesr="Unknown return status code found : "+aStatus;
						errorMsg=aStatusDesr;
					}
					if ((null==errorMsg && null!=aStatus) && (aStatus.equals(ApplicationConstant.STATUS_00) || aStatus.equals(ApplicationConstant.STATUS_94))) {
						this.updateStatusTLOutData(dri);//update process flag =5 
						int cnt=this.getArtMstCount(dri,ApplicationConstant.IN_PROCESS,ApplicationConstant.IN_PROCESS);
						while (cnt > 0) {
							mapList = this.getArtMstData(dri); // get map of serialkey and dataPacket
							if (null != mapList) {
								for (HashMap<String, String> artMap : mapList) {
									Iterator<Map.Entry<String, String>> itr = artMap.entrySet().iterator();
									Map.Entry<String, String> pair = itr.next();
									String transmitLogKey = pair.getKey();
									String bDataPacket = pair.getValue();
									String bRetStatus = null;
									String bStatus = null;
									bDataPacket = ApplicationConstant.LF_CHARACTER.concat(bDataPacket).concat(ApplicationConstant.CR_CHARACTER);
									clientOut.write(bDataPacket);
									clientOut.newLine();
									clientOut.flush();
									int j = 0;
									log.info("Article master data is : "+bDataPacket);
									StringBuilder bStatusMsg = new StringBuilder();
									while ((j = clientIn.read()) != ApplicationConstant.CR_BYTE) {
										if (j != ApplicationConstant.LF_BYTE) {
											bStatusMsg.append((char) j);
										}
									}
									bRetStatus = bStatusMsg.toString();
									log.info("The return status is: "+bRetStatus);
									HashMap<String,String>bStatusMap = this.getStatusMsg(bRetStatus,dri);
									bStatus=bStatusMap.get(ApplicationConstant.STATUS);
									errorMsg=bStatusMap.get(ApplicationConstant.ERROR);
									String statusDesr=null;
									if(null==bStatus){
										statusDesr=errorMsg;
									}else{
										statusDesr=Config.STATUS_MAP.get(bStatus);
										if(null==statusDesr){
											statusDesr="Unknown return status code found : "+bStatus;
										}
									}
									if (null!=errorMsg || !bStatus.equals(ApplicationConstant.STATUS_00)) {
										if (Config.SEND_JALERT.equals(ApplicationConstant.YES)) {
											String errMsg = "<i>Attention</i><br><br>";
											errMsg += "An Exception occured in warehouse :"+ Config.INSTANCE_NAME+ " for dri: "+ dri+ " and transmitlogkey: "+ transmitLogKey;
											errMsg += "<br>The exception is given below :<br><br>"+ statusDesr;
											errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
											Util.SendMailSSL(Config.EMAIL_TO,"Export: Exception occured, while exporting data to WCS",errMsg+" "+errorMsg);
											emailStatus = ApplicationConstant.YES;
										}
										Util.insertToErrorLog(dri,transmitLogKey,statusDesr,emailStatus);
									}
									errorMsg=this.updateArtMstStatus(transmitLogKey, bStatus,bRetStatus,dri,errorMsg);// updating processflag=as per result
								}
								dataSent=true;
							}
							cnt--;
						}
					}else{
						String statusDesr=null;
							if(null==aStatus){
								statusDesr=errorMsg;
							}else{
								statusDesr=Config.STATUS_MAP.get(aStatus);
								if(null==statusDesr){
									statusDesr="Unknown return status code found : "+aStatus;
								}
							}
						if (Config.SEND_JALERT.equals(ApplicationConstant.YES)) {
							String errMsg = "<i>Attention</i><br><br>";
							errMsg += "An Exception occured in warehouse :"+ Config.INSTANCE_NAME+ " for dri: "+ dri;
							errMsg += "<br>The exception is given below :<br><br>"+statusDesr;
							errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
							Util.SendMailSSL(Config.EMAIL_TO,"Export: Exception occured, while exporting data to WCS",errMsg+" "+errorMsg);
							emailStatus = ApplicationConstant.YES;
						}
						Util.insertToErrorLog(dri,aDataPacket.trim(),statusDesr,emailStatus);
					}
					if(dataSent){
						String cDri=ApplicationConstant.DRI_1A9;
						String cDataPacket=ApplicationConstant.ART_MASTER_1A9;
						cDataPacket = ApplicationConstant.LF_CHARACTER.concat(cDataPacket).concat(ApplicationConstant.CR_CHARACTER);
						String cRetStatus = null;
						String cStatus = null;
						clientOut.write(cDataPacket);
						clientOut.newLine();
						clientOut.flush();
						int k = 0;
						log.info("The data packet sent is: "+cDataPacket);
						StringBuilder cStatusMsg = new StringBuilder();
						while ((k = clientIn.read()) != ApplicationConstant.CR_BYTE) {
							if (k != ApplicationConstant.LF_BYTE) {
								cStatusMsg.append((char) k);
							}
						}
						cRetStatus = cStatusMsg.toString();
						log.info("The return status is: "+cRetStatus);
						HashMap<String,String>cStatusMap = this.getStatusMsg(cRetStatus,cDri);
						cStatus=cStatusMap.get(ApplicationConstant.STATUS);
						errorMsg=cStatusMap.get(ApplicationConstant.ERROR);
						String statusDesr=null;
						if(null==cStatus){
							statusDesr=errorMsg;
						}else{
							statusDesr=Config.STATUS_MAP.get(cStatus);
							if(null==statusDesr){
								statusDesr="Unknown return status code found : "+cStatus;
							}
						}
						if (null!=errorMsg || !cStatus.equals(ApplicationConstant.STATUS_00)) {
							if (Config.SEND_JALERT.equals(ApplicationConstant.YES)) {
								String errMsg = "<i>Attention</i><br><br>";
								errMsg += "An Exception occured in warehouse :"+ Config.INSTANCE_NAME+ " for dri: "+ dri;
								errMsg += "<br>The exception is given below :<br><br>"+ statusDesr;
								errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
								Util.SendMailSSL(Config.EMAIL_TO,"Export: Exception occured, while exporting data to WCS",errMsg+" "+errorMsg);
								emailStatus = ApplicationConstant.YES;
							}
							Util.insertToErrorLog(dri,ApplicationConstant.ART_MASTER_1A9,statusDesr,emailStatus);
						}
					}
				}else{
					errorMsg=ApplicationConstant.ART_MST_CONFIG_MSG;
				}
			}
			}catch (SocketTimeoutException e) {
				errorMsg=ApplicationConstant.I_SOCKET_RECEIVE_EXCEPTION+e.toString();
				log.error(errorMsg);
				socket.close();
				clientOut.close();
				clientIn.close();
				socket=null;
				socket= this.getSocketConnction(Config.KISOFT_SERVER_IP, Config.KISOFT_SERVER_PORT_OUT);
			}catch(ConnectException e){
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+e.toString();
				socket.close();
				clientOut.close();
				clientIn.close();
				socket=null;
				socket= this.getSocketConnction(Config.KISOFT_SERVER_IP, Config.KISOFT_SERVER_PORT_OUT);
				log.error(errorMsg);
			}catch(SocketException e){
				log.error("This is SocketException ");
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+e.toString();
				socket.close();
				clientOut.close();
				clientIn.close();
				socket=null;
				socket= this.getSocketConnction(Config.KISOFT_SERVER_IP, Config.KISOFT_SERVER_PORT_OUT);
				log.error(errorMsg);
			}catch (IOException e) {
				log.error("This is IOException ");
				errorMsg=ApplicationConstant.I_SOCKET_CON_EXCEPTION+e.toString();
				log.error(errorMsg);
			}catch (Exception e) {
				errorMsg=ApplicationConstant.I_SOCKET_RECEIVE_EXCEPTION+e.toString();
				log.error(errorMsg);
			}
		if(null!=errorMsg){
			if(Config.SEND_JALERT.equals(ApplicationConstant.YES)){
				String errMsg = "<i>Attention</i><br><br>";
				errMsg += "An Exception occured in warehouse :"+Config.INSTANCE_NAME ;
				errMsg += "<br>The exception is given below :<br><br>"+ errorMsg;
				errMsg += "<br><br><br><br>Note: This is a system generated email. Please do not reply to it.";
				Util.SendMailSSL(Config.EMAIL_TO, "Export: Exception occured, while exporting data to WCS", errMsg);
				emailStatus=ApplicationConstant.YES;
				}
			Util.insertToErrorLog("ExportSocketClient","Export: Exception occured while DataPacket Sending for dri "+dri,errorMsg,emailStatus);
		}
		return socket;
	}
	public  ArrayList<HashMap<String,String>> getDataPacket(String dri){
		Connection con = null;
		PreparedStatement pStmt = null;
		ResultSet rSet = null;
		HashMap<String,String> map=null;
		ArrayList<HashMap<String,String>> list=null;
		try {
			con = Util.getConnection();
			if(null!=con){
				//sql:select serialkey,DATAPACKET  from tl_out_data where processflag=? and datarecordid=? order by serialkey
				pStmt = con.prepareStatement(DBConstant.SELECT_OUT_DATA);
				pStmt.setString(1, ApplicationConstant.ZERO);
				pStmt.setString(2, dri);
				rSet = pStmt.executeQuery();
				list=new ArrayList<HashMap<String,String>>();
				while (rSet.next()) {
					map=new HashMap<String, String>();
					map.put(ApplicationConstant.TRANSMITLOGKEY, rSet.getString(1));
					map.put(ApplicationConstant.DATAPACKET, rSet.getString(2));
					list.add(map);
				}	
			}else{
				log.error("Exception occured in getDataPacket while executing sql "+DBConstant.SELECT_OUT_DATA+" DB Connection Error");
			}
			
		} catch (SQLException sqlException) {
			log.error("Exception occured in getDataPacket while executing sql "+DBConstant.SELECT_OUT_DATA+" "+sqlException.toString());
		} finally {
			try {
				if(null!=con){
					if(null!=rSet){
						rSet.close();
					}
					pStmt.close();
					con.close();
				}
			} catch (SQLException sqlException) {
				log.error("Exception occured in getDataPacket while executing sql "+DBConstant.SELECT_OUT_DATA+" "+sqlException.toString());
			}
		}
		return list;
		}
	public  ArrayList<HashMap<String,String>> getArtMstData(String dri){
		Connection con = null;
		PreparedStatement pStmt = null;
		ResultSet rSet = null;
		HashMap<String,String> map=null;
		ArrayList<HashMap<String,String>> masterList=null;
		try {
			con = Util.getConnection();
			if(null!=con){
				//sql:select transmitlogkey,DATAPACKET  from tl_out_data where processflag=? and datarecordid=? and rownum<101 order by serialkey
				pStmt = con.prepareStatement(DBConstant.SELECT_ART_MST_DATA);
				pStmt.setString(1, ApplicationConstant.IN_PROCESS);
				pStmt.setString(2, dri);
				rSet = pStmt.executeQuery();
				masterList=new ArrayList<HashMap<String,String>>();
				while (rSet.next()) {
					map=new HashMap<String, String>();
					map.put(rSet.getString(1), rSet.getString(2));
					masterList.add(map);
			}
		}
		} catch (SQLException sqlException) {
			log.error("Exception occured in getDataPacket while executing sql "+DBConstant.SELECT_ART_MST_DATA+" "+sqlException.toString());
		} finally {
			try {
				if (null != con) {
					if (null != rSet) {
						rSet.close();
					}
					pStmt.close();
					con.close();
				}
			} catch (SQLException sqlException) {
				log.error("Exception occured in getDataPacket while executing sql "+DBConstant.SELECT_ART_MST_DATA+" "+sqlException.toString());
			}
		}
		return masterList;
		}

	public  String updateRetStatusData(String transmitLogKey,String status,String retStatus,String dri,String errMsg) {
		Connection con = null;
		PreparedStatement pStmt = null;
		String errorMsg=null;
		try {
			con = Util.getConnection();
			//sql: update tl_out_data set PROCESSFLAG=?,RETURNSTATUS=?,MSG=?,PROCESSDATE =systimestamp where processflag=? and transmitlogkey=? and datarecordid=?
			pStmt = con.prepareStatement(DBConstant.UPDATE_OUT_DATA);
			if(null==status){
				pStmt.setString(1, ApplicationConstant.ERROR);
				pStmt.setString(3, errMsg);
			}else if (status.equals(ApplicationConstant.STATUS_00)){
				pStmt.setString(1, ApplicationConstant.SUCCESS);
				pStmt.setString(3, Config.STATUS_MAP.get(status));
			}else{
				pStmt.setString(1, ApplicationConstant.ERROR);
				pStmt.setString(3, Config.STATUS_MAP.get(status));
			}
			pStmt.setString(2, retStatus);
			pStmt.setString(4, ApplicationConstant.ZERO);
			pStmt.setString(5, transmitLogKey);
			pStmt.setString(6, dri);
			pStmt.executeUpdate();
		} catch (SQLException sqlException) {
			errorMsg="Exception occured in updateRetStatusData method  while executing sql "+DBConstant.UPDATE_OUT_DATA+" "+sqlException.toString();
			log.error(errorMsg);
		}catch (Exception exception) {
			errorMsg="Exception occured in updateRetStatusData method  while executing sql "+DBConstant.UPDATE_OUT_DATA+" "+exception.toString();
			log.error(errorMsg);
		} finally {
			try {
				if(null!=con){
					pStmt.close();
					con.close();
				}
			} catch (SQLException sqlException) {
				errorMsg="Exception occured in updateRetStatusData method  while executing sql "+DBConstant.UPDATE_OUT_DATA+" "+sqlException.toString();
				log.error(errorMsg);
			}
		}
		return errorMsg;
	}
	public String updateArtMstStatus(String transmitLogKey,String status,String retStatus,String dri,String errMsg) {
		Connection con = null;
		PreparedStatement pStmt = null;
		String errorMsg=null;
		try {
			con = Util.getConnection();
			//sql: update tl_out_data set PROCESSFLAG=?,RETURNSTATUS=?,MSG=?,PROCESSDATE =sysdate where processflag=? and transmitlogkey=? and datarecordid=?
			pStmt = con.prepareStatement(DBConstant.UPDATE_OUT_DATA);
			if(null==status){
				pStmt.setString(1, ApplicationConstant.ERROR);
				pStmt.setString(3, errMsg);
			}else if (status.equals(ApplicationConstant.STATUS_00)){
				pStmt.setString(1, ApplicationConstant.SUCCESS);
				pStmt.setString(3, Config.STATUS_MAP.get(status));
			}else{
				pStmt.setString(1, ApplicationConstant.ERROR);
				pStmt.setString(3, Config.STATUS_MAP.get(status));
			}
			pStmt.setString(2, retStatus);
			pStmt.setString(4, ApplicationConstant.IN_PROCESS);
			pStmt.setString(5, transmitLogKey);
			pStmt.setString(6, dri);
			pStmt.executeUpdate();
		} catch (SQLException sqlException) {
			errorMsg="Exception occured in updateArtMstStatus method  while executing sql "+DBConstant.UPDATE_OUT_DATA+" "+sqlException.toString();
			log.error(errorMsg);
		} finally {
			try {
				if(null!=con){
					pStmt.close();
					con.close();
				}
			} catch (SQLException sqlException) {
				errorMsg="Exception occured in updateArtMstStatus method  while executing sql "+DBConstant.UPDATE_OUT_DATA+" "+sqlException.toString();
				log.error(errorMsg);
			}
		}
		return errorMsg;
	}
	public String updateStatusTLOutData(String dri) {
		log.info("inside updateStatusTLOutData");
		Connection con = null;
		PreparedStatement pStmt = null;
		String errorMsg=null;
		try {
			con = Util.getConnection();
			//sql: UPDATE_ART_MST_DATA="update tl_out_data set PROCESSFLAG=? where processflag=? and datarecordid=?
			//sql:update tlv_out_data set PROCESSFLAG=?,PROCESSDATE =sysdate where processflag=? and datarecordid=?
			pStmt = con.prepareStatement(DBConstant.UPDATE_ART_MST_DATA);
			pStmt.setString(1, ApplicationConstant.IN_PROCESS);
			pStmt.setString(2, ApplicationConstant.ZERO);
			pStmt.setString(3, dri);
			int r=pStmt.executeUpdate();
		} catch (SQLException sqlException) {
			errorMsg="Exception occured in updateStatusTLOutData method  while executing sql "+DBConstant.UPDATE_OUT_DATA+" "+sqlException.toString();
			log.error(errorMsg);
		} finally {
			try {
				if(null!=con){
					pStmt.close();
					con.close();
				}
			} catch (SQLException sqlException) {
				errorMsg="Exception occured in updateStatusTLOutData method  while executing sql "+DBConstant.UPDATE_OUT_DATA+" "+sqlException.toString();
				log.error(errorMsg);
			}
		}
		return errorMsg;
	}
	private Socket  getSocketConnction(String ip,String port){
		Socket socket=null;
		long start_time = System.currentTimeMillis();
		long wait_time = Long.parseLong(Config.WAIT_TIME);
		long end_time = start_time + wait_time;
		while(null==socket && System.currentTimeMillis()<end_time){
			try {
				socket = new Socket(ip,Integer.parseInt(port));
			} catch (UnknownHostException e) {
				log.error("Exception occured in getSocketConnction method while getting connection with server"+e.toString());
			} catch (IOException e) {
				log.error("Exception occured in getSocketConnction method while getting connection with server"+e.toString());
			}
			if(null==socket){
				log.info("Trying to reconnect.....");
			}
		}
		return socket;
	}
	public HashMap<String,String> getStatusMsg(String dataPacket,String dri){
		String status=null; 
		String data=null;
		String byteCount=null;
		int dataPacketLength=0;
		String stDri=null;
		String errorMsg=null;
		HashMap<String,String> map=null;
		try{
			byteCount=dataPacket.substring(0, 7);
			int bCount=Integer.parseInt(byteCount);
			dataPacketLength=dataPacket.length();
			stDri=dataPacket.substring(7,10);
			if (stDri.equals(Config.EXPORT_STATUS_INT_MAP.get(dri))) {
				if (bCount != dataPacketLength) {
					status = ApplicationConstant.STATUS_10; // byte count error
				} else {
					data = dataPacket.substring(7, dataPacketLength);
					status = data.substring(3, data.length()).trim();
				}
			}else{
				status=ApplicationConstant.STATUS_91;//incorrect data record identifier
			}
		}catch(Exception e){
			errorMsg="Exception occured in getStatusMsg method while extracting status msg for dri "+dri+" and data packet: "+dataPacket+" "+e.toString();
			log.error(errorMsg);
		}
		map=new HashMap<String,String>();
		map.put(ApplicationConstant.STATUS, status);
		map.put(ApplicationConstant.ERROR, errorMsg);
		return map;
	}
	private int getArtMstCount(String dri,String pFlag1,String pFlag2){
		int count=0;
		Connection con = null;
		PreparedStatement pStmt = null;
		ResultSet rSet = null;
		try{
			con = Util.getConnection();
			if(null!=con){
				// sql:select count(distinct TRANSMITLOGKEY)  from tl_out_data where processflag in (?,?) and datarecordid=?
				pStmt = con.prepareStatement(DBConstant.COUNT_ART_MST_DATA);
				pStmt.setString(1, pFlag1);
				pStmt.setString(2, pFlag2);
				pStmt.setString(3, dri);
			    rSet = pStmt.executeQuery();
			    if(rSet.next()){
			    	count=Integer.parseInt(rSet.getString(1));
			    }
			    if(null!=rSet){
			    	rSet.close();
			    }
			    pStmt.close();
			    con.close();
			}else{
				log.error("Exception occured in getArtMstCount method DB Connection Error");
			}
		}catch(Exception e){
			log.error("Exception occured in getArtMstCount method "+e.toString());
		}
		return count;
	}
	public boolean isValidTimeToRun(String dri){
		HashMap<String,String> schedulerMap=null;
		String schedulerTimings=null;
		boolean flag=false;
		try{
			schedulerMap=Config.SCHEDULAR_MAP;
			if(null!=schedulerMap){
				schedulerTimings=schedulerMap.get(dri);
				String[]arrSchedulerTimings=schedulerTimings.split(ApplicationConstant.COMMA);
				for(String timings:arrSchedulerTimings){
					String [] arrTimings=timings.split(ApplicationConstant.DASH);
					String scheduleTime1=arrTimings[0];
					String scheduleTime2=arrTimings[1];					
		            String currentTime = new SimpleDateFormat(ApplicationConstant.TIME_FORMAT).format(new Date());
		            //Scheduler Start Time:
		            Date timerStart = new SimpleDateFormat(ApplicationConstant.TIME_FORMAT).parse(scheduleTime1);
		            Calendar startTime = Calendar.getInstance();
		            startTime.setTime(timerStart );
		            //Scheduler End Time:
		            Date timerEnd = new SimpleDateFormat(ApplicationConstant.TIME_FORMAT).parse(scheduleTime2);
		            Calendar endTime = Calendar.getInstance();
		            endTime.setTime(timerEnd );
		            //Scheduler Current Time:
		            Date timerNow = new SimpleDateFormat(ApplicationConstant.TIME_FORMAT).parse(currentTime);
		            Calendar cNow = Calendar.getInstance();
		            cNow.setTime(timerNow );
		            Date curDate = cNow.getTime();
		            if (curDate.after(startTime.getTime()) && curDate.before(endTime.getTime())) {
		            	flag=true;
		            } 
				}
			}
		}catch(Exception e){
			log.error("Exception occured in isValidTimeToRun method "+e.toString());
		}
		return flag;
	}
}
