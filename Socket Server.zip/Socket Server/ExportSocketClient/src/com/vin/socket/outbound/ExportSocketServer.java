package com.vin.socket.outbound;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

import org.apache.log4j.Logger;

import com.vin.socket.config.Config;
import com.vin.socket.constant.ApplicationConstant;

public class ExportSocketServer {

	private static Logger log = Logger.getLogger(ExportSocketServer.class);
	public static void main(String[] args) {
		ServerSocket serverSocket;
		try {
			serverSocket = new ServerSocket(Integer.parseInt(Config.KISOFT_SERVER_PORT_OUT));
			log.info("The server out port: "+Config.KISOFT_SERVER_PORT_OUT);
			Socket socket=serverSocket.accept();  
			BufferedReader din = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-15"));
			BufferedWriter dout= new BufferedWriter( new OutputStreamWriter( socket.getOutputStream() ) );
			while(true){
				
				int i=0;
				StringBuilder dp=new StringBuilder();
				while((i = din.read())!=ApplicationConstant.CR_BYTE) {
			         if(i!=ApplicationConstant.LF_BYTE){
			        	 dp.append((char)i);
			         }
		         }
				String dataPacket=dp.toString();
				log.info("This is data packet : "+dataPacket);
			String tempStr=null;
			log.info("this is test "+dataPacket);
			while(null!=dataPacket && !dataPacket.isEmpty()){
				if(!dataPacket.equals(tempStr)){
					String dri=dataPacket.substring(7,10);
					log.info("the dri is: "+dri);
					String sDri=Config.EXPORT_STATUS_INT_MAP.get(dri);
					//for(String so:sr){
					log.info("client says: " + dataPacket);
					dout.write("\n0000012"+sDri+"61\r");  
					dout.newLine();
					dout.flush();
					tempStr=dataPacket;
					dataPacket=null;
					log.info("msg sent");
			//	}
			}
			}
		}
		} catch (NumberFormatException e) {
			 log.error("Exception occured : "+e.toString());
		} catch (IOException e) {
			log.error("Exception occured while sending data to client "+e.toString());
		}
		
	}
	
	public static void getResponse(DataInputStream clientIn){
		long start_time = System.currentTimeMillis();
		long wait_time = 15000;
		long end_time = start_time + wait_time;
		try{
			int i=0;
			while(System.currentTimeMillis()<end_time){
				System.out.print(i++);
			}
			
		}catch(Exception ex){
			log.error("IO Exception occured while getting response from server : "+ex);
		}
	}

}
